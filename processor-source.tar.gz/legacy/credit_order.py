"""Resolve either credit order using recording evidence, never an uploader guess."""
import re,urllib.parse
from library import clean,clean_artist,clean_title,clean_track_tags,recording_key

def candidates(track):
    raw=clean(track.get('original') or track.get('title',''))[:400]
    if track.get('metadataConfirmed'):
        # A confirmed main performer can anchor a collaboration prefix, including
        # a compact dash. Extra credits are candidates until the catalogue proves
        # the complete artist/title identity; never trust an arbitrary uploader.
        known=set(recording_key({'artist':track.get('artist',''),'title':'_'}).split(':',1)[0].split('+'))
        if not track.get('artist') or not known:return []
        choices=[raw]
        displayed=clean(track.get('title',''))
        # An old catalogue snapshot can wrap the current title while retaining
        # an already plain original. It is a candidate only; full recording
        # identity and duration must still be verified by the catalogue below.
        if displayed!=raw and len(displayed)<=400 and not track.get('manualTags') and track.get('catalogueState')!='custom' and track.get('tagsMode')!='original':choices.append(displayed)
        for value in choices:
            for delimiter in re.finditer(r'[—–-]',value):
                artist=clean_artist(value[:delimiter.start()]);title=clean_title(value[delimiter.end():])
                names=set(recording_key({'artist':artist,'title':'_'}).split(':',1)[0].split('+'))
                if 0<len(artist)<=100 and 0<len(title)<=200 and known<names:
                    return [{'artist':artist,'title':title,'duration':track.get('duration',0)}]
        return []
    # A bare hyphen in an unanchored name is insufficient evidence (e.g. AC-DC).
    parts=re.split(r'\s*[—–]\s*|\s+-\s+',raw)
    if len(parts)!=2 or not all(parts):return []
    return [{'artist':clean_artist(a),'title':clean_title(b),'duration':track.get('duration',0)}
            for a,b in (parts,parts[::-1]) if len(a)<=100 and len(b)<=200]

def resolve(track,rows,provider,verify,base_title):
    matches=[];ambiguous=False
    for candidate in candidates(track):
        # Unknown ordering requires an exact title; fuzzy matches cannot identify an artist.
        wanted=clean_track_tags({**candidate,'metadataConfirmed':True})
        exact=[r for r in rows if recording_key(clean_track_tags({'artist':r.get('artistName',''),'title':base_title(r.get('trackName','')),'metadataConfirmed':True}))==recording_key({**wanted,'title':base_title(wanted['title'])})]
        result=verify(candidate,exact,provider)
        if result['catalogueState']=='ambiguous':ambiguous=True
        if result['catalogueState']=='verified':
            row=exact[0]
            tags=clean_track_tags({'artist':row['artistName'],'title':row['trackName'],'metadataConfirmed':True})
            result.update(artist=tags['artist'],title=candidate['title'] if base_title(candidate['title'])!=clean_title(candidate['title']) else tags['title'],metadataConfirmed=True,tagProvider=provider)
            matches.append(clean_track_tags(result))
    keys={recording_key(m) for m in matches}
    if ambiguous or len(keys)>1:return {'catalogueState':'ambiguous'}
    return matches[0] if matches else {'catalogueState':'not-found'}

def lookup(track,request,verify,base_title):
    choices=candidates(track)
    if not choices:return {'catalogueState':'not-found'}
    term=choices[0]['artist']+' '+base_title(choices[0]['title']);failed=False
    try:
        rows=request('https://itunes.apple.com/search?'+urllib.parse.urlencode({'term':term,'entity':'song','limit':25}),'Apple Music').get('results',[])
        result=resolve(track,rows,'Apple Music',verify,base_title)
        if result['catalogueState']!='not-found':return result
    except Exception:failed=True
    quoted=lambda s:'"'+s.replace('\\','\\\\').replace('"','\\"')+'"'
    query=' OR '.join('(artist:'+quoted(c['artist'])+' AND recording:'+quoted(base_title(c['title']))+')' for c in choices)
    try:
        data=request('https://musicbrainz.org/ws/2/recording/?'+urllib.parse.urlencode({'query':query,'fmt':'json','limit':25}),'MusicBrainz')
        rows=[{'wrapperType':'track','artistName':', '.join(a.get('name','') for a in r.get('artist-credit',[]) if isinstance(a,dict)),'trackName':r.get('title',''),'trackTimeMillis':r.get('length',0)} for r in data.get('recordings',[]) if not re.search(r'live|remix|instrumental|edit|karaoke',r.get('disambiguation',''),re.I)]
        result=resolve(track,rows,'MusicBrainz',verify,base_title)
        return {'catalogueState':'unavailable'} if failed and result['catalogueState']=='not-found' else result
    except Exception:return {'catalogueState':'unavailable'}
