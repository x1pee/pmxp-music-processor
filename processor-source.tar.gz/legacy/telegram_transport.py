"""Bounded multipart streaming and per-thread HTTPS reuse; never replay writes."""
import socket,http.client,json,mimetypes,secrets,ssl,threading,time,urllib.parse,urllib.request,urllib.error
from pathlib import Path

READ_ONLY={'getMe','getFile'}

class Multipart:
    def __init__(self,fields,files,boundary=None,on_progress=None):
        self.boundary=boundary or 'pmxp'+secrets.token_hex(16);self.parts=[];self.length=0;self.on_progress=on_progress
        for key,value in fields.items():
            if isinstance(value,(dict,list)):value=json.dumps(value,ensure_ascii=False)
            self.add(f'--{self.boundary}\r\nContent-Disposition: form-data; name="{key}"\r\n\r\n{value}\r\n'.encode())
        for key,path in files.items():
            upload_name=None
            if isinstance(path,tuple):path,upload_name=path
            path=Path(path);filename=(upload_name or path.name).replace('"','_').replace('\r','').replace('\n','')
            self.add(f'--{self.boundary}\r\nContent-Disposition: form-data; name="{key}"; filename="{filename}"\r\nContent-Type: {mimetypes.guess_type(filename)[0] or "application/octet-stream"}\r\n\r\n'.encode())
            size=path.stat().st_size;self.parts.append((path,size));self.length+=size;self.add(b'\r\n')
        self.add(f'--{self.boundary}--\r\n'.encode())
    def add(self,blob):self.parts.append(blob);self.length+=len(blob)
    def __iter__(self):
        done=0;last=0
        def emit():
            nonlocal last
            now=time.monotonic()
            if not self.on_progress or now-last<.35 and done<self.length:return
            last=now
            try:self.on_progress({'stage':'upload','updatedAt':round(time.time()*1000),'bytesDone':done,'bytesTotal':self.length})
            except Exception:pass # Status failure must never abort or replay an upload.
        for part in self.parts:
            if isinstance(part,bytes):
                yield part;done+=len(part);emit();continue
            path,size=part;remaining=size
            with path.open('rb') as file:
                if file.seek(0,2)!=size:raise ValueError('Prepared file changed')
                file.seek(0)
                while remaining:
                    chunk=file.read(min(65536,remaining))
                    if not chunk:raise ValueError('Prepared file changed')
                    remaining-=len(chunk);yield chunk
                    done+=len(chunk);emit()


class TelegramConnection(http.client.HTTPSConnection):
    """Choose a verified TLS connection before sending any HTTP request bytes."""
    endpoint_lock=threading.Lock()
    preferred=None
    preferred_until=0
    fallback='149.154.167.220'
    def connect(self):
        if self.host!='api.telegram.org' or self._tunnel_host:
            raise ValueError('Unexpected Telegram connection')
        deadline=time.monotonic()+min(6,float(self.timeout))
        with self.endpoint_lock:
            preferred=self.preferred if self.preferred_until>time.monotonic() else None
        endpoints=list(dict.fromkeys(x for x in (preferred,self.host,self.fallback) if x))
        last=None
        for endpoint in endpoints:
            remaining=deadline-time.monotonic()
            if remaining<=0:break
            sock=None
            try:
                # A dead route must not consume the 75-second file upload budget.
                sock=socket.create_connection((endpoint,self.port),timeout=min(1,remaining))
                sock.settimeout(max(.01,min(2,deadline-time.monotonic())))
                # Always authenticate api.telegram.org, including the fallback IP.
                sock=self._context.wrap_socket(sock,server_hostname=self.host)
                sock.settimeout(self.timeout)
                self.sock=sock
                with self.endpoint_lock:
                    type(self).preferred=sock.getpeername()[0]
                    type(self).preferred_until=time.monotonic()+90
                return
            except (OSError,ssl.SSLError) as error:
                last=error
                if sock is not None:sock.close()
                with self.endpoint_lock:
                    if type(self).preferred==endpoint:type(self).preferred_until=0
        raise OSError('Telegram TLS connection unavailable') from last

class Transport:
    def __init__(self,base):
        url=urllib.parse.urlsplit(base)
        if url.scheme!='https' or url.hostname!='api.telegram.org' or url.username or url.password or url.query or url.fragment:raise ValueError('Invalid Telegram endpoint')
        self.prefix=url.path;self.base=base;self.local=threading.local()
        self.proxy=bool(urllib.request.getproxies().get('https'))
        self.context=None if self.proxy else ssl.create_default_context()
    def close(self):
        connection=getattr(self.local,'connection',None)
        if connection is not None:
            try:connection.close()
            except Exception:pass
        self.local.connection=None
    def request(self,method,body,content_type,timeout=75):
        if self.proxy:
            # Retain urllib's configured/system proxy and TLS behavior for local
            # clients; the hosted direct connection can use persistent HTTPS.
            length=body.length if isinstance(body,Multipart) else len(body)
            req=urllib.request.Request(self.base+method,data=body,headers={'Content-Type':content_type,'Content-Length':str(length)})
            try:response=urllib.request.urlopen(req,timeout=timeout)
            except urllib.error.HTTPError as error:response=error
            except Exception:raise RuntimeError('Нет соединения с Telegram') from None
            try:
                raw=response.read(10*1024*1024+1);status=response.status
                if len(raw)>10*1024*1024:raise ValueError('Oversized Telegram response')
                try:data=json.loads(raw)
                except ValueError:data={}
                return status,data if isinstance(data,dict) else {}
            except Exception:raise RuntimeError('Нет соединения с Telegram') from None
            finally:response.close()
        # Conservative idle expiry avoids a stale connection on a later upload.
        if time.monotonic()-getattr(self.local,'used',0)>2:self.close()
        for attempt in range(2 if method in READ_ONLY else 1):
            try:
                connection=getattr(self.local,'connection',None)
                if connection is None:
                    connection=TelegramConnection('api.telegram.org',timeout=timeout,context=self.context);self.local.connection=connection
                connection.timeout=timeout
                sock=getattr(connection,'sock',None)
                if sock is not None:sock.settimeout(timeout)
                length=body.length if isinstance(body,Multipart) else len(body)
                connection.request('POST',self.prefix+method,body=body,headers={'Content-Type':content_type,'Content-Length':str(length)})
                response=connection.getresponse();raw=response.read(10*1024*1024+1);status=response.status
                self.local.used=time.monotonic()
                if response.will_close:self.close()
                if len(raw)>10*1024*1024:raise ValueError('Oversized Telegram response')
                try:data=json.loads(raw)
                except ValueError:data={}
                if not isinstance(data,dict):data={}
                return status,data
            except Exception:
                self.close()
                if attempt or method not in READ_ONLY:raise RuntimeError('Нет соединения с Telegram') from None
        raise RuntimeError('Нет соединения с Telegram')
