"""Bounded private preparation cache; no Telegram writes or history events."""
import copy,hashlib,json,os,secrets,shutil,threading,time
from pathlib import Path
from contextlib import contextmanager
from media import ROOT
from work_cache import atomic_json

_guard=threading.RLock()
TTL=1800
MAX_ENTRIES=24
MAX_BYTES=256*1024*1024

def identity(track,fmt,owner,bot_id):
    fields=('source','id','duration','original','originalArtist','artist','title','tagsMode','trimPercent','manualTags','coverMode','cover','downloadCover','originalCover','originalDownloadCover','catalogueCover','tagSchemaVersion','artworkLookupVersion')
    value=[1,owner,str(bot_id),fmt,{k:track.get(k) for k in fields}]
    return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False).encode()).hexdigest()

def _folder():return ROOT/'work/prepared-cache'
def _digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()

def _path(name):
    if not isinstance(name,str) or not name.startswith('sc-ready-') or '/' in name or '\\' in name:return None
    path=ROOT/'work'/name
    if path.is_symlink() or path.parent.resolve()!=(ROOT/'work').resolve():return None
    return path

def _file_rows(row):
    if not isinstance(row,dict):return None
    files=row.get('files',{})
    if not isinstance(files,dict) or any(not isinstance(item,dict) or not isinstance(item.get('name'),str) for item in files.values()):return None
    return files

def _referenced_files():
    names=set()
    for path in _folder().glob('*.json'):
        try:
            row=json.loads(path.read_text())
            files=_file_rows(row)
            if files is None:return None
            names.update(item['name'] for item in files.values())
        except (OSError,ValueError,KeyError,TypeError):
            # A record we cannot inspect is not proof that its bytes are unused.
            return None
    return names

def _remove_unused_files(row):
    files=_file_rows(row)
    if files is None:return
    referenced=_referenced_files()
    if referenced is None:return
    for item in files.values():
        p=_path(item.get('name'))
        if p and p.name not in referenced:
            try:p.unlink(missing_ok=True)
            except OSError:pass

def _remove(path,row):
    path.unlink(missing_ok=True)
    _remove_unused_files(row)

def _prune():
    entries=[]
    for p in _folder().glob('*.json'):
        try:
            row=json.loads(p.read_text());files=_file_rows(row)
            if files is None:continue
            size=sum(x.get('bytes',0) for x in files.values())
            if time.time()-row['time']>TTL:_remove(p,row)
            else:entries.append((row['time'],p,row,size))
        except (OSError,ValueError,KeyError,TypeError):continue
    entries.sort(reverse=True,key=lambda x:x[0]);total=0
    for index,(_,p,row,size) in enumerate(entries):
        total+=size
        if index>=MAX_ENTRIES or total>MAX_BYTES:_remove(p,row)

def load(key):
    if not isinstance(key,str) or len(key)!=64 or any(c not in '0123456789abcdef' for c in key):return None
    with _guard:
        copies=[];complete=False
        try:
            row=json.loads((_folder()/(key+'.json')).read_text())
            files=_file_rows(row)
            if files is None:return None
            if row['key']!=key or time.time()-row['time']>TTL:return None
            result=copy.deepcopy(row['prepared']);result['files']={}
            # Copy while holding the cache mutex; pruning cannot remove a file
            # currently being copied. The upload uses independent stable bytes.
            for name,item in files.items():
                p=_path(item.get('name'))
                if not p or not p.is_file() or p.stat().st_size!=item['bytes'] or _digest(p)!=item['sha256']:return None
            for name,item in files.items():
                source=_path(item['name']);target=ROOT/'work'/('sc-'+str(int(key[:15],16))+'-'+secrets.token_hex(6)+source.suffix)
                copies.append(target)
                shutil.copyfile(source,target);os.chmod(target,0o600)
                result['files'][name]=(target,item['uploadName']) if item.get('uploadName') else target
            complete=True
            return result
        except (OSError,ValueError,KeyError,TypeError):return None
        finally:
            if not complete:
                for target in copies:
                    try:target.unlink(missing_ok=True)
                    except OSError:pass

def store(key,prepared):
    if not isinstance(key,str) or len(key)!=64 or any(c not in '0123456789abcdef' for c in key):return False
    with _guard:
        manifest=_folder()/(key+'.json')
        try:previous=json.loads(manifest.read_text())
        except (OSError,ValueError):previous={}
        result=copy.deepcopy({k:v for k,v in prepared.items() if k!='files'})
        sources={}
        for name,value in prepared.get('files',{}).items():
            source,upload=value if isinstance(value,tuple) else (value,None)
            source=Path(source)
            if source.is_symlink() or source.resolve().parent!=(ROOT/'work').resolve() or not source.name.startswith('sc-'):return False
            if not source.is_file() or not 0<source.stat().st_size<=49*1024*1024:return False
            sources[name]=(source,upload)
        files={}
        try:
            for name,(source,upload) in sources.items():
                # New immutable names keep the current manifest usable if a
                # later copy or the atomic manifest replacement fails.
                target=ROOT/'work'/('sc-ready-'+key+'-'+name+'-'+secrets.token_hex(6)+source.suffix)
                temporary=target.with_name(target.name+'.pending')
                files[name]={'name':target.name}
                try:
                    shutil.copyfile(source,temporary);os.chmod(temporary,0o600);temporary.replace(target)
                finally:temporary.unlink(missing_ok=True)
                files[name].update(bytes=target.stat().st_size,sha256=_digest(target),uploadName=upload)
            row={'key':key,'time':time.time(),'prepared':result,'files':files}
            atomic_json(manifest,row)
        except BaseException:
            # A failure after a successful rename may already have committed
            # the new manifest. Remove only bytes no manifest references.
            _remove_unused_files({'files':files})
            raise
        # load() copies to independent paths under this same mutex; the old
        # bytes can be removed after the replacement is durable and no current
        # manifest references them, including another retained cache record.
        _remove_unused_files(previous)
        _prune();return True


@contextmanager
def leased(key,slots):
    """Reserve bounded ready-file capacity before copying a prepared upload.

    Read-only Telegram IDs need no permit. Never wait while holding the cache
    mutex: a completed sender must still be able to replace/prune its manifest.
    """
    if not isinstance(key,str) or len(key)!=64 or any(c not in '0123456789abcdef' for c in key):
        yield None;return
    with _guard:
        try:
            row=json.loads((_folder()/(key+'.json')).read_text())
            needs_files=bool(_file_rows(row))
        except (OSError,ValueError,KeyError,TypeError):needs_files=False
        if not needs_files:ready=load(key)
    if not needs_files:
        yield ready;return
    acquired=False
    try:
        slots.acquire();acquired=True
        ready=load(key)
        # It may have expired, been pruned, or become a file_id while waiting.
        # A miss must not enter cold preparation while retaining this permit.
        if not ready or not ready.get('files'):
            slots.release();acquired=False
        yield ready
    finally:
        if acquired:slots.release()
