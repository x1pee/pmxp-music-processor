"""Explicit job helpers extracted from owned service; no service process."""
import json,threading,time,uuid
from source import search_page
from media import ROOT
audit_slots=threading.BoundedSemaphore(1)

def received_input(payload):
    original=payload.get('receivedTrack');track=payload.get('track') or {}
    if isinstance(original,dict):return original
    # Old manually edited jobs have no trusted pre-edit identity.
    return {**track,'metadataConfirmed':False,'recommendationOnly':True} if track.get('manualTags') else track

def search_results(query,provider,offset,local):
    try:
        if provider=='SoundCloud':page=search_page(query,offset)
        else:
            from external_sources import search
            page=search(query,provider,offset,timeout=18)
        page['providerState']='ok' if page['tracks'] else 'empty'
        if not page['tracks']:page['providerMessage']=provider+' не вернул треки по этому запросу. Попробуй другое название или ссылку на трек.'
    except RuntimeError as error:
        if not local:raise
        page={'tracks':[],'nextOffset':None,'metadataVersion':10 if provider=='SoundCloud' else 15 if provider=='YouTube' else 14,'providerState':'error','providerMessage':str(error)}
    page['provider']=provider
    page['localCount']=len(local)
    page['tracks']=local+page['tracks']
    return page

def check_audio(track,include_quality=False,api=None):
    from audio_audit import analyze,analyze_available
    from source import download_track
    started=time.monotonic();audit=analyze_available(track)
    if audit.get('audioAuditState')=='verified' and not include_quality:return {'trackAudit':{'id':track['id'],**audit}}
    # Keep complete originals reusable; bound background downloads separately.
    # A later send reuses the file; this check never sends a Telegram message.
    with audit_slots:
        entered=time.monotonic();temporary=None
        try:
            if track.get('source')=='Telegram':
                from bot_media_cache import archive_file,same_bot
                original=archive_file(track)
                if original is None:
                    if api is None or not same_bot(track,api) or not track.get('file_id') or track.get('format') not in ('mp3','m4a','aac','ogg','opus','flac','wav'):raise ValueError('Imported audio unavailable')
                    temporary=ROOT/'work'/('tg-quality-'+uuid.uuid4().hex+'.'+track['format']);api.download(track['file_id'],temporary);original=temporary
            else:original=download_track(track)
            downloaded=time.monotonic()
            if audit.get('audioAuditState')!='verified':audit=analyze(track,original)
            result={'trackAudit':{'id':track['id'],**audit}}
            if include_quality:
                from chat_quality import inspect
                result['quality']=inspect(original)
        finally:
            if temporary:temporary.unlink(missing_ok=True)
    print('Mini audit stages wait='+str(round(entered-started,2))+' download='+str(round(downloaded-entered,2))+' scan='+str(round(time.monotonic()-downloaded,2)),flush=True)
    return result

def resolve_catalogue(rows,on_update,timeout=4):
    from tag_resolver import canonicalize
    deadline=time.monotonic()+timeout;sent={}
    while True:
        rows=[canonicalize(t,enqueue=True) for t in rows]
        changed=[]
        for t in rows:
            if t.get('catalogueState')=='pending':continue
            stamp=json.dumps(t,sort_keys=True,ensure_ascii=False)
            if sent.get(t['id'])!=stamp:sent[t['id']]=stamp;changed.append(t)
        if changed:
            try:on_update(changed)
            except Exception:pass  # Final completion still contains every result.
        if all(t.get('catalogueState')!='pending' for t in rows) or time.monotonic()>=deadline:return rows
        time.sleep(.3)
