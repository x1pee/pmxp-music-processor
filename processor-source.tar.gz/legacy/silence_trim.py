from runtime_security import run as private_run, popen as private_popen
"""Conservative terminal-silence cut; leaves originals and interior pauses intact."""
import math,re,subprocess,time
from pathlib import Path
from media import ffmpeg_path
from media_security import local_input

def trim_percent(value):
    if isinstance(value,bool) or value not in (0,50,70,80,85):raise ValueError('Invalid silence percentage')
    return int(value)

def trim_plan(source,percent):
    percent=trim_percent(percent)
    if not percent:return None
    path=Path(source)
    if not path.is_file() or path.is_symlink():raise ValueError('Not a local audio file')
    deadline=time.monotonic()+4
    def run(args):
        remaining=deadline-time.monotonic()
        if remaining<=0:raise TimeoutError('Silence scan budget exceeded')
        return private_run([ffmpeg_path(),'-hide_banner','-nostdin','-threads','1',*args],capture_output=True,timeout=remaining)
    facts={'percent':percent,'removedSeconds':0,'state':'unverified'}
    try:
        probe=run(local_input(path));text=probe.stderr.decode('utf-8',errors='replace')
        found=re.search(r'Duration: (\d+):(\d+):(\d+(?:\.\d+)?)',text)
        if not found:return facts
        total=int(found[1])*3600+int(found[2])*60+float(found[3])
        if not math.isfinite(total) or not .75<total<=1085:return facts
        for window in (20,40,60):
            length=min(total,window);offset=total-length
            # Combined detection requires every channel to be quiet. One quiet
            # stereo channel is not permission to cut the other channel's music.
            combined=run(['-ss',str(offset),*local_input(path),'-t',str(length),'-map','0:a:0','-vn','-af','silencedetect=noise=-70dB:duration=0.75','-progress','pipe:1','-nostats','-f','null','-'])
            if combined.returncode:return facts
            combined_text=combined.stderr.decode('utf-8',errors='replace')
            end_times=re.findall(r'^out_time_us=(\d+)$',combined.stdout.decode('utf-8',errors='replace'),re.M)
            if not end_times:return facts
            decoded=min(length,int(end_times[-1])/1e6)
            if decoded<length-.12:return facts
            start=None;terminal=[]
            for kind,value in re.findall(r'silence_(start|end):\s*(-?\d+(?:\.\d+)?)',combined_text):
                value=max(0,min(decoded,float(value)))
                if kind=='start':start=value
                elif start is not None:
                    if value>=decoded-.03:terminal.append(start)
                    start=None
            if start is not None:terminal.append(start)
            if not terminal:return {**facts,'state':'no-silence'}
            boundary=min(terminal)
            if boundary<=.08:
                if length>=total-.08:return {**facts,'state':'uncertain'}
                continue
            tail=decoded-boundary
            removed=min(tail*percent/100,max(0,tail-.3))
            if removed<.1:return {**facts,'state':'no-silence'}
            return {**facts,'state':'trimmed','trailingSeconds':round(tail,3),'removedSeconds':round(removed,3),'retainedSeconds':round(tail-removed,3),'endAt':round(offset+decoded-removed,3)}
    except (OSError,ValueError,TimeoutError,subprocess.TimeoutExpired):pass
    return facts
