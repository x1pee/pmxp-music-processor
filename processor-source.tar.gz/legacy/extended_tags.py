"""Stable optional audio-tag identity, shared with mini-tag-fields.mjs."""
import hashlib,json

def optional_fields(track):
    manual=track.get('manualTags')
    return {name:manual[name] for name in ('album','trackNumber','year') if name in manual} if isinstance(manual,dict) else {}

def fields_key(track):
    fields=optional_fields(track)
    return hashlib.sha256(json.dumps(fields,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest() if fields else None
