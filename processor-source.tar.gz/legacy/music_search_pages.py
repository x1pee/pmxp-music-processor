"""Reuse actual Music search continuations; bounded metadata-only live cursors."""
from collections import OrderedDict
import threading,time
from work_cache import keyed_lock

_pages=OrderedDict()
_guard=threading.Lock()
_LIMIT=16
_ROWS_LIMIT=12000
_TTL=1800

def song_page(query,offset,factory):
    if not isinstance(offset,int) or not 0<=offset<10000:raise ValueError('Invalid offset')
    key=query.casefold()
    # One query owns its extractor. Two callers never advance the same iterator
    # concurrently; other queries never reuse its mutable client context.
    with keyed_lock(('music-song-cursor',key)):
        with _guard:
            entry=_pages.get(key)
            if entry is not None and time.monotonic()-entry['touched']>_TTL:
                if not entry['active']:
                    _pages.pop(key);entry['context'].close();entry=None
            if entry is None:
                context,ie=factory()
                entry={'context':context,'iterator':iter(ie._search_results(query,ie._SECTIONS['songs'],default_client='web_music')),'rows':[],'ids':set(),'examined':0,'ended':False,'active':0,'touched':time.monotonic()}
                _pages[key]=entry
            entry['active']+=1;_pages.move_to_end(key)
        try:
            while len(entry['rows'])<offset+10 and not entry['ended']:
                try:row=next(entry['iterator'])
                except StopIteration:entry['ended']=True;break
                entry['examined']+=1
                # Repeated provider IDs must not consume another user page.
                # Existing request deadlines still bound exhausted continuations.
                if row and row.get('id') and row['id'] not in entry['ids']:
                    entry['rows'].append(row);entry['ids'].add(row.get('id'))
                if len(entry['rows'])>=10000 or entry['examined']>=12000:entry['ended']=True
            rows=entry['rows'][offset:offset+10]
            return {'entries':[dict(row) for row in rows],'nextOffset':offset+10 if not entry['ended'] and len(rows)==10 or offset+10<len(entry['rows']) else None}
        except Exception:
            with _guard:
                if _pages.get(key) is entry:_pages.pop(key)
            entry['context'].close();raise
        finally:
            with _guard:
                entry['active']-=1;entry['touched']=time.monotonic()
                for old in list(_pages):
                    if len(_pages)<=_LIMIT and sum(len(p['rows']) for p in _pages.values())<=_ROWS_LIMIT:break
                    candidate=_pages[old]
                    if candidate['active']:continue
                    _pages.pop(old);candidate['context'].close()
