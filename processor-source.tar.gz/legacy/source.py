from runtime_security import run as private_run, popen as private_popen
import threading,weakref
from collections import namedtuple
import hashlib,json,re,subprocess,sys,time,urllib.parse
from pathlib import Path
from contextlib import nullcontext
from library import clean,clean_title,clean_artist,clean_track_tags,recording_key
from media import ROOT
from work_cache import keyed_lock,atomic_json
from search_ranking import provider_counts,rank_tracks

VERSION_RE=re.compile(r'\b(?:slowed|sped[\s_-]*up|speed[\s_-]*up|night?core|reverb|remix|bass[\s_-]*boost(?:ed)?|pitch(?:ed)?|8d|ускор\w*|замедл\w*|ремикс\w*)\b',re.I)

def track_version(title):
    match=VERSION_RE.search(clean(title))
    if match:return 'Nightcore' if re.fullmatch(r'night?core',match.group(0),re.I) else match.group(0)
    from track_versions import audio_version
    return audio_version(clean(title))

_NormalizationRoster=namedtuple('_NormalizationRoster','artists names entries')

def normalization_roster(known):
    # A page uses one immutable local roster; no volatile catalogue/global cache.
    artists={clean_artist(name) for name in known}
    key=lambda name:re.sub(r'\W','',clean(name).casefold().replace('ё','е'))
    entries=[]
    for name in sorted(artists,key=len,reverse=True):
        escaped=re.escape(name).replace(r'\ ',r'\s*')
        boundary=r'(?:\s+[—–-]\s+|\s*[—–]\s*)'
        entries.append((name,key(name),re.compile(r'^'+escaped+boundary+r'(.+)$',re.I),
                        re.compile(r'^(.+?)'+boundary+escaped+r'(?P<edition>\s*\([^)]*\))?$',re.I)))
    return _NormalizationRoster(tuple(artists),frozenset(key(name) for name in artists),tuple(entries))

def normalize_track(item,known):
    original=clean(item.get('title',''));uploader=clean(item.get('uploader',''))
    title=re.sub(r'\s*\((?:prod\.?|produced by)\s[^)]*\)','',original,flags=re.I).strip()
    published=item.get('artist') or ' & '.join(item.get('artists') or [])
    original_artist=clean(published or uploader)
    artist=clean(published or uploader);confirmed=bool(published)
    key=lambda s:re.sub(r'\W','',clean(s).casefold().replace('ё','е'))
    roster=known if isinstance(known,_NormalizationRoster) else normalization_roster(known)
    known=roster.artists;names=roster.names
    title_tags=clean_track_tags({'artist':artist,'title':title,'metadataConfirmed':confirmed},known)
    if title_tags['title']!=clean_title(title):
        artist=title_tags['artist'];title=title_tags['title'];confirmed=True;published=artist
    # Full collaboration prefixes take priority over a single known name.
    parts=re.split(r'\s+[—–-]\s+',title,maxsplit=1)
    if len(parts)==2:
        prefix=parts[0].strip();members=re.split(r'\s*(?:&|,|\+|\bfeat\.?|\bft\.?)\s*|\s+[xх×]\s+',prefix,flags=re.I)
        # Publisher artist fields outrank unrelated names found in upload titles.
        if (published and key(prefix)==key(artist)) or (not confirmed and len(prefix)<=100 and any(key(m) in names for m in members) and all(0<len(m)<=45 for m in members)):
            artist=prefix;title=parts[1].strip();confirmed=True
    for name,name_key,prefix_pattern,suffix_pattern in roster.entries:
        # The old path discarded both matches for a different confirmed artist.
        if confirmed and key(artist)!=name_key:continue
        prefix=prefix_pattern.match(title);suffix=suffix_pattern.match(title)
        if prefix or suffix:
            artist=name;title=(prefix or suffix)[1];confirmed=True
            if suffix and not prefix and suffix['edition']:
                from track_versions import version_labels
                if version_labels(suffix['edition']):title+=' '+suffix['edition'].strip()
            break
        if not confirmed and key(clean_artist(name))==key(clean_artist(uploader)):artist=clean_artist(name);confirmed=True
    collaboration=re.match(r'^(.+?)\s+\+\s*([^()]+)$',title)
    if collaboration:title=collaboration[1].strip();artist+=' & '+collaboration[2].strip()
    title=re.sub(r'^\d{1,2}[.)]\s+','',title).strip(' —–-')
    # Strip a repeated full performer field without duplicating collaborators.
    parts=re.split(r'\s+[—–-]\s+',title,maxsplit=1)
    if len(parts)==2 and key(parts[0])==key(artist):title=parts[1].strip()
    if not confirmed:artist='Исполнитель не подтверждён'
    thumbs=item.get('thumbnails') or []
    cover=item.get('thumbnail') or (thumbs[-1].get('url','') if thumbs else '')
    track={**provider_counts(item),'id':str(item['id']),'title':clean_title(title),'artist':clean_artist(artist) or 'Неизвестный исполнитель','uploader':uploader,'metadataConfirmed':confirmed,
        'duration':round(item.get('duration') or 0),'cover':cover,'source':'SoundCloud','url':item.get('webpage_url') or '', 'original':original,'originalArtist':original_artist,'version':track_version(original)}
    from tag_resolver import canonicalize
    return canonicalize(track)

def call_source(action,payload,timeout=None,on_progress=None):
    try:
        if action=='search':
            # Reuse imported extractor code in the server; no Python child per query.
            from source_cli import search_independent
            try:return search_independent(payload['query'],payload.get('offset',0))
            except Exception:raise RuntimeError('SoundCloud временно недоступен. Попробуй ещё раз.') from None
        budget=timeout if timeout is not None else 75 if action=='search' else 240
        if action=='download':
            from download_process import try_download,legacy_permit
            started=time.monotonic()
            ready=try_download({'action':action,'provider':'SoundCloud',**payload},timeout=budget,on_progress=on_progress)
            if ready is not None:return ready
            budget-=time.monotonic()-started
            if budget<=0:raise RuntimeError('SoundCloud отвечает долго. Попробуй ещё раз.')
        permit=legacy_permit(timeout=budget) if action=='download' else nullcontext(budget)
        with permit as remaining:
            if on_progress and action=='download':
                from download_progress import run_with_progress
                run=run_with_progress([sys.executable,'-X','utf8',str(Path(__file__).with_name('source_cli.py'))],{'action':action,**payload},remaining,on_progress)
            else:
                run=private_run([sys.executable,'-X','utf8',str(Path(__file__).with_name('source_cli.py'))],input=json.dumps({'action':action,**payload},ensure_ascii=False),capture_output=True,text=True,encoding='utf-8',timeout=remaining)
        data=json.loads(run.stdout)
        if not data.get('ok'):raise RuntimeError(data.get('error','Источник временно недоступен.'))
        return data['result']
    except subprocess.TimeoutExpired:raise RuntimeError('SoundCloud отвечает долго. Попробуй ещё раз.') from None
    except (ValueError,KeyError):raise RuntimeError('Не удалось получить ответ SoundCloud. Попробуй позже.') from None

ARTIST_ALIASES={'капсайз':'CUPSIZE','капсайс':'CUPSIZE','купсайз':'CUPSIZE','мэдкид':'madk1d','мэдкит':'madk1d','мадкид':'madk1d','мэдкайд':'madk1d'}
def resolve_artist_query(query):
    # Keep any song words following a recognized artist spelling.
    canonical=clean_artist(query)
    folded=query.casefold().replace('ё','е')
    for alias,canonical in ARTIST_ALIASES.items():
        if folded==alias or folded.startswith(alias+' '):return canonical+query[len(alias):]
    from query_normalizer import resolve_known
    try:known={x['artist'] for x in json.loads((ROOT/'catalog/catalog.json').read_text(encoding='utf-8')) if x.get('artist')}
    except (OSError,ValueError):known=set()
    return resolve_known(query,known)

def version_quality(track):
    if track.get('version'):return 3
    if track.get('catalogueState')!='verified':return 1
    if track.get('audioAuditState')!='verified':return 1
    from audio_audit import effective_duration,duration_tolerance
    from math import isfinite
    measured=float(track.get('audioDuration') or 0);reference=float(track.get('referenceDuration') or 0)
    if not isfinite(measured) or not isfinite(reference) or measured<=0 or reference<=0:return 1
    gap=effective_duration(track)-reference
    return 0 if abs(gap)<=duration_tolerance(track) else 2

def search_page(query,offset=0):
    # Cached metadata also warms only code for the next selected-track download.
    try:
        from download_process import warm
        warm()
    except Exception:pass
    query=resolve_artist_query(clean(query).strip()[:150])
    with keyed_lock(('soundcloud-search',query.casefold(),offset)):
        return _search_page(query,offset)

def _search_page(query,offset=0):
    started=time.monotonic();provider_seconds=0.;normalize_seconds=0.;pages=0
    query=resolve_artist_query(clean(query).strip()[:150])
    if len(query)<2:return {'tracks':[],'nextOffset':None}
    # Artist aliases come from metadata, not from a fixed list of special-case songs.
    catalog=json.loads((ROOT/'catalog'/'catalog.json').read_text(encoding='utf-8'))
    known={x['artist'] for x in catalog if x.get('artist')}
    key=lambda s:re.sub(r'\W','',s.casefold().replace('ё','е'))
    translit={'а':'a','б':'b','в':'v','г':'g','д':'d','е':'e','ё':'e','ж':'zh','з':'z','и':'i','й':'i','к':'k','л':'l','м':'m','н':'n','о':'o','п':'p','р':'r','с':'s','т':'t','у':'u','ф':'f','х':'h','ц':'ts','ч':'ch','ш':'sh','щ':'sch','ъ':'','ы':'y','ь':'','э':'e','ю':'yu','я':'ya'}
    latin=''.join(translit.get(c,c) for c in query.casefold())
    alias=next((a for a in known if a.isascii() and key(a)==key(latin)),None)
    if alias:query=alias
    cache=ROOT/'work'/('search-'+hashlib.sha256((query.casefold()+':'+str(offset)+':v14-title-popularity').encode()).hexdigest()[:16]+'.json')
    if cache.exists() and time.time()-cache.stat().st_mtime<1800:
        try:
            from tag_resolver import canonicalize
            result=json.loads(cache.read_text(encoding='utf-8'));result['tracks']=rank_tracks(query,[canonicalize(t) for t in result['tracks']],version_quality)
            print('SC search cache=hit seconds='+str(round(time.monotonic()-started,3))+' rows='+str(len(result['tracks'])),flush=True)
            return result
        except ValueError:pass
    # An explicit version query keeps editions. Ordinary searches skip labelled
    # alterations; unlabelled audio cannot be certified from metadata alone.
    editions=bool(track_version(query));rows=[];cursor=offset
    roster=normalization_roster(known)
    for attempt in range(3):
        stage=time.monotonic()
        try:raw=call_source('search',{'query':query,'offset':cursor})
        except Exception:
            print('SC search cache=miss failed=provider seconds='+str(round(time.monotonic()-started,3))+' pages='+str(pages+1),flush=True)
            raise
        provider_seconds+=time.monotonic()-stage;pages+=1;stage=time.monotonic()
        rows=[normalize_track(x,roster) for x in raw['entries']]
        normalize_seconds+=time.monotonic()-stage
        if not editions:rows=[x for x in rows if not x['version']]
        cursor=raw.get('nextOffset')
        if rows or cursor is None:break
    rows=rank_tracks(query,rows,version_quality)
    output=[];seen=set()
    for row in rows:
        identity=recording_key({**row,'artist':row['artist'] if row['metadataConfirmed'] else row['uploader']})
        if identity in seen or not 0<row['duration']<=1080:continue
        if not valid_url(row['url']):continue
        seen.add(identity);output.append(row)
        if len(output)>=10:break
    result={'tracks':output,'nextOffset':cursor,'metadataVersion':10,'versionsRequested':editions,'resolvedQuery':query,'ranking':'title-popularity','searchRankingVersion':1}
    atomic_json(cache,result)
    print('SC search cache=miss seconds='+str(round(time.monotonic()-started,3))+' provider='+str(round(provider_seconds,3))+' normalize='+str(round(normalize_seconds,3))+' pages='+str(pages)+' rows='+str(len(output)),flush=True)
    return result

def search_tracks(query):
    return search_page(query)['tracks']

def valid_url(url):
    parsed=urllib.parse.urlsplit(url)
    return parsed.scheme=='https' and parsed.hostname=='soundcloud.com' and not parsed.username and not parsed.password and len([x for x in parsed.path.split('/') if x])==2

_download_locks=weakref.WeakValueDictionary()
_download_guard=threading.Lock()
def download_track(track,timeout=None,on_progress=None):
    if track.get('source') in ('YouTube','Bandcamp'):
        from external_sources import download
        with _download_guard:lock=_download_locks.setdefault(track['id'],threading.Lock())
        with lock:return download(track,on_progress=on_progress) if on_progress else download(track)
    if not valid_url(track['url']):raise ValueError('Недопустимый источник')
    if not re.fullmatch(r'\d{1,20}',str(track['id'])):raise ValueError('Недопустимый трек')
    with _download_guard:lock=_download_locks.setdefault(track['id'],threading.Lock())
    started=time.monotonic()
    acquired=lock.acquire(timeout=max(.1,timeout)) if timeout is not None else lock.acquire()
    if not acquired:raise RuntimeError('Файл ещё загружается. Попробуй позже.')
    try:
        # A complete original is already local: do not start another Python/extractor.
        for extension in ('m4a','mp3','opus','ogg','webm'):
            path=ROOT/'work'/('sc-'+track['id']+'.'+extension)
            if path.is_file() and not path.is_symlink() and 0<path.stat().st_size<=49*1024*1024:return path
        remaining=max(.1,timeout-(time.monotonic()-started)) if timeout is not None else None
        payload={'url':track['url'],'id':track['id']}
        kwargs={}
        if remaining is not None:kwargs['timeout']=remaining
        if on_progress:kwargs['on_progress']=on_progress
        return Path(call_source('download',payload,**kwargs))
    finally:lock.release()
