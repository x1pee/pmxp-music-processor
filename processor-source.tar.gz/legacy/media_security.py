"""Restrict uploaded files to audio/image demuxers, never local playlists."""
AUDIO_FORMATS='mp3,mov,aac,wav,flac,ogg,matroska,webm'
IMAGE_FORMATS='image2,jpeg_pipe,png_pipe,webp_pipe,bmp_pipe'
MAX_IMAGE_PIXELS=16*1024*1024

def local_input(path, image=False):
    # Compressed byte limits do not bound decoded images/attached artwork.
    return ['-protocol_whitelist','file,pipe','-format_whitelist',IMAGE_FORMATS if image else AUDIO_FORMATS,'-max_pixels',str(MAX_IMAGE_PIXELS),'-i',str(path)]
