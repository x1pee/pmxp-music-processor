"""Private newline RPC, preserving Music continuations between searches."""
import json,os,sys,threading,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent/'vendor'))
parent=os.getppid()
def watch_parent():
    while True:
        time.sleep(1)
        if os.getppid()!=parent:os._exit(0)
threading.Thread(target=watch_parent,daemon=True).start()
from external_sources import main,user_error,warm_search
PROTOCOL=1
print(json.dumps({'type':'ready','protocol':PROTOCOL}),flush=True)
for line in sys.stdin:
    ident=None
    try:
        request=json.loads(line);ident=request['id'];payload=request['payload']
        if payload.get('provider')!='YouTube' or payload.get('action') not in ('search','warm'):raise ValueError('Invalid provider worker operation')
        if payload['action']=='warm':
            warm_search();result={'warmed':True}
        else:result=main(payload)
        reply={'protocol':PROTOCOL,'id':ident,'ok':True,'result':result}
    except Exception as error:reply={'protocol':PROTOCOL,'id':ident,'ok':False,'error':user_error(error,'YouTube')[:300]}
    print(json.dumps(reply,ensure_ascii=False),flush=True)
