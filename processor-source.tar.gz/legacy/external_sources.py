from runtime_security import run as private_run, popen as private_popen
"""Separate public providers. IDs never overlap SoundCloud; URLs are allowlisted."""
import hashlib,itertools,json,re,subprocess,sys,time,urllib.parse,threading
from pathlib import Path
from contextlib import nullcontext
from media import ROOT,ffmpeg_path
from library import clean,clean_artist,clean_title,clean_track_tags
from work_cache import keyed_lock,atomic_json
from search_ranking import provider_counts,rank_tracks,displayed_plays

PROVIDERS=('SoundCloud','YouTube','Bandcamp')
_music_context=threading.local()

def user_error(error,provider):
    if isinstance(error,RuntimeError):return str(error)
    reason=str(error).lower()
    if provider=='YouTube' and ('confirm your age' in reason or 'age-restricted' in reason):
        return 'YouTube требует подтверждения возраста для этой записи. Без авторизации она недоступна; выбери другой трек или источник.'
    if provider=='YouTube' and ('sign in' in reason or 'not a bot' in reason or 'http error 403' in reason):
        return 'YouTube ограничил доступ к этой записи с сервера. Выбери другой трек или источник.'
    return 'Источник не отдал трек. Возможно, аудио недоступно; выбери другую запись.'

def valid_external(track):
    url=urllib.parse.urlsplit(track.get('url',''))
    if url.scheme!='https' or url.username or url.password or url.port not in (None,443) or url.fragment:return False
    ident=track.get('id','')
    if track.get('source')=='YouTube':
        return bool(re.fullmatch(r'yt-[\w-]{11}',ident) and url.netloc=='www.youtube.com' and url.path=='/watch' and url.query=='v='+ident[3:])
    if track.get('source')=='Bandcamp':
        return bool(re.fullmatch(r'[a-z0-9-]+\.bandcamp\.com',url.netloc) and re.fullmatch(r'/track/[\w%-]+',url.path) and not url.query and ident=='bc-'+hashlib.sha256(track['url'].encode()).hexdigest()[:24])
    return False

def link(query,provider):
    url=urllib.parse.urlsplit(query)
    if provider=='YouTube':
        ident=url.path.strip('/') if url.hostname=='youtu.be' else urllib.parse.parse_qs(url.query).get('v',[''])[0] if url.hostname in ('www.youtube.com','youtube.com','music.youtube.com') and url.path=='/watch' else ''
        row={'source':provider,'id':'yt-'+ident,'url':'https://www.youtube.com/watch?v='+ident}
    else:row={'source':provider,'id':'bc-'+hashlib.sha256(query.encode()).hexdigest()[:24],'url':query}
    return row if valid_external(row) else None

def music_cover(renderer):
    thumbnails=renderer.get('thumbnail',{}).get('musicThumbnailRenderer',{}).get('thumbnail',{}).get('thumbnails',[])
    square=[]
    for item in thumbnails:
        parsed=urllib.parse.urlsplit(item.get('url',''))
        if parsed.scheme!='https' or parsed.hostname not in {'yt3.googleusercontent.com','lh3.googleusercontent.com','i.ytimg.com'} or parsed.username or parsed.password or parsed.port not in (None,443):continue
        width,height=item.get('width',0),item.get('height',0)
        if isinstance(width,(int,float)) and isinstance(height,(int,float)) and 0<width==height<=10000:square.append(item)
    if not square:return ''
    # A larger video thumbnail must not hide the genuine Music artwork.
    artwork=[i for i in square if urllib.parse.urlsplit(i['url']).hostname in {'yt3.googleusercontent.com','lh3.googleusercontent.com'}]
    url=max(artwork or square,key=lambda item:item['width'])['url']
    if urllib.parse.urlsplit(url).hostname in {'yt3.googleusercontent.com','lh3.googleusercontent.com'}:
        url=re.sub(r'=w\d+-h\d+(-[^/?#]*)$',r'=w600-h600\1',url)
    return url

def normalize(info,provider,url=None):
    from source import track_version
    ident=('yt-'+str(info['id'])) if provider=='YouTube' else 'bc-'+hashlib.sha256(url.encode()).hexdigest()[:24]
    url=url or 'https://www.youtube.com/watch?v='+str(info['id'])
    original=clean(info.get('track') or info.get('title') or '')
    credit=info.get('artist') or info.get('creator')
    channel=clean(info.get('channel') or info.get('uploader') or '')
    artist=clean_artist(credit or channel);title=original;confirmed=bool(credit)
    parts=re.split(r'\s+[—–-]\s+',original,maxsplit=1)
    structured=bool(credit and (info.get('track') or info.get('_pmx_music_song')))
    if not structured and len(parts)==2 and 0<len(parts[0])<=100:artist=clean_artist(parts[0]);title=parts[1];confirmed=True
    if channel.endswith(' - Topic') and not credit:artist=clean_artist(channel[:-8]);confirmed=True
    row={**provider_counts(info),'id':ident,'url':url,'source':provider,'sourceLabel':'YouTube Music' if info.get('_pmx_music_song') else provider,'title':clean_title(title),'artist':artist or 'Исполнитель не подтверждён','original':original,'originalArtist':clean(credit or channel),'metadataConfirmed':confirmed,'duration':round(info.get('duration') or 0),'version':track_version(original),'cover':(info.get('_pmx_music_cover') or 'https://i.ytimg.com/vi/'+info['id']+'/hqdefault.jpg') if provider=='YouTube' else info.get('thumbnail','')}
    if provider=='YouTube' and info.get('_pmx_music_cover'):row['downloadCover']=info['_pmx_music_cover']
    album_id=info.get('_pmx_music_album_id','')
    if provider=='YouTube' and re.fullmatch(r'MPREb_[\w-]{5,100}',album_id):row.update(albumId='yt-album-'+album_id,albumTitle=clean(info.get('_pmx_music_album_title',''))[:200])
    if not valid_external(row):raise ValueError('Invalid provider identity')
    from tag_resolver import canonicalize
    return canonicalize(clean_track_tags(row))

def search(query,provider,offset=0,timeout=40,artist_lookup=False):
    if provider not in PROVIDERS[1:]:raise ValueError('Invalid provider')
    query=clean(query)[:250]
    if provider=='YouTube':
        try:
            from download_process import warm
            warm()
        except Exception:pass
    if provider=='Bandcamp' and not link(query,provider):raise RuntimeError('Вставь ссылку на трек автора в Bandcamp: https://имя.bandcamp.com/track/название')
    from query_normalizer import resolve_known
    if not link(query,provider):query=resolve_known(query)
    if offset>=10000:return {'tracks':[],'nextOffset':None,'metadataVersion':15}
    key=hashlib.sha256((provider+':'+query.casefold()+':'+str(offset)+(':artist-top-v9-popularity' if artist_lookup else ':songs-only-v4-popularity')).encode()).hexdigest()[:24]
    path=ROOT/'work'/('provider-search-'+key+'.json')
    with keyed_lock(('provider-search',key)):
        result=None
        try:
            saved=json.loads(path.read_text(encoding='utf-8'))
            if isinstance(saved.get('tracks'),list) and time.time()-path.stat().st_mtime<(1800 if saved['tracks'] else 90):result=saved
        except (OSError,ValueError,TypeError,AttributeError):pass
        if result is None:
            result=call({'action':'search','query':query,'provider':provider,'offset':offset,'artistLookup':artist_lookup},timeout=timeout)
            atomic_json(path,result)
    from tag_resolver import canonicalize
    result['tracks']=[canonicalize(t) for t in result['tracks']]
    if result.get('ranking')=='title-popularity':
        from source import version_quality
        result['tracks']=rank_tracks(query,result['tracks'],version_quality)
    return result

def call(payload,timeout=None,on_progress=None):
    try:
        if payload['action']=='search' and payload.get('provider')=='YouTube' and not link(payload['query'],'YouTube'):
            from provider_process import search as bounded_search
            return bounded_search(payload,timeout=timeout or 40)
        budget=max(8,min(40,timeout or 40)) if payload['action']=='search' else 180
        if payload['action']=='download':
            from download_process import try_download,legacy_permit
            started=time.monotonic()
            ready=try_download({**payload,'provider':payload['track']['source']},timeout=budget,on_progress=on_progress)
            if ready is not None:return ready
            budget-=time.monotonic()-started
            if budget<=0:raise RuntimeError('Источник отвечает долго. Попробуй другой.')
        permit=legacy_permit(timeout=budget) if payload['action']=='download' else nullcontext(budget)
        with permit as remaining:
            if on_progress and payload['action']=='download':
                from download_progress import run_with_progress
                run=run_with_progress([sys.executable,'-X','utf8',str(Path(__file__).with_name('external_sources.py'))],payload,remaining,on_progress)
            else:
                run=private_run([sys.executable,'-X','utf8',str(Path(__file__).with_name('external_sources.py'))],input=json.dumps(payload),capture_output=True,text=True,encoding='utf-8',timeout=remaining)
        data=json.loads(run.stdout)
        if not data.get('ok'):raise RuntimeError(data.get('error','Источник не отдал аудио.'))
        return data['result']
    except (ValueError,subprocess.TimeoutExpired):raise RuntimeError('Источник отвечает долго или временно недоступен. Попробуй другой.') from None

def completed_download(track):
    """Use only a completed, identity-bound file; never accept a .part or symlink."""
    if not valid_external(track):return None,{}
    target=ROOT/'work'/('sc-'+track['id']);marker=target.with_suffix('.complete.json')
    try:
        if marker.is_symlink():return None,{}
        saved=json.loads(marker.read_text(encoding='utf-8'))
        if saved.get('url')!=track['url']:return None,{}
        for ext in ('m4a','mp3','opus','ogg','webm'):
            file=target.with_suffix('.'+ext)
            if file.is_symlink() or not file.is_file():continue
            stat=file.stat()
            if saved.get('stamp')==[stat.st_size,stat.st_mtime_ns] and 0<stat.st_size<=49*1024*1024:return file,saved
    except (OSError,ValueError,TypeError,AttributeError):pass
    return None,{}

def download(track,on_progress=None):
    if not valid_external(track):raise ValueError('Invalid external track')
    file,_=completed_download(track)
    if file is not None:return file
    return Path(call({'action':'download','track':track},on_progress=on_progress) if on_progress else call({'action':'download','track':track}))

def music_entry(renderer,entry):
    if not entry or not renderer.get('playlistItemData',{}).get('videoId'):return None
    runs=[]
    for column in renderer.get('flexColumns') or []:
        runs.extend(column.get('musicResponsiveListItemFlexColumnRenderer',{}).get('text',{}).get('runs',[]))
    for column in renderer.get('fixedColumns') or []:
        runs.extend(column.get('musicResponsiveListItemFixedColumnRenderer',{}).get('text',{}).get('runs',[]))
    # ATV denotes the catalog audio recording; OMV/UGC can be clips or uploads.
    types=[r.get('navigationEndpoint',{}).get('watchEndpoint',{}).get('watchEndpointMusicSupportedConfigs',{}).get('watchEndpointMusicConfig',{}).get('musicVideoType') for r in runs]
    if 'MUSIC_VIDEO_TYPE_ATV' not in types:return None
    artists=[];duration=0
    for run in runs:
        browse=run.get('navigationEndpoint',{}).get('browseEndpoint',{})
        page=browse.get('browseEndpointContextSupportedConfigs',{}).get('browseEndpointContextMusicConfig',{}).get('pageType')
        if page=='MUSIC_PAGE_TYPE_ARTIST' and run.get('text') and run['text'] not in artists:artists.append(run['text'])
        text=run.get('text','')
        if re.fullmatch(r'\d{1,2}:\d{2}(?::\d{2})?',text):
            duration=0
            for number in text.split(':'):duration=duration*60+int(number)
    if not artists or not 0<duration<=1080:return None
    albums=[]
    for run in runs:
        browse=run.get('navigationEndpoint',{}).get('browseEndpoint',{})
        page=browse.get('browseEndpointContextSupportedConfigs',{}).get('browseEndpointContextMusicConfig',{}).get('pageType')
        ident=browse.get('browseId','')
        if page=='MUSIC_PAGE_TYPE_ALBUM' and re.fullmatch(r'MPREb_[\w-]{5,100}',ident):albums.append((ident,clean(run.get('text',''))))
    album=albums[0] if len({a[0] for a in albums})==1 else ('','')
    plays=next((count for run in runs if (count:=displayed_plays(run.get('text',''))) is not None),None)
    return {**entry,**({'playCount':plays} if plays is not None else {}),'artist':', '.join(artists),'duration':duration,'_pmx_music_song':True,'_pmx_music_cover':music_cover(renderer),'_pmx_music_album_id':album[0],'_pmx_music_album_title':album[1]}

def provider_options(download=False):
    sys.path.insert(0,str(ROOT/'vendor'))
    from source_cli import Quiet
    opts={'quiet':True,'logger':Quiet(),'socket_timeout':8,'retries':1,'fragment_retries':1,'noplaylist':True,'hls_prefer_native':True,'external_downloader':{'default':'native'},'cachedir':False}
    # Metadata-only search never invokes FFmpeg. Executable discovery belongs
    # to the download path; it must not delay the first search response.
    if download:opts['ffmpeg_location']=ffmpeg_path()
    node=ROOT.parent/'makcraex.beget.tech/pmxp-node/bin/node'
    if node.is_file():opts['js_runtimes']={'node':{'path':str(node)}}
    return opts

def make_music_context(opts):
    import yt_dlp
    from yt_dlp.extractor.youtube._search import YoutubeMusicSearchURLIE as BaseMusicSearch
    class YoutubeMusicSearchURLIE(BaseMusicSearch):
        def _music_reponsive_list_entry(self,renderer):
            from music_catalogue import artist_entry
            entry=super()._music_reponsive_list_entry(renderer)
            return music_entry(renderer,entry) if renderer.get('playlistItemData',{}).get('videoId') else artist_entry(renderer,entry)
    context=yt_dlp.YoutubeDL({**opts,'extract_flat':'in_playlist','skip_download':True},auto_init=False)
    context.add_info_extractor(YoutubeMusicSearchURLIE(context))
    return context,context.get_info_extractor(YoutubeMusicSearchURLIE.ie_key())

def warm_search():
    """Prepare this worker's code/context only; never query providers or audio."""
    from source import track_version
    from tag_resolver import canonicalize
    from music_catalogue import artist_songs
    from music_search_pages import song_page
    if getattr(_music_context,'extractor',None) is None:
        context,_=make_music_context(provider_options())
        _music_context.extractor=context

def main(payload):
    # A queued caller may find the original completed since it first checked.
    if payload['action']=='download':
        file,_=completed_download(payload['track'])
        if file is not None:return str(file)
    sys.path.insert(0,str(ROOT/'vendor'))
    import yt_dlp
    from source import track_version
    opts=provider_options(download=payload['action']=='download')
    if payload['action']=='search':
        provider=payload['provider'];query=clean(payload['query'])[:250];offset=int(payload.get('offset',0));direct=link(query,provider)
        if provider not in PROVIDERS[1:] or not 0<=offset<=10000:raise ValueError('Invalid search')
        if provider=='Bandcamp' and not direct:raise RuntimeError('Вставь ссылку на трек Bandcamp.')
        if provider=='YouTube' and not direct:
            # A context per thread retains the music client and HTTP connection pool.
            # Register only Music search; do not instantiate every video extractor.
            def factory():return make_music_context(opts)
            y=getattr(_music_context,'extractor',None)
            if y is None:
                y,_=factory();_music_context.extractor=y
            y.params['playlistend']=offset+10
            try:
                from music_catalogue import artist_songs
                music_ie=y.get_info_extractor('YoutubeMusicSearchURL')
                try:top=artist_songs(music_ie,query,offset,music_entry) if payload.get('artistLookup',False) else None
                except Exception:top=None  # A catalogue outage must not disable regular song search.
                if top is not None:raw=top['entries'];query=top['resolvedQuery']
                else:
                    from music_search_pages import song_page
                    song_result=song_page(query,offset,factory)
                    raw=song_result['entries']
            except Exception:
                y.close();_music_context.extractor=None;raise
        else:
            with yt_dlp.YoutubeDL({**opts,'extract_flat':False,'skip_download':True}) as y:
                info=y.extract_info(direct['url'],download=False)
            raw=[info]
        rows=[]
        for item in raw:
            # Flat YouTube search also returns channels and playlists.
            # An invalid identity must not discard the valid videos in this page.
            if provider=='YouTube' and not re.fullmatch(r'[\w-]{11}',str(item.get('id',''))):continue
            if item.get('is_live') or item.get('live_status') in ('is_live','is_upcoming'):continue
            row=normalize(item,provider,direct['url'] if direct else None)
            if not 0<row['duration']<=1080 or (row['version'] and not track_version(query)):continue
            rows.append(row)
        from source import version_quality
        if provider=='YouTube' and not direct and top is None:rows=rank_tracks(query,rows,version_quality)
        return {'tracks':rows,'nextOffset':top['nextOffset'] if provider=='YouTube' and not direct and top is not None else song_result['nextOffset'] if provider=='YouTube' and not direct else None,'metadataVersion':15,'provider':provider,'resolvedQuery':query,'ranking':top.get('ranking','artist-top-songs') if provider=='YouTube' and not direct and top is not None else 'title-popularity','searchRankingVersion':1,'sourceLabel':'YouTube Music' if provider=='YouTube' and not direct else provider}
    if payload['action']=='download':
        track=payload['track']
        if not valid_external(track):raise ValueError('Invalid source')
        target=ROOT/'work'/('sc-'+track['id'])
        completed=target.with_suffix('.complete.json')
        if payload.get('progressPath'):
            from download_progress import progress_hook
            opts={**opts,'progress_hooks':[progress_hook(payload['progressPath'])]}
        from native_audio import ready_audio_selector
        with yt_dlp.YoutubeDL({**opts,'format':ready_audio_selector,'concurrent_fragment_downloads':1,'skip_unavailable_fragments':False,'overwrites':True,'outtmpl':str(target)+'.%(ext)s','max_filesize':45*1024*1024,'match_filter':lambda i,**kw:'Unsupported long/live audio' if i.get('is_live') or (i.get('duration') or 0)>1080 else None}) as y:
            info=y.extract_info(track['url'],download=True);file=Path(y.prepare_filename(info))
        if track['source']=='YouTube' and str(info.get('id'))!=track['id'][3:]:raise ValueError('Identity changed')
        if not file.is_file() or not 0<file.stat().st_size<=49*1024*1024:raise ValueError('Missing complete audio')
        from audio_audit import inspect
        measured=inspect(file)
        if measured.get('audioAuditState')!='verified' or measured['audioDuration']<max(1,track.get('duration',0)-max(2,track.get('duration',0)*.02)):raise RuntimeError('Источник отдал неполное аудио; этот файл не отправлен.')
        atomic_json(completed,{'url':track['url'],'stamp':[file.stat().st_size,file.stat().st_mtime_ns],'sourceDuration':float(track.get('duration') or measured['audioDuration']),'audit':measured})
        return str(file)
    raise ValueError('Invalid action')

if __name__=='__main__':
    payload={}
    try:
        payload=json.loads(sys.stdin.read())
        print(json.dumps({'ok':True,'result':main(payload)},ensure_ascii=False))
    except Exception as e:print(json.dumps({'ok':False,'error':user_error(e,payload.get('provider') or payload.get('track',{}).get('source'))},ensure_ascii=False))
