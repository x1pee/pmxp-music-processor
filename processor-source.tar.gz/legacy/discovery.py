"""Bounded, cached discovery work runs independently of delivery and HTTP."""
import datetime,hashlib,json,re,time
from concurrent.futures import ThreadPoolExecutor,as_completed
from media import ROOT
from source import normalize_track,valid_url,version_quality
from taste import identity,preferences,artist_statistics,track_artists
from library import recording_key,clean_artist,listening_key
from work_cache import keyed_lock,atomic_json
from received_tracks import build_received_index,has_received,build_owned_index,has_owned,recording_facts

def _all_artists_blocked(track,blocked):
    keys={identity(a) for a in track_artists(track)}
    return bool(keys) and keys.issubset(blocked)

SEEDS=['Мумий Тролль','Дайте танк (!)','Моя Мишель','Cream Soda','Markul','Три дня дождя','Zoloto','Сироткин']
_executor=ThreadPoolExecutor(max_workers=2,thread_name_prefix='discovery-source')

def youtube_candidates(query,known,offset=0,timeout=25,artist_lookup=True):
    from external_sources import search
    return search(query,'YouTube',offset,timeout=timeout,artist_lookup=artist_lookup)

def valid_candidate(track):
    if track.get('source')=='YouTube':
        from external_sources import valid_external
        return valid_external(track)
    return valid_url(track.get('url',''))

def candidates(query,known,offset=0,timeout=25):
    # Store raw pages so different known-artist sets are normalized independently.
    key=hashlib.sha256(json.dumps([query,offset],ensure_ascii=False).encode()).hexdigest()
    folder=ROOT/'work/discovery-pages';path=folder/(key+'.json');page=None
    with keyed_lock(('discovery-search',key)):
        try:
            cached=json.loads(path.read_text(encoding='utf-8'))
            if cached.get('version')==1 and time.time()-cached['time']<(21600 if cached['page']['entries'] else 300):page=cached['page']
        except (OSError,ValueError,KeyError,TypeError):pass
        if page is None:
            from source_cli import search_independent
            page=search_independent(query,offset)
            atomic_json(path,{'version':1,'time':time.time(),'page':page})
    return {'tracks':[normalize_track(x,known) for x in page['entries']],'nextOffset':page.get('nextOffset')}

def ready_pages(find,selected,stream=False):
    if not stream:
        yield from zip(selected,_executor.map(find,selected));return
    futures={_executor.submit(find,item):item for item in selected}
    for future in as_completed(futures):yield futures[future],future.result()

def announce(callback,tracks,personalized=False,artists=(),explore=False,received=None,owned=None):
    if not callback or not tracks:return
    from tag_resolver import canonicalize
    try:
        tracks=[canonicalize(t) for t in tracks]
        if received is not None:tracks=[t for t in tracks if not has_received(t,received)]
        if owned is not None:tracks=[t for t in tracks if not has_owned(t,owned)]
        if not tracks:return
        callback({'tracks':tracks,'artists':list(artists)[:5],'personalized':personalized,
        'description':'Популярное сейчас, новинки и хиты разных лет · Россия и мир' if explore else 'По твоим скачиваниям и аудио из чата' if personalized else 'Новые исполнители и треки'})
    except Exception:pass  # Final completion remains authoritative after a lost partial response.

def heard_key(track):return listening_key({**track,'artist':', '.join(track_artists(track))})

def recommendation_keys(track):
    # Studio and a clearly labelled alternate edition cannot consume one
    # another's dedup slot. The ordinary keys retain the existing cursor shape.
    editions=tuple(sorted({edition for _,labels,_ in recording_facts(track) for edition in labels}))
    suffix='|edition:'+json.dumps(list(editions),ensure_ascii=False,separators=(',',':')) if editions else ''
    return recording_key(track)+suffix,heard_key(track)+suffix

def received_policy(rows,received):
    """Keep new compositions first; one marked repeat only for a sparse batch."""
    fresh=[];repeats=[]
    for row in rows:
        if has_received(row,received):repeats.append(row)
        else:fresh.append(row)
    if len(fresh)>=3:return fresh
    return fresh+[{**row,'receivedFallback':True,'recommendationPenalty':100} for row in repeats[:1]]

def build_feed(profile,tab,fetch=None,cursor=None,exclude=(),provider='SoundCloud',batch_size=None,on_partial=None,related_lookup=None,include_related=True):
    if provider not in ('SoundCloud','YouTube'):raise ValueError('Unsupported recommendation provider')
    source_fetch=fetch is None
    fetch=fetch or (youtube_candidates if provider=='YouTube' else candidates)
    if tab=='explore':return build_explore(profile,fetch,cursor,exclude,batch_size,on_partial)
    rows=profile.get('recommendationTracks',profile.get('tracks',[]));stats=profile.get('artistPreferences')
    if stats is None:stats=artist_statistics(rows)
    blocked=set(profile.get('excludedArtists',[]))
    stats=[a for a in stats if a.get('weight',0)>0 and identity(clean_artist(a.get('name',''))) not in blocked];artists=[clean_artist(a['name']) for a in stats]
    known=set(artists)|set(SEEDS)
    # Receipt provenance and composition identity are shared with cached pools.
    # Clicks/uncertain attempts cannot become an exclusion just by being history.
    received=build_received_index(profile);owned=build_owned_index(profile);seen=set(exclude)
    known_keys={identity(a) for a in artists}
    rotation=int(datetime.datetime.now(datetime.timezone.utc).strftime('%j'))%len(SEEDS)
    seeds=SEEDS[rotation:]+SEEDS[:rotation]
    allowed={}
    for a in stats[:15]:
        name=clean_artist(a['name']);key=identity(name)
        if key and key not in blocked:allowed[key]={'query':name,'kind':'familiar' if a.get('tracks',0) else 'moment','weight':max(.01,a['weight'])}
    if not artists:
        for name in seeds:
            key=identity(name)
            if key not in blocked and key not in profile.get('resetArtists',[]):allowed[key]={'query':name,'kind':'cold','weight':1}
    if related_lookup is None:
        if source_fetch and 'artistPreferences' in profile:
            from related_artists import get
            related_lookup=get
        else:related_lookup=lambda name:([],False)
    previous=cursor.get('queries',[]) if cursor and cursor.get('version') in (2,3) else []
    relation_pending=bool(cursor and cursor.get('relatedPending')) if not include_related else False
    # Pausing background discovery must not restart a related artist's offset
    # when it becomes useful again. Revalidate the saved anchor and exclusions.
    for q in previous:
        key=identity(clean_artist(q.get('query','')));anchor_key=identity(clean_artist(q.get('relatedTo','')))
        if q.get('kind')=='related' and q.get('recommendationSource') in {'YouTube Music','ListenBrainz'} and anchor_key in known_keys and anchor_key in allowed and key and key not in blocked and key not in known_keys:
            saved={k:q[k] for k in ('query','kind','relatedTo','recommendationSource','relatedScore') if k in q};saved['weight']=allowed[anchor_key]['weight']*.3*max(.2,min(1,q.get('relatedScore',.6)));allowed[key]=saved
    for anchor in stats[:3] if include_related else []:
        links,waiting=related_lookup(clean_artist(anchor['name']));relation_pending|=waiting
        for link in links[:16]:
            name=clean_artist(link.get('name',''));key=identity(name)
            if not key or key in blocked or key in known_keys or link.get('source') not in {'YouTube Music','ListenBrainz'}:continue
            weight=anchor['weight']*.3*max(.2,min(1,link.get('score',.6)));prior=allowed.get(key)
            if prior and prior['weight']>=weight:continue
            allowed[key]={'query':name,'kind':'related','relatedTo':clean_artist(anchor['name']),'recommendationSource':link['source'],'relatedScore':link.get('score',.6),'weight':weight}
    # Verified graph identities are known to this search, not yet favorites in
    # listening history. Without this, official related-artist uploads lacking
    # an explicit performer field were rejected as arbitrary uploaders.
    known.update(q['query'] for q in allowed.values())
    pending=[];used=set()
    for q in previous:
        key=identity(clean_artist(q.get('query','')))
        if key not in allowed or key in used:continue
        used.add(key);pending.append({**allowed[key],'offset':q.get('offset',0),'served':min(10000,max(0,q.get('served',0)))})
    pending.extend({**q,'offset':0,'served':0} for key,q in allowed.items() if key not in used)
    size=max(3,min(6,batch_size or 3));available=[i for i,q in enumerate(pending) if q['offset'] is not None and (include_related or q['kind']!='related')]
    priority=lambda i:pending[i]['weight']/(pending[i]['served']+1)
    familiar=sorted([i for i in available if pending[i]['kind']!='related'],key=priority,reverse=True)
    related=sorted([i for i in available if pending[i]['kind']=='related'],key=priority,reverse=True)
    selected=familiar[:size-min(1,len(related))]+related[:min(1,len(related))]
    if len(selected)<size:selected.extend(i for i in familiar+related if i not in selected and len(selected)<size)
    result=[];ids=set();buckets={i:[] for i in selected};successes=0
    def find(i):
        try:return fetch(pending[i]['query'],known,pending[i]['offset'])
        except Exception:return None
    for i,found in ready_pages(find,selected,on_partial is not None):
        query=pending[i]['query'];offset=pending[i]['offset'];pending[i]['served']+=1
        try:
            if found is None:raise RuntimeError('Provider unavailable')
            if isinstance(found,list):found={'tracks':found,'nextOffset':None}
            following=found.get('nextOffset')
            pending[i]['offset']=following if isinstance(following,int) and offset<following<=10000 else None
            successes+=1
        except Exception:
            continue
        bucket=[]
        for track in sorted(found['tracks'],key=version_quality):
            key,heard=recommendation_keys(track);artist_key=identity(track.get('artist',''))
            if not track.get('metadataConfirmed') or track.get('version') or has_owned(track,owned) or key in seen or heard in seen or track['id'] in ids or not valid_candidate(track) or not 0<track.get('duration',0)<=1080:continue
            # Never recommend a random uploader as a favourite artist.
            query_credits={identity(a) for a in track_artists({'artist':query,'metadataConfirmed':True})}
            track_credits={identity(a) for a in track_artists(track)}
            if track_credits and track_credits<=blocked:continue
            if tab=='personal' and artists and not query_credits.issubset(track_credits):continue
            if tab=='explore' and artist_key in known_keys:continue
            ids.add(track['id']);seen.add(key);seen.add(heard)
            kind=pending[i]['kind']
            reason=f'Похож на {pending[i]["relatedTo"]} · {pending[i]["recommendationSource"]}' if kind=='related' else f'По твоей истории: {query}' if kind=='familiar' else f'Понравились треки: {query}' if kind=='moment' else f'Другой исполнитель · запрос {query}'
            bucket.append({**track,'reason':reason,'recommendationKind':kind,**({k:pending[i][k] for k in ('relatedTo','recommendationSource','relatedScore')} if kind=='related' else {})})
        buckets[i]=bucket;announce(on_partial,bucket,bool(artists) and tab=='personal',artists,received=received,owned=owned)
    buckets=[buckets[i] for i in selected]
    # Round robin preserves variety instead of showing ten tracks by one artist.
    for index in range(max((len(b) for b in buckets),default=0)):
        for bucket in buckets:
            if index<len(bucket):result.append(bucket[index])
    following={'version':3,'queries':pending,'relatedPending':relation_pending,**({'retryAt':time.time()*1000+2000} if not selected and relation_pending else {})} if any(q['offset'] is not None for q in pending) or relation_pending else None
    from tag_resolver import canonicalize
    result=received_policy([t for row in result if not has_owned(t:=canonicalize(row),owned)],received)
    return {'tracks':result,'artists':artists[:5],'personalized':bool(artists) and tab=='personal','cursor':following,'feedVersion':3,
        'unavailable':bool(selected) and successes==0,
        'description':'По твоим скачиваниям и аудио из чата' if artists and tab=='personal' else 'Новые исполнители и треки'}

def build_explore(profile,fetch=candidates,cursor=None,exclude=(),batch_size=None,on_partial=None):
    from charts import targets
    from alternatives import same_recording
    from tag_resolver import canonicalize
    received=build_received_index(profile);owned=build_owned_index(profile)
    state=cursor if cursor and cursor.get('version')==4 else {'version':4,'targets':targets(),'index':0}
    blocked=set(profile.get('excludedArtists',[]))
    if state.get('stage')=='artists':return explore_artists(state,fetch,exclude,batch_size,on_partial,blocked,received,owned)
    pool=state['targets'];index=state['index'];result=[];counts={};seen=set(exclude);successes=0;selected=[]
    while index<len(pool) and len(selected)<max(4,min(12,batch_size or 4)):
        target=pool[index];index+=1
        if _all_artists_blocked({**target,'metadataConfirmed':True},blocked):continue
        if target['artist'] in counts:continue
        counts[target['artist']]=1;selected.append(target)
    def find(target):
        known={target['artist'],*re.split(r'\s*,\s*',target['artist'])}
        try:
            if fetch is youtube_candidates:return fetch(target['artist']+' '+target['title'],known,0,timeout=12,artist_lookup=False)
            return fetch(target['artist']+' '+target['title'],known,0,timeout=12) if fetch is candidates else fetch(target['artist']+' '+target['title'],known,0)
        except Exception:return None
    # Exact chart songs, never arbitrary tracks from a fixed artist search.
    for target,page in ready_pages(find,selected,on_partial is not None):
        if page is None:continue
        successes+=1
        if isinstance(page,list):page={'tracks':page}
        matches=[t for t in page['tracks'] if t.get('metadataConfirmed') and not t.get('version') and not has_owned(t,owned) and valid_candidate(t) and 0<t.get('duration',0)<=1080 and same_recording(target,t) and not any(key in seen for key in recommendation_keys(t))]
        matches.sort(key=lambda t:abs(t['duration']-target.get('referenceDuration',t['duration'])))
        if not matches:continue
        t=canonicalize(matches[0]);seen.update(recommendation_keys(t));counts[target['artist']]=1
        if has_owned(t,owned):continue
        row={**t,'reason':target['label']+' · Apple Music'};result.append(row)
        announce(on_partial,[row],explore=True,received=received,owned=owned)
    if selected and not successes:index=state['index']
    following={**state,'index':index} if index<len(pool) else artist_cursor([t for t in pool if not _all_artists_blocked({**t,'metadataConfirmed':True},blocked)])
    return explore_result(received_policy(result,received),following,bool(selected) and successes==0)

def artist_cursor(pool):
    artists=list(dict.fromkeys(t['artist'] for t in pool))
    return {'version':4,'stage':'artists','queries':[{'query':a,'offset':0} for a in artists],'round':0} if artists else None

def explore_result(rows,cursor,unavailable=False):
    return {'tracks':rows,'artists':[],'personalized':False,'cursor':cursor,'feedVersion':4,'unavailable':unavailable,
            'description':'Популярное сейчас, новинки и хиты разных лет · Россия и мир'}

def explore_artists(state,fetch,exclude,batch_size=None,on_partial=None,blocked=(),received=None,owned=None):
    """Continue with real paginated catalogues of chart artists, without inventing chart ranks."""
    from tag_resolver import canonicalize
    received=build_received_index({}) if received is None else received
    owned=build_owned_index({}) if owned is None else owned
    blocked=set(blocked);pending=[dict(q) for q in state['queries']];start=state.get('round',0)%max(1,len(pending))
    for q in pending:
        if _all_artists_blocked({'artist':q['query'],'metadataConfirmed':True},blocked):q['offset']=None
    order=list(range(start,len(pending)))+list(range(start));selected=[i for i in order if pending[i]['offset'] is not None][:max(3,min(6,batch_size or 3))]
    def find(i):
        q=pending[i];known={q['query'],*re.split(r'\s*,\s*',q['query'])}
        try:return fetch(q['query'],known,q['offset'])
        except Exception:return None
    buckets={i:[] for i in selected};seen=set(exclude);ids=set();successes=0
    for i,page in ready_pages(find,selected,on_partial is not None):
        bucket=[];buckets[i]=bucket
        if page is None:continue
        successes+=1
        if isinstance(page,list):page={'tracks':page,'nextOffset':None}
        q=pending[i];following=page.get('nextOffset');q['offset']=following if isinstance(following,int) and q['offset']<following<=10000 else None
        credits={identity(a) for a in re.split(r'\s*,\s*',q['query']) if a}
        for row in page['tracks']:
            row_credits={identity(a) for a in track_artists(row)}
            keys=recommendation_keys(row)
            if not row.get('metadataConfirmed') or row.get('version') or has_owned(row,owned) or not credits.issubset(row_credits) or (bool(row_credits) and row_credits<=blocked) or any(key in seen for key in keys) or row['id'] in ids or not valid_candidate(row) or not 0<row.get('duration',0)<=1080:continue
            fixed=canonicalize(row)
            if has_owned(fixed,owned):continue
            seen.update(keys);ids.add(row['id']);bucket.append({**fixed,'reason':'Ещё у исполнителя · '+q['query']})
        announce(on_partial,bucket,explore=True,received=received,owned=owned)
    buckets=[buckets[i] for i in selected]
    rows=[b[i] for i in range(max((len(b) for b in buckets),default=0)) for b in buckets if i<len(b)]
    following={**state,'queries':pending,'round':(selected[-1]+1) if selected else 0} if any(q['offset'] is not None for q in pending) else None
    return explore_result(received_policy(rows,received),following,bool(selected) and successes==0)
