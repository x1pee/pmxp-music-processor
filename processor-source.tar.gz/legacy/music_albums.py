"""YouTube Music releases, not community playlists; bounded public browse IDs."""
import re,threading,urllib.parse
from library import clean,clean_artist,clean_title
from music_catalogue import nodes
from external_sources import music_cover,normalize

_local=threading.local()
ID=re.compile(r'MPREb_[\w-]{5,100}')

def context():
    ie=getattr(_local,'ie',None)
    if ie is None:
        import yt_dlp
        from yt_dlp.extractor.youtube._search import YoutubeMusicSearchURLIE
        from source_cli import Quiet
        y=yt_dlp.YoutubeDL({'quiet':True,'logger':Quiet(),'socket_timeout':4,'retries':0,'extractor_retries':0,'cachedir':False,'extract_flat':True,'skip_download':True},auto_init=False)
        y.add_info_extractor(YoutubeMusicSearchURLIE(y));ie=y.get_info_extractor(YoutubeMusicSearchURLIE.ie_key())
        _local.ie=ie;_local.y=y
    return ie

def response(ep,query,ident):
    return context()._extract_response(item_id=ident,ep=ep,query=query,default_client='web_music')

def text(value):
    return clean(''.join(r.get('text','') for r in value.get('runs',[])) or value.get('simpleText',''))

def credits(value):
    found=[]
    for run in nodes(value,{'runs'}):
        for r in run:
            browse=r.get('navigationEndpoint',{}).get('browseEndpoint',{})
            if re.fullmatch(r'UC[\w-]{22}',browse.get('browseId','')) and r.get('text') and r['text'] not in found:found.append(r['text'])
    return clean_artist(', '.join(found))

def thumbnail(value):
    for item in nodes(value,{'musicThumbnailRenderer'}):
        cover=music_cover({'thumbnail':{'musicThumbnailRenderer':item}})
        if cover:return cover
    return ''

def album_row(renderer):
    endpoint=renderer.get('navigationEndpoint',{}).get('browseEndpoint',{})
    ident=endpoint.get('browseId','')
    if not ID.fullmatch(ident):return None
    title=text(renderer.get('title',{}))
    if not title:
        columns=renderer.get('flexColumns',[])
        if columns:title=text(columns[0].get('musicResponsiveListItemFlexColumnRenderer',{}).get('text',{}))
    artist=credits(renderer)
    if not title or not artist:return None
    return {'id':'yt-album-'+ident,'title':title[:200],'artist':artist[:100],'cover':thumbnail(renderer),'trackCount':None,'source':'YouTube','sourceLabel':'YouTube Music','kind':'album'}

def parse_search(data):
    rows=[];seen=set()
    for renderer in nodes(data,{'musicResponsiveListItemRenderer','musicTwoRowItemRenderer'}):
        row=album_row(renderer)
        if row and row['id'] not in seen:rows.append(row);seen.add(row['id'])
    shelves=list(nodes(data,{'musicShelfRenderer','musicShelfContinuation','musicGridRenderer','gridContinuation'}))
    token=next((context()._extract_continuation(s) for s in shelves if context()._extract_continuation(s)),None)
    return {'rows':rows,'continuation':token}

def search_albums(query,offset=0,first_page=False):
    from albums import cached
    if offset>=200:return {'tracks':[],'albums':[],'nextOffset':None,'providerState':'empty'}
    key='youtube-albums-v1:'+query.casefold()
    page=cached(key,lambda:parse_search(response('search',{'query':query,'params':context()._SECTIONS['albums']},query)))
    rows=list(page['rows']);seen={r['id'] for r in rows};token=page.get('continuation');visited=set()
    for _ in range(8):
        # Do not fetch an extra page just to discover whether "more" exists.
        # The continuation already answers that; keep fixed ten-row offsets.
        if first_page or len(rows)>=offset+10 or not token:break
        marker=str(token)
        if marker in visited:token=None;break
        visited.add(marker)
        page=cached(key+':'+marker,lambda:parse_search(response('search',token,query)))
        for row in page['rows']:
            if row['id'] not in seen:rows.append(row);seen.add(row['id'])
        token=page.get('continuation')
    selected=rows[offset:offset+10]
    return {'tracks':[],'albums':selected,'nextOffset':offset+10 if selected and (offset+10<len(rows) or token) else None,'providerState':'ok' if selected else 'empty'}

def header(data,ident):
    values=list(nodes(data,{'musicResponsiveHeaderRenderer','musicDetailHeaderRenderer'}))
    value=values[0] if values else {}
    title=text(value.get('title',{}));artist=credits(value)
    if not title or not artist:raise RuntimeError('YouTube Music не подтвердил данные альбома.')
    return {'id':'yt-album-'+ident,'title':title[:200],'artist':artist[:100],'cover':thumbnail(value),'trackCount':0,'source':'YouTube','sourceLabel':'YouTube Music','kind':'album'}

def duration(renderer):
    for column in renderer.get('fixedColumns',[]):
        value=text(column.get('musicResponsiveListItemFixedColumnRenderer',{}).get('text',{}))
        if re.fullmatch(r'\d{1,2}:\d{2}(?::\d{2})?',value):
            total=0
            for n in value.split(':'):total=total*60+int(n)
            return total
    return 0

def page_entries(data):
    shelves=[s for s in nodes(data,{'musicPlaylistShelfRenderer','musicPlaylistShelfContinuation','musicShelfRenderer','musicShelfContinuation'}) if any(x.get('musicResponsiveListItemRenderer',{}).get('playlistItemData',{}).get('videoId') for x in s.get('contents',[]))]
    if not shelves:return [],None
    shelf=shelves[0]
    return [x['musicResponsiveListItemRenderer'] for x in shelf.get('contents',[]) if 'musicResponsiveListItemRenderer' in x],context()._extract_continuation(shelf)

def album_first_page(raw_id):
    from albums import cached
    if not ID.fullmatch(raw_id):raise ValueError('Invalid music album ID')
    def fetch():
        data=response('browse',{'browseId':raw_id},raw_id);album=header(data,raw_id);entries,token=page_entries(data)
        return {'album':album,'entries':entries,'continuation':token}
    return cached('youtube-album-first-v1:'+raw_id,fetch,21600)

def album_membership(track):
    ident=track.get('albumId','');video=track.get('id','').removeprefix('yt-')
    if track.get('source')!='YouTube' or not ident.startswith('yt-album-') or not ID.fullmatch(ident.removeprefix('yt-album-')) or not re.fullmatch(r'[\w-]{11}',video):return None
    first=album_first_page(ident.removeprefix('yt-album-'))
    for row in first['entries']:
        columns=row.get('flexColumns',[])
        title=text(columns[0].get('musicResponsiveListItemFlexColumnRenderer',{}).get('text',{})) if columns else ''
        if row.get('playlistItemData',{}).get('videoId')==video and row.get('isPlayable') is not False and title and 0<duration(row)<=1080:
            return {**first['album'],'trackCount':None if first['continuation'] else len(first['entries'])}
    if first['continuation']:
        opened=open_album(ident)
        if any(t.get('id')==track['id'] and t.get('source')=='YouTube' for t in opened['tracks']):return opened['album']
    return None

def open_album(ident):
    from albums import cached
    raw_id=ident.removeprefix('yt-album-')
    if not ID.fullmatch(raw_id):raise ValueError('Invalid music album ID')
    def fetch():
        first=album_first_page(raw_id);album=first['album'];entries=list(first['entries']);token=first['continuation'];visited=set()
        for _ in range(7):
            if not token or len(entries)>=200:break
            marker=str(token)
            if marker in visited:token=None;break
            visited.add(marker)
            part,token=page_entries(response('browse',token,raw_id));entries.extend(part)
        if not entries:raise RuntimeError('YouTube Music не вернул доступный список треков альбома.')
        return {'album':album,'entries':entries[:200],'truncated':bool(token) or len(entries)>200}
    saved=cached('youtube-album-detail-v2:'+raw_id,fetch,21600);album=dict(saved['album']);rows=[];seen=set()
    for pos,r in enumerate(saved['entries']):
        video=r.get('playlistItemData',{}).get('videoId') or r.get('navigationEndpoint',{}).get('watchEndpoint',{}).get('videoId','')
        if not re.fullmatch(r'[\w-]{11}',video) or video in seen or r.get('isPlayable') is False:continue
        columns=r.get('flexColumns',[]);title=text(columns[0].get('musicResponsiveListItemFlexColumnRenderer',{}).get('text',{})) if columns else ''
        seconds=duration(r)
        if not title or not 0<seconds<=1080:continue
        seen.add(video);artist=credits(r) or album['artist']
        row=normalize({'id':video,'track':title,'artist':artist,'duration':seconds,'_pmx_music_song':True,'_pmx_music_cover':thumbnail(r) or album['cover']},'YouTube')
        rows.append({**row,'albumTitle':album['title'],'albumId':album['id'],'albumPosition':pos+1})
    album['trackCount']=len(saved['entries'])
    return {'tracks':rows,'albums':[],'album':album,'nextOffset':None,'unavailableCount':len(saved['entries'])-len(rows),'truncated':saved['truncated'],'metadataVersion':11,'providerState':'ok' if rows else 'empty'}


def recording_art(track):
    ident=track.get('albumId','')
    if track.get('source')!='YouTube' or not re.fullmatch(r'yt-album-MPREb_[\w-]{5,100}',ident):return {}
    album=album_membership(track)
    if not album:return {}
    cover=album.get('cover','')
    # Album catalogue artwork only; never manufacture it by cropping a video.
    url=urllib.parse.urlsplit(cover)
    if url.scheme!='https' or url.hostname not in {'yt3.googleusercontent.com','lh3.googleusercontent.com'} or url.username or url.password or url.port not in (None,443):return {}
    return {'catalogueCover':cover,'coverProvider':'YouTube Music','catalogueAlbum':album['title'],'catalogueAlbumId':ident}
