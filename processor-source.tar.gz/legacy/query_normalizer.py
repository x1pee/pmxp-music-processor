"""Shared, evidence-based artist spelling and keyboard-layout matching."""
import json,re,time,unicodedata
from difflib import SequenceMatcher
from media import ROOT
from work_cache import atomic_json,keyed_lock
CYR='йцукенгшщзхъфывапролджэячсмитьбю'
LAT="qwertyuiop[]asdfghjkl;'zxcvbnm,."
TRANSLIT=dict(zip('абвгдеёзийклмнопрстуфхцчшщъыьэюя',('a','b','v','g','d','e','e','z','i','i','k','l','m','n','o','p','r','s','t','u','f','h','ts','ch','sh','sch','','y','','e','yu','ya')))
def translit(value):return ''.join(TRANSLIT.get(c,c) for c in value.casefold())
def key(value):
    text=unicodedata.normalize('NFKC',value).casefold().replace('ё','е')
    ident=''.join(c for c in text if unicodedata.category(c)[0] in 'LNM')
    return ident if any(unicodedata.category(c)[0] in 'LN' for c in ident) else ''
def phonetic(value):
    s=translit(value).replace('ph','f').replace('ck','k').replace('qu','k').replace('c','k').replace('q','k').replace('w','v')
    return re.sub(r'[aeiouy\W]','',s)
def variants(value):
    rows=[value]
    if re.search('[а-яё]',value,re.I):rows.extend([value.casefold().translate(str.maketrans(CYR,LAT)),translit(value)])
    elif re.search('[a-z]',value,re.I):rows.append(value.casefold().translate(str.maketrans(LAT,CYR)))
    return list(dict.fromkeys(rows))
def artist_matches(query,name):
    query_key,name_key=key(query),key(name)
    if not query_key or not name_key:return False
    if query_key==name_key:return True
    if len(query_key)<6:return False
    for candidate in variants(query):
        candidate_key=key(candidate)
        translated_key,translated_name=key(translit(candidate)),key(translit(name))
        if (candidate_key and candidate_key==name_key) or (translated_key and translated_name and translated_key==translated_name):return True
        # Only a complete name, never arbitrary fuzzy words or a song suffix.
        # Keyboard/transliteration evidence is defined only for RU/EN.
        # Other scripts' combining marks must not disappear in phonetic guesses.
        supported=bool(re.fullmatch(r'[a-z0-9а-я]+',key(candidate)) and re.fullmatch(r'[a-z0-9а-я]+',name_key))
        if supported and len(phonetic(candidate))>=6 and phonetic(candidate)==phonetic(name):return True
        layout=query.casefold().translate(str.maketrans(CYR,LAT))
        if supported and candidate==layout and re.search('[а-яё]',query,re.I) and len(key(name))>=10 and len(query.split())==len(name.split()) and SequenceMatcher(None,key(candidate),key(name)).ratio()>=.84 and SequenceMatcher(None,phonetic(candidate),phonetic(name)).ratio()>=.86:return True
    return False
def remembered():
    try:return json.loads((ROOT/'work/query-artists.json').read_text(encoding='utf-8'))
    except (OSError,ValueError):return {}
def remember_artist(query,name):
    query_key=key(query)
    if not query_key:return
    with keyed_lock('query-artists'):
        data=remembered();data[query_key]={'name':name,'time':time.time()}
        data=dict(sorted(data.items(),key=lambda pair:pair[1]['time'],reverse=True)[:500]);atomic_json(ROOT/'work/query-artists.json',data)
def resolve_known(query,known=()):
    query_key=key(query)
    if not query_key:return query
    saved=remembered().get(query_key)
    if saved and time.time()-saved.get('time',0)<30*86400:return saved['name']
    matches=[n for n in known if artist_matches(query,n)]
    if len(set(matches))==1:return matches[0]
    # Exact spelling prefixes retain the track title; translit comparisons above
    # deliberately require the full artist name to avoid swallowing song words.
    for name in sorted(known,key=len,reverse=True):
        for variant in variants(query):
            if variant.casefold().startswith(name.casefold()+' '):return name+variant[len(name):]
    return query
