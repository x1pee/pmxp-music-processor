"""Find another upload of a confirmed recording; do not infer audio speed."""
import time
from audio_audit import comparison_duration,duration_tolerance
from audio_quality import inspect_track,no_technical_downgrade
from library import recording_key,clean_track_tags
from source import track_version,valid_url

def same_recording(a,b):return recording_key(clean_track_tags(a))==recording_key(clean_track_tags(b))

def find_alternative(track,fetch=None,inspect_audio=None):
    if track.get('catalogueState')!='verified' or not track.get('referenceDuration') or track.get('version') or track_version(track.get('original','')):
        raise RuntimeError('Для этого трека нет подтверждённой длительности обычной версии.')
    if fetch is None:
        from discovery import candidates
        fetch=candidates
    inspect_audio=inspect_audio or inspect_track
    reference=float(track['referenceDuration']);found=[];deadline=time.monotonic()+30
    offset=0;exhausted=False;scanned=0;checked=0;uncertain=False;seen=set()
    def result():
        return {'tracks':found[:1],'notFound':not found,'alternativeState':'found' if found else 'not-found' if exhausted and not uncertain else 'incomplete','scanned':scanned,'metadataVersion':9,'alternativeVersion':2,'nextOffset':None}
    try:original=inspect_audio(track,timeout=8)
    except Exception:uncertain=True;return result()
    original_duration=comparison_duration(original,reference=reference);original_gap=abs(original_duration-reference)
    if original_gap<=duration_tolerance(track):exhausted=True;return result()
    # Reuse discovery's cached pages; a valid version may be below the first ten hits.
    for _ in range(3):
        if time.monotonic()>=deadline:break
        page=fetch(track['artist']+' '+track['title'],{track['artist']},offset)
        # Inspect nearest metadata candidates first, before expensive downloads.
        ordered=sorted(page['tracks'],key=lambda row:abs(comparison_duration(row,reference=reference)-reference))
        for row in ordered:
            scanned+=1
            ident=(row.get('source'),row.get('id'))
            if ident in seen:continue
            seen.add(ident)
            if row['id']==track['id'] or row.get('version') or track_version(row.get('original','')) or not row.get('metadataConfirmed') or not valid_url(row.get('url','')) or not same_recording(track,row) or abs(comparison_duration(row,reference=reference)-reference)>2.5:continue
            if checked>=3 or deadline-time.monotonic()<5:uncertain=True;continue
            checked+=1
            try:candidate=inspect_audio(row,timeout=min(8,max(.1,deadline-time.monotonic()-5)))
            except Exception:uncertain=True;continue
            duration=comparison_duration(candidate,reference=reference);gap=abs(duration-reference)
            if gap>2.5 or original_gap-gap<2 or abs(duration-original_duration)<2 or not no_technical_downgrade(original,candidate):continue
            found.append({**candidate,'referenceDuration':reference,'durationDelta':round(duration-reference,2),'referenceProvider':track.get('referenceProvider'),'catalogueState':'verified','catalogueCheckedAt':track.get('catalogueCheckedAt')})
            # Identity, measured duration and technical quality all passed.
            # One replacement satisfies the request; don't download two extras.
            return result()
        following=page.get('nextOffset')
        if found:break
        if following is None:exhausted=True;break
        if not isinstance(following,int) or not offset<following<=10000:break
        offset=following
    found.sort(key=lambda t:(t.get('audioAuditState')!='verified',abs(t['durationDelta'])))
    return result()
