from runtime_security import run as private_run, popen as private_popen
"""Compare measured files conservatively; bitrate is not an audible-quality score."""
import re,subprocess,threading,time
from pathlib import Path
from collections import OrderedDict
from audio_audit import analyze
from media import ffmpeg_path
from media_security import local_input
from work_cache import keyed_lock

_quality=OrderedDict()
_quality_guard=threading.Lock()

def file_stamp(path):
    stat=path.stat()
    return (stat.st_dev,stat.st_ino,stat.st_size,stat.st_mtime_ns,stat.st_ctime_ns)

def measured_quality(path):
    if path.is_symlink() or not path.is_file():raise ValueError('Not a local audio file')
    args=local_input(path);stamp=file_stamp(path);key=(str(path.resolve()),stamp)
    with keyed_lock(('audio-quality',key)):
        with _quality_guard:
            saved=_quality.get(key)
            if saved and time.monotonic()-saved[0]<600:
                _quality.move_to_end(key);return dict(saved[1])
        run=private_run([ffmpeg_path(),'-hide_banner','-nostdin','-threads','1',*args],capture_output=True,timeout=3)
        line=next((s for s in run.stderr.decode(errors='replace').splitlines() if 'Audio:' in s),'')
        codec=re.search(r'Audio:\s*([\w]+)',line);rate=re.search(r'(\d+) Hz',line);bitrate=re.search(r'(\d+(?:\.\d+)?) kb/s',line)
        channels=2 if re.search(r'\bstereo\b',line) else 1 if re.search(r'\bmono\b',line) else 0
        if not all((codec,rate,bitrate,channels)):raise ValueError('Audio quality unavailable')
        if path.is_symlink() or file_stamp(path)!=stamp:raise ValueError('Audio file changed during probe')
        value={'codec':codec[1],'sampleRate':int(rate[1]),'channels':channels,'bitrate':float(bitrate[1])}
        with _quality_guard:
            _quality[key]=(time.monotonic(),value);_quality.move_to_end(key)
            while len(_quality)>64:_quality.popitem(last=False)
        return dict(value)

def inspect_track(track,timeout=8):
    from source import download_track
    path=Path(download_track(track,timeout=timeout))
    audit=analyze(track,path)
    if audit.get('audioAuditState')!='verified':raise ValueError('Audio duration unavailable')
    return {**track,**audit,'audioQuality':measured_quality(path)}

def no_technical_downgrade(original,candidate):
    a=original.get('audioQuality',{});b=candidate.get('audioQuality',{})
    # Different codecs cannot be ranked by file size or bitrate alone.
    return bool(a and b and a.get('codec')==b.get('codec') and b.get('sampleRate',0)>=a.get('sampleRate',0) and b.get('channels',0)>=a.get('channels',0) and b.get('bitrate',0)>=a.get('bitrate',0)*.95)
