"""Edition labels are metadata; only audio alterations affect source filtering."""
import re

_audio=[
 ('Nightcore',r'\bnight?core\b'),
 ('Sped up',r'\b(?:sped[\s_-]*up|speed[\s_-]*(?:up|songs?)|sped[\s_-]*songs?|ускор\w*)\b'),
 ('Slowed',r'\b(?:slowed|замедл\w*)\b'),
 ('Reverb',r'\breverb\b'),
 ('Remix',r'\b(?:remix|ремикс\w*)\b'),
 ('Bass boosted',r'\bbass[\s_-]*boost(?:ed)?\b'),
 ('Pitch',r'\bpitch(?:ed)?\b'),
 ('8D',r'\b8d\b')]
_editions=[('Acoustic',r'acoustic(?:\s+(?:version|ver\.?))?'),('Live',r'live(?:[\s_-]+(?:session|version|ver\.?))?'),('Snippet',r'snippet'),('Без цензуры',r'без\s+цензуры|uncensored|explicit')]

def audio_version(title):
 found=[(m.start(),label) for label,pattern in _audio for m in re.finditer(pattern,str(title),re.I)]
 return min(found,key=lambda item:item[0])[1] if found else ''

def version_labels(title):
 value=str(title);found=[(m.start(),label) for label,pattern in _audio for m in re.finditer(pattern,value,re.I)]
 for label,pattern in _editions:
  for m in re.finditer(r'[\[(]\s*(?:'+pattern+r')\s*[\])]|\s+[-—–]\s*(?:'+pattern+r')\s*$',value,re.I):found.append((m.start(),label))
 for m in re.finditer(r'[\[(]\s*площадки\s*[\])]',value,re.I):found.append((m.start(),'Площадки'))
 # Legacy public titles also use an unbracketed trailing LIVE marker.
 for m in re.finditer(r'\s+(?:LIVE|live[\s_-]+session)\s*$',value,re.I):found.append((m.start(),'Live'))
 return list(dict.fromkeys(label for _,label in sorted(found,key=lambda item:item[0])))

def clean_edition_bracket(text):
 value=text.strip()
 if re.fullmatch(r'без\s+цензуры|uncensored|explicit',value,re.I):return ''
 if re.fullmatch(r'night?core',value,re.I):return 'Nightcore'
 if re.fullmatch(r'(?:speed[\s_-]*songs?|sped[\s_-]*songs?)',value,re.I):return 'Sped up'
 if re.fullmatch(r'live[\s_-]+session',value,re.I):return 'Live'
 if re.fullmatch(r'площадки',value,re.I):return ''
 return value
