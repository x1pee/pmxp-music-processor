"""Reuse a private forwarded original, converting only when requested."""
import hashlib,threading,re,secrets,json
from bot_media_cache import same_bot,archive_file
from media import ROOT,convert_audio,safe_name,telegram_audio_details,download_cover
from extended_tags import optional_fields
from delivery import prepare_slots,cache_lock,track_locks
from silence_trim import trim_plan,trim_percent

def send_uploaded(api,owner,track,fmt,stage):
    if fmt not in {'mp3','m4a'} or not re.fullmatch(r'tg-[a-f0-9]{24}',str(track.get('id',''))) or track.get('format') not in {'mp3','m4a','aac','ogg','opus','flac','wav'}:raise ValueError('Invalid imported audio')
    local=archive_file(track)
    if not local and not (track.get('file_id') and same_bot(track,api)):raise ValueError('Imported audio unavailable')
    with cache_lock:lock=track_locks.setdefault(track['id']+':'+fmt,threading.Lock())
    with lock,prepare_slots:
        fields={'chat_id':owner,'title':track['title'],'performer':track['artist'],'disable_notification':True}
        percent=trim_percent(track.get('trimPercent',0))
        if fmt==track.get('format') and not track.get('manualTags') and not percent and track.get('file_id') and same_bot(track,api):
            stage('cached-send');fields['audio']=track['file_id'];result=api.call('sendAudio',fields)
            return {'message_id':result['message_id'],'cached':True}
        original=local or ROOT/'work'/(track['id']+'-original.'+track['format'])
        if original.is_symlink():raise ValueError('Invalid imported audio path')
        if not original.is_file():
            if not track.get('file_id') or not same_bot(track,api):raise ValueError('Imported audio unavailable')
            temporary=original.with_name(original.stem+'-'+secrets.token_hex(6)+original.suffix)
            try:
                stage('download');api.download(track['file_id'],temporary)
                temporary.replace(original)
            finally:temporary.unlink(missing_ok=True)
        trim=trim_plan(original,percent) if percent else None
        manual=track.get('manualTags') if isinstance(track.get('manualTags'),dict) else {}
        tags=hashlib.sha256(json.dumps([track['artist'],track['title'],manual,percent],sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()[:12]
        output=original if fmt==track.get('format') and not track.get('manualTags') and not percent else ROOT/'work'/(track['id']+'-'+tags+'.'+fmt)
        if not output.is_file():
            # A failed encoder may leave playable but incomplete bytes. Only
            # publish successful output; the next request must retry failures.
            temporary=output.with_name(output.stem+'-'+secrets.token_hex(6)+output.suffix)
            cover=None;cover_temporary=None
            try:
                if manual.get('coverMode')!='original' and manual.get('coverUrl'):
                    cover_temporary=ROOT/'work'/('tg-cover-'+secrets.token_hex(6)+'.jpg')
                    stage('cover');cover=download_cover(manual['coverUrl'],cover_temporary)
                extra=optional_fields(track)
                stage('convert');convert_audio(original,temporary,track['artist'],track['title'],cover,not track.get('manualTags'),trim.get('endAt') if trim else None,**({'extra_tags':extra} if extra else {}))
                temporary.replace(output)
            finally:
                temporary.unlink(missing_ok=True)
                if cover_temporary:cover_temporary.unlink(missing_ok=True)
        if output.stat().st_size>49*1024*1024:raise RuntimeError('Файл слишком большой для Telegram.')
        duration,thumb=telegram_audio_details(output,ROOT/'work'/(track['id']+'-thumbnail.jpg'))
        fields['duration']=duration;files={'audio':(output,safe_name(track['artist'],track['title'])+'.'+fmt)}
        if thumb:files['thumbnail']=thumb
        stage('upload');result=api.call('sendAudio',fields,files)
        return {'message_id':result['message_id'],'duration':duration,'cached':False,'trimFacts':trim}
