"""Background catalogue verification never blocks search or an audio send."""
import hashlib,json,math,os,queue,re,threading,time,urllib.parse,urllib.request
from difflib import SequenceMatcher
from media import ROOT
from library import clean,clean_title,clean_artist,clean_track_tags,recording_key
import credit_order
from catalogue_art import artwork,safe_reference,genius_lookup,artist_profile,source_artist,preferred_artist_spelling,localized_catalogue_rows
from work_cache import keyed_lock,atomic_json

_lock=threading.RLock();_pending=queue.Queue(64);_queued=set();_cache={};_enabled=False
_provider_locks={p:threading.Lock() for p in ('Apple Music','MusicBrainz','Genius')};_provider_next={}
_known_catalogue_stamp=None;_known_catalogue_names=()

def _known_artists():
    """Reuse the source search's local artist roster; never fetch on this path."""
    global _known_catalogue_stamp,_known_catalogue_names
    path=ROOT/'catalog/catalog.json';limit=4*1024*1024
    try:
        info=path.stat()
        if info.st_size>limit:return ()
        stamp=(str(path),info.st_ino,info.st_mtime_ns,info.st_ctime_ns,info.st_size)
        with _lock:
            if stamp==_known_catalogue_stamp:return _known_catalogue_names
            with path.open('rb') as file:raw=file.read(limit+1)
            if len(raw)>limit:return ()
            rows=json.loads(raw)
            if not isinstance(rows,list) or len(rows)>10000:return ()
            names=tuple(dict.fromkeys(row['artist'] for row in rows if isinstance(row,dict) and isinstance(row.get('artist'),str) and 0<len(row['artist'])<=100 and row.get('metadataConfirmed') is not False))
            _known_catalogue_stamp=stamp;_known_catalogue_names=names
            return names
    except (OSError,ValueError):return ()

def catalogue_request(url,provider):
    # Share catalogue metadata across reuploads and providers. Each track still
    # gets its own identity/edit/duration verification against these raw rows.
    key=hashlib.sha256((provider+':'+url).encode()).hexdigest()
    folder=ROOT/'work/catalogue-pages';path=folder/(key+'.json')
    with keyed_lock(('catalogue',key)):
        try:
            saved=json.loads(path.read_text(encoding='utf-8'))
            if time.time()-saved['time']<21600 and isinstance(saved['data'],dict):return saved['data']
        except (OSError,ValueError,KeyError,TypeError):pass
        data=_catalogue_fetch(url,provider)
        if not isinstance(data,dict):raise ValueError('Invalid catalogue response')
        atomic_json(path,{'time':time.time(),'data':data})
        try:
            paths=list(folder.glob('*.json'))
            if len(paths)>512:
                for old in sorted(paths,key=lambda p:p.stat().st_mtime)[:len(paths)-512]:old.unlink(missing_ok=True)
        except OSError:pass  # Another resolver may prune the same old entry.
        return data

def _catalogue_fetch(url,provider):
    with _provider_locks[provider]:
        time.sleep(max(0,_provider_next.get(provider,0)-time.monotonic()))
        _provider_next[provider]=time.monotonic()+(3.1 if provider=='Apple Music' else 1.1)
    req=urllib.request.Request(url,headers={'User-Agent':'PMXP-MusicBot/0.3 (https://pmxp.fun)'})
    with urllib.request.urlopen(req,timeout=4) as response:
        data=response.read(1024*1024+1)
        if len(data)>1024*1024:raise ValueError('Metadata response too large')
        return json.loads(data)

TAG_SCHEMA_VERSION=13

def signature(track,version=TAG_SCHEMA_VERSION):
    identity=json.dumps([track.get('source'),track.get('id'),track.get('original'),track.get('originalArtist')],ensure_ascii=False) if track.get('original') else recording_key(track)
    return hashlib.sha256(('v'+str(version)+':'+identity+':'+format(float(track.get('duration',0)),'.2f')).encode()).hexdigest()

def base_title(title):
    return re.sub(r'\s*[\[(]\s*(?:slowed(?:\s*\+\s*reverb)?|slow|speed\s*up|sped\s*up|night?core)\s*[\])]','',clean_title(title),flags=re.I).strip()

def verify(track,rows,provider='Apple Music'):
    # A matching title alone must never replace the performer of another song.
    track=clean_track_tags({**track,'metadataConfirmed':True});candidates=[]
    for row in rows:
        tags=clean_track_tags({'artist':row.get('artistName',''),'title':row.get('trackName',''),'metadataConfirmed':True})
        artist=tags['artist'];title=tags['title']
        if not artist or not title or row.get('wrapperType')!='track':continue
        wanted=recording_key({'artist':track['artist'],'title':'_' }).split(':',1)[0]
        found=recording_key({'artist':artist,'title':'_'}).split(':',1)[0]
        if wanted!=found:continue
        a=recording_key({'artist':'_','title':base_title(track['title'])}).split(':',1)[1]
        b=recording_key({'artist':'_','title':clean_title(title)}).split(':',1)[1]
        if SequenceMatcher(None,a,b).ratio()<.95:continue
        duration=(row.get('trackTimeMillis') or 0)/1000
        if not duration or not track.get('duration') or abs(duration-track['duration'])>duration*.20:continue
        candidates.append((a==b,duration,artist,title,row))
    if not candidates:return {'catalogueState':'not-found'}
    exact=[c for c in candidates if c[0]];candidates=exact or candidates
    # Different official edits with the same title cannot establish one original duration.
    if max(c[1] for c in candidates)-min(c[1] for c in candidates)>1.5:return {'catalogueState':'ambiguous'}
    _,duration,artist,title,row=candidates[0]
    delta=round(track['duration']-duration,2)
    result={'referenceDuration':round(duration,2),'durationDelta':delta,'referenceProvider':provider,'catalogueState':'verified'}
    # Artwork follows the verified recording identity, independently of audio length.
    result.update(artwork(row,provider))
    if row.get('collectionName') and row.get('collectionId'):
        result.update(catalogueAlbum=clean(row['collectionName']),catalogueAlbumId=str(row['collectionId']))
    source=safe_reference(row.get('trackViewUrl'),provider)
    if source:result['metadataSourceUrl']=source
    if abs(delta)<=max(3,track['duration']*.025):
        # MusicBrainz follows editorial title style rather than release lettering.
        # Use its identity/duration while retaining the uploader's cleaned case.
        preserved=track['title']
        if provider=='MusicBrainz' and track.get('original'):
            source_title=clean_track_tags({**track,'title':track['original']})['title']
            key=lambda value:recording_key({'artist':'_','title':value})
            if key(source_title)==key(preserved):preserved=source_title
        result.update(artist=source_artist(track) if provider=='MusicBrainz' else artist,title=title if provider!='MusicBrainz' and base_title(track['title'])==clean_title(track['title']) else preserved,tagProvider=provider,metadataVerified=True)
    return result

def artist_catalogue(track):
    if track.get('metadataConfirmed') is False:return [],''
    query={'term':clean_artist(track.get('mainArtist') or track['artist']).split(', ')[0],'entity':'song','limit':200,'country':'kz'}
    rows=catalogue_request('https://itunes.apple.com/search?'+urllib.parse.urlencode(query),'Apple Music').get('results',[])
    rows=localized_catalogue_rows({**track,'title':base_title(track['title'])},rows,catalogue_request)
    return rows,''

def artist_release_catalogue(track):
    # Anchor to a unique official performer entity, then verify the whole
    # collaboration against its release rows. Term search can omit these songs.
    artist=clean_artist(track.get('mainArtist') or track['artist']).split(', ')[0]
    key=lambda name:recording_key({'artist':name,'title':'_'}).split(':',1)[0]
    query={'term':artist,'entity':'musicArtist','limit':25,'country':'kz'}
    entities=catalogue_request('https://itunes.apple.com/search?'+urllib.parse.urlencode(query),'Apple Music').get('results',[])
    ids={r.get('artistId') for r in entities if r.get('wrapperType')=='artist' and key(r.get('artistName',''))==key(artist) and r.get('artistId')}
    if len(ids)!=1:return []
    query={'id':next(iter(ids)),'entity':'song','limit':200,'country':'kz'}
    rows=catalogue_request('https://itunes.apple.com/lookup?'+urllib.parse.urlencode(query),'Apple Music').get('results',[])
    return localized_catalogue_rows({**track,'title':base_title(track['title'])},rows,catalogue_request)

def lookup_duration(track,on_duration=None):
    def duration_ready(result):
        # Publish only a terminal duration decision. Artwork and profile spelling
        # are independent enrichment and must not delay the first comparison.
        if on_duration is not None:
            try:on_duration(dict(result))
            except Exception:pass
        return result
    if track.get('metadataConfirmed') is False or credit_order.candidates(track):
        evidence=[]
        def request(url,provider):
            data=catalogue_request(url,provider)
            if provider=='Apple Music':evidence.extend(data.get('results',[]))
            return data
        resolved=credit_order.lookup(track,request,verify,base_title)
        if track.get('metadataConfirmed') and resolved.get('catalogueState')!='verified':
            # Term search often omits collaborations. Use the anchored performer's
            # unique catalogue ID, then verify the complete credits and recording.
            try:
                rows,_=artist_catalogue(track)
                found=credit_order.resolve(track,rows,'Apple Music',verify,base_title)
                if found.get('catalogueState')=='not-found':
                    key=lambda name:recording_key({'artist':name,'title':'_'}).split(':',1)[0]
                    ids={r.get('artistId') for r in rows if key(r.get('artistName',''))==key(track['artist']) and r.get('artistId')}
                    if len(ids)!=1:
                        query={'term':track['artist'],'entity':'musicArtist','limit':25,'country':'kz'}
                        entities=request('https://itunes.apple.com/search?'+urllib.parse.urlencode(query),'Apple Music').get('results',[])
                        ids={r.get('artistId') for r in entities if r.get('wrapperType')=='artist' and key(r.get('artistName',''))==key(track['artist']) and r.get('artistId')}
                    if len(ids)==1:
                        query={'id':next(iter(ids)),'entity':'song','limit':200,'country':'kz'}
                        rows=request('https://itunes.apple.com/lookup?'+urllib.parse.urlencode(query),'Apple Music').get('results',[])
                        found=credit_order.resolve(track,rows,'Apple Music',verify,base_title)
                if found.get('catalogueState') in ('verified','ambiguous'):resolved=found
                evidence.extend(rows)
            except Exception:pass
        duration_ready(resolved)
        if resolved.get('catalogueState')=='verified':
            # The same artist-entity check applies to both upload title orders,
            # reusing recording evidence instead of repeating term searches.
            try:name=artist_profile({**track,**resolved},evidence,catalogue_request)
            except Exception:name=''
            if name:resolved.update(artist=name,artistProvider='Apple Music')
            elif resolved.get('referenceProvider')=='MusicBrainz':resolved['artist']=source_artist({**track,**resolved})
        return resolved
    bulk=None;failed=False;name=''
    try:
        bulk,name=artist_catalogue(track)
        result=verify(track,bulk)
        if result['catalogueState']!='not-found':
            duration_ready(result)
            try:name=artist_profile(track,bulk,catalogue_request)
            except Exception:name=''
            if name:result.update(artist=name,artistProvider='Apple Music')
            return result
    except Exception:failed=True
    url='https://itunes.apple.com/search?'+urllib.parse.urlencode({'term':track['artist']+' '+base_title(track['title']),'entity':'song','limit':25,'country':'kz'})
    try:
        rows=localized_catalogue_rows({**track,'title':base_title(track['title'])},catalogue_request(url,'Apple Music').get('results',[]),catalogue_request)
        result=verify(track,rows)
        if result['catalogueState']!='not-found':
            duration_ready(result)
            try:name=artist_profile(track,rows,catalogue_request)
            except Exception:name=''
            if name:result.update(artist=name,artistProvider='Apple Music')
            return result
    except Exception:failed=True
    # Some tracks are omitted from term search but exist in the artist catalogue.
    # A second storefront supplies metadata only; every row still passes verify().
    try:
        query={'term':track['artist'],'entity':'song','limit':200,'country':'kz'}
        rows=bulk if bulk is not None else catalogue_request('https://itunes.apple.com/search?'+urllib.parse.urlencode(query),'Apple Music').get('results',[])
        key=lambda artist:recording_key({'artist':artist,'title':'_'}).split(':',1)[0]
        try:name=artist_profile(track,rows,catalogue_request)
        except Exception:name=''
        if name:track={**track,'artist':name,'originalArtist':name}
        ids={r.get('artistId') for r in rows if key(r.get('artistName',''))==key(track['artist']) and r.get('artistId')}
        if len(ids)!=1:
            rows=artist_release_catalogue(track)
            result=verify(track,rows)
            if result['catalogueState']!='not-found':return duration_ready(result)
        if len(ids)==1:
            query={'id':next(iter(ids)),'entity':'song','limit':200,'country':'kz'}
            rows=localized_catalogue_rows({**track,'title':base_title(track['title'])},catalogue_request('https://itunes.apple.com/lookup?'+urllib.parse.urlencode(query),'Apple Music').get('results',[]),catalogue_request)
            result=verify(track,rows)
            if result['catalogueState']!='not-found':
                duration_ready(result)
                if name:result.update(artist=name,artistProvider='Apple Music')
                return result
    except Exception:failed=True
    quoted=lambda s:'"'+s.replace('\\','\\\\').replace('"','\\"')+'"'
    artists=re.split(r'\s*(?:&|,|\+|\bfeat\.?|\bft\.?)\s*|\s+[xх×]\s+',track['artist'],flags=re.I)
    query=' AND '.join('artist:'+quoted(a) for a in artists if a)+' AND recording:'+quoted(base_title(track['title']))
    url='https://musicbrainz.org/ws/2/recording/?'+urllib.parse.urlencode({'query':query,'fmt':'json','limit':10})
    try:
        rows=[]
        for r in catalogue_request(url,'MusicBrainz').get('recordings',[]):
            if re.search(r'live|remix|instrumental|edit|karaoke',r.get('disambiguation',''),re.I):continue
            rows.append({'wrapperType':'track','artistName':' & '.join(a.get('name','') for a in r.get('artist-credit',[]) if isinstance(a,dict)), 'trackName':r.get('title'),'trackTimeMillis':r.get('length')})
        result=verify(track,rows,'MusicBrainz')
        if name and result['catalogueState']=='verified':result.update(artist=name,artistProvider='Apple Music')
        return duration_ready({'catalogueState':'unavailable'} if failed and result['catalogueState']=='not-found' else result)
    except Exception:return duration_ready({'catalogueState':'unavailable'})

def lookup(track,on_duration=None):
    track=clean_track_tags(track)
    credit_choices=credit_order.candidates(track)
    result=lookup_duration(track,on_duration=on_duration) if on_duration is not None else lookup_duration(track)
    # Once an unknown upload's credit order is verified, reuse the official
    # artist catalogue to obtain its release and artwork. Duration/style from
    # the first verification stay authoritative.
    if result.get('catalogueState')=='verified' and (not result.get('catalogueAlbum') or not result.get('catalogueCover')):
        verified=clean_track_tags({**track,**result,'metadataConfirmed':True})
        try:
            rows,_=artist_catalogue(verified);release=verify(verified,rows)
            if release.get('catalogueState')!='verified' or not release.get('catalogueCover'):
                rows=artist_release_catalogue(verified);release=verify(verified,rows)
            if release.get('catalogueState')=='verified':
                result.update({k:release[k] for k in ('catalogueCover','coverProvider','catalogueAlbum','catalogueAlbumId') if k in release})
                if not result.get('artistProvider'):
                    name=artist_profile(verified,rows,catalogue_request)
                    if name:result.update(artist=name,artistProvider='Apple Music')
        except Exception:pass
    if not result.get('catalogueCover') or result.get('catalogueState') in ('not-found','unavailable'):
        try:
            if track.get('metadataConfirmed') and not credit_choices:tags=genius_lookup(track,catalogue_request)
            else:
                matches=[genius_lookup({**c,'metadataConfirmed':True},catalogue_request) for c in credit_order.candidates(track)]
                matches=[m for m in matches if m]
                tags=matches[0] if len({recording_key(m) for m in matches})==1 else {}
            if result.get('catalogueState')=='verified':
                result.update({k:tags[k] for k in ('catalogueCover','coverProvider') if k in tags})
            else:result.update(tags)
        except Exception:pass
    # Artist-profile lettering is independent of the selected album artwork.
    # Resolve in the existing background lane; never add this to send/search.
    spelling={'artistSpellingVersion':1,'artistSpellingState':'unavailable'}
    if result.get('metadataVerified') or result.get('catalogueState')=='verified':
        try:
            wanted=clean_track_tags({**track,**result,'metadataConfirmed':True})
            wanted['title']=base_title(wanted['title'])
            if result.get('artistProvider')=='Apple Music':artist_rows=[]
            else:
                # A temporary profile failure must not replace previously
                # confirmed lettering with a release-credit capitalization.
                if track.get('artistProvider')=='Apple Music' and recording_key({'artist':track['artist'],'title':'_'})==recording_key({'artist':wanted['artist'],'title':'_'}):wanted.update(artist=track['artist'],artistProvider='Apple Music')
                else:wanted.pop('artistProvider',None)
                try:artist_rows,_=artist_catalogue(wanted)
                except Exception:artist_rows=[]
            spelling.update(preferred_artist_spelling(wanted,artist_rows,catalogue_request))
        except Exception:pass
        result.update(spelling)
    music_art=False
    if track.get('source')=='YouTube' and re.fullmatch(r'yt-album-MPREb_[\w-]{5,100}',track.get('albumId','')):
        try:
            from music_albums import recording_art
            art=recording_art(track)
            if art:result.update(art);music_art=True
        except Exception:pass
    return {**result,**({'musicArtworkVersion':1} if music_art else {}),'versionLabels':track.get('versionLabels',[]),'tagSchemaVersion':TAG_SCHEMA_VERSION,'catalogueLookupPhase':'complete','catalogueEnrichmentRetryAt':None,**({'creditOrderVersion':1} if track.get('metadataConfirmed') and credit_choices else {}),**({'artworkLookupVersion':2} if track.get('metadataConfirmed') else {})}

def canonicalize(track,enqueue=False):
    if 'originalCover' not in track:track={**track,'originalCover':track.get('cover',''),'originalDownloadCover':track.get('downloadCover','')}
    if track.get('manualTags') and track.get('tagsMode','corrected')!='original':
        tags=track['manualTags']
        corrected={**track,'title':clean(tags['title']),'artist':clean(tags['artist']),'featuredArtists':[],'productionCredits':[],'metadataConfirmed':True}
        corrected.pop('mainArtist',None)
        return {**corrected,'original':track.get('original',''),'catalogueState':'custom','metadataVerified':False,'tagProvider':'User'}
    artist_keys=lambda value:set(recording_key({'artist':value,'title':'_'}).split(':',1)[0].split('+'))-{''}
    def invalidate_recording(value):
        # Nulls also clear an older Node snapshot through its existing field
        # whitelist. Original provider artwork remains a safe preview fallback.
        for name in ('referenceDuration','durationDelta','referenceProvider','catalogueLookupPhase','catalogueEnrichmentRetryAt','catalogueAlbum','catalogueAlbumId','catalogueCover','catalogueCheckedAt','metadataSourceUrl','coverProvider','tagProvider','artistProvider','artistSpellingVersion','artistSpellingState','artworkLookupVersion','musicArtworkVersion','creditOrderVersion'):
            value[name]=None
        value['metadataVerified']=False;value['catalogueState']='pending' if _enabled else 'unavailable'
        return value
    original_artist=track.get('artist','')
    known=_known_artists() if track.get('metadataConfirmed') and original_artist else ()
    track=clean_track_tags(track,known)
    expanded=artist_keys(original_artist)<artist_keys(track['artist'])
    if expanded:track=invalidate_recording(track)
    # Retain source-bound complete credits when an older exact cache fingerprint
    # still contains only the uploader/main performer. The existing local roster
    # may identify missing names; arbitrary new names remain catalogue candidates.
    raw_title=track.get('original') or track['title']
    source_credits=clean_track_tags({**track,'title':raw_title},known)
    source_credits=source_credits if source_credits['title']!=clean_title(raw_title) else None
    def cache_identity_changed(tags):
        previous=tags.get('artist',original_artist if expanded else track['artist'])
        return bool(source_credits and artist_keys(previous)<artist_keys(source_credits['artist']))
    def cached_tags(tags):
        merged={**track,**tags}
        if cache_identity_changed(tags):
            merged['artist']=source_credits['artist'];invalidate_recording(merged)
        return clean_track_tags(merged,known)
    from source import track_version
    track={**track,'version':track_version(track.get('original') or track['title'])}
    from audio_audit import cached
    track={**track,**cached(track)}
    key=signature(track)
    with _lock:
        cached=_cache.get(key)
        ttl=30*86400 if cached and cached['tags'].get('catalogueState')=='verified' and cached['tags'].get('catalogueCover') and cached['tags'].get('artistProvider') else 60 if cached and cached['tags'].get('catalogueState')=='unavailable' else 6*3600
        # A completed lookup attempt does not prove a partial credit list. Retry
        # unresolved collaboration wrappers after a cooldown, even when an older
        # cache row already carries creditOrderVersion=1 or other verified tags.
        unresolved_credit=bool(track.get('metadataConfirmed') and credit_order.candidates(track)) and cached and bool(credit_order.candidates(clean_track_tags({**track,**cached['tags']})))
        retry_credit=bool(cached and cache_identity_changed(cached['tags'])) or unresolved_credit and (cached['tags'].get('creditOrderVersion')!=1 or time.time()-cached['time']>300)
        retry_artwork=cached and track.get('metadataConfirmed') and not (cached['tags'].get('catalogueCover') or track.get('catalogueCover')) and cached['tags'].get('artworkLookupVersion',0)<2 and time.time()-cached['time']>60
        retry_spelling=cached and (cached['tags'].get('metadataVerified') or cached['tags'].get('catalogueState')=='verified') and (cached['tags'].get('artistSpellingVersion')!=1 and time.time()-cached['time']>60 or cached['tags'].get('artistSpellingState')=='unavailable' and time.time()-cached['time']>300)
        retry_music=track.get('source')=='YouTube' and re.fullmatch(r'yt-album-MPREb_[\w-]{5,100}',track.get('albumId','')) and cached and cached['tags'].get('musicArtworkVersion')!=1 and time.time()-cached['time']>60
        retry_at=cached['tags'].get('catalogueEnrichmentRetryAt') if cached else None
        retry_at=retry_at if isinstance(retry_at,(int,float)) and not isinstance(retry_at,bool) and math.isfinite(retry_at) and retry_at>0 else None
        enrichment_deferred=bool(retry_at and time.time()*1000<retry_at and not cache_identity_changed(cached['tags']))
        retry_enrichment=bool(cached and (cached['tags'].get('catalogueLookupPhase')=='duration' and key not in _queued or retry_at and time.time()*1000>=retry_at))
        if cached and (enrichment_deferred or not retry_credit and not retry_artwork and not retry_music and not retry_spelling and not retry_enrichment) and time.time()-cached['time']<ttl:return cached_tags(cached['tags'])
        # An older exact source/duration fingerprint can supply already verified
        # artwork while the current parser/catalogue schema is rechecked.
        fallback=cached['tags'] if cached and time.time()-cached['time']<ttl else None
        for version in (12,11,10,9,8,7):
            old=_cache.get(signature(track,version));tags=old.get('tags',{}) if old else {}
            if tags.get('tagSchemaVersion')==version and tags.get('catalogueState')=='verified' and tags.get('metadataVerified') and tags.get('catalogueCover') and tags.get('coverProvider') in ('Apple Music','Genius') and 0<=time.time()-old['time']<30*86400:
                if fallback is None:fallback=tags
                break
        eligible=bool(track.get('metadataConfirmed') or credit_order.candidates(track)) and track.get('duration',0)>0
        if enqueue and _enabled and eligible and key not in _queued:
            try:_pending.put_nowait((key,dict(track)));_queued.add(key)
            except queue.Full:pass
    if fallback:return cached_tags({**fallback,**({'title':track['title']} if track['version'] else {}),'version':track['version']})
    return {**track,'catalogueState':'pending' if _enabled and eligible else 'not-found' if _enabled else 'unavailable','tagSchemaVersion':TAG_SCHEMA_VERSION}

def start_resolver():
    global _enabled,_cache
    with _lock:
        if _enabled:return
        path=ROOT/'work/tag-catalogue.json'
        try:_cache=json.loads(path.read_text(encoding='utf-8'))
        except (OSError,ValueError):_cache={}
        _enabled=True
    def run():
        while True:
            key,track=_pending.get()
            try:
                def publish(tags,phase):
                    # One worker owns this exact source/original/duration key
                    # until its final enrichment is stored. Callbacks never
                    # carry user edits or audio audits into the shared cache.
                    tags={**tags,'tagSchemaVersion':TAG_SCHEMA_VERSION,'catalogueLookupPhase':phase,'catalogueCheckedAt':round(time.time()*1000)}
                    with _lock:
                        _cache[key]={'time':time.time(),'tags':tags}
                        if len(_cache)>2000:
                            for old in sorted(_cache,key=lambda k:_cache[k]['time'])[:len(_cache)-2000]:del _cache[old]
                        temp=path.with_suffix('.pending.json');temp.write_text(json.dumps(_cache,ensure_ascii=False),encoding='utf-8');os.chmod(temp,0o600);temp.replace(path)
                duration_result=None
                def duration_ready(result):
                    nonlocal duration_result
                    duration_result=dict(result)
                    publish(result,'duration')
                try:tags=lookup(track,on_duration=duration_ready)
                except Exception:
                    # Optional enrichment cannot erase an already verified
                    # duration. Preserve the terminal decision and retry the
                    # remaining enrichment after a bounded cooldown.
                    tags={**(duration_result or {'catalogueState':'unavailable'}),'catalogueEnrichmentRetryAt':round((time.time()+60)*1000)}
                publish(tags,'complete')
            except Exception:pass
            finally:
                with _lock:_queued.discard(key)
                _pending.task_done()
    for i in range(4):threading.Thread(target=run,name='tag-catalogue-'+str(i),daemon=True).start()
