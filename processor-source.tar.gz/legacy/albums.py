"""Public SoundCloud sets, bounded and cached; no caller-controlled API URLs."""
import hashlib,json,re,time,urllib.parse
from concurrent.futures import ThreadPoolExecutor,as_completed,TimeoutError
from media import ROOT
from library import clean,recording_key
from work_cache import keyed_lock,atomic_json

_pool=ThreadPoolExecutor(max_workers=1,thread_name_prefix='album-membership')
_providers={name:ThreadPoolExecutor(max_workers=1,thread_name_prefix='album-'+name) for name in ('SoundCloud','YouTube')}
_warm=ThreadPoolExecutor(max_workers=1,thread_name_prefix='album-prewarm')
_warming=set()
import threading
_warm_lock=threading.Lock()

def api(path,params=None):
    from source_cli import independent_session
    extractor=independent_session()['extractor']
    return extractor._call_api(extractor._API_V2_BASE+path,'albums',headers=extractor._HEADERS,query={'client_id':extractor._CLIENT_ID,**(params or {})})

def cached(key,fetch,ttl=1800):
    path=ROOT/'work/album-pages'/(hashlib.sha256(key.encode()).hexdigest()+'.json')
    with keyed_lock(('albums',key)):
        try:
            saved=json.loads(path.read_text(encoding='utf-8'))
            duration=ttl(saved['data']) if callable(ttl) else ttl
            if time.time()-saved['time']<duration:return saved['data']
        except (OSError,ValueError,KeyError,TypeError):pass
        data=fetch();atomic_json(path,{'time':time.time(),'data':data})
        try:
            paths=list(path.parent.glob('*.json'))
            if len(paths)>256:
                for old in sorted(paths,key=lambda p:p.stat().st_mtime)[:len(paths)-256]:old.unlink(missing_ok=True)
        except OSError:pass
        return data

def public_album(raw):
    url=urllib.parse.urlsplit(raw.get('permalink_url') or '')
    if not re.fullmatch(r'\d{1,20}',str(raw.get('id',''))) or url.scheme!='https' or url.netloc!='soundcloud.com' or not re.fullmatch(r'/[^/]+/sets/[^/]+',url.path):return None
    cover=raw.get('artwork_url') or next((t.get('artwork_url') for t in raw.get('tracks',[]) if t.get('artwork_url')),'')
    try:
        image=urllib.parse.urlsplit(cover or '')
        if image.scheme!='https' or image.hostname!='i1.sndcdn.com' or image.username or image.password or image.port not in (None,443):cover=''
    except ValueError:cover=''
    try:count=min(2000,max(0,int(raw.get('track_count') or len(raw.get('tracks',[])))))
    except (ValueError,TypeError,OverflowError):return None
    cover=re.sub(r'-[0-9a-z]+\.(?:jpg|png)$','-t500x500.jpg',cover or '')
    return {'id':str(raw['id']),'title':clean(raw.get('title',''))[:200],'artist':clean((raw.get('user') or {}).get('username',''))[:100],
        'cover':cover,'trackCount':count,'source':'SoundCloud','kind':'album' if raw.get('is_album') else 'playlist'}

def search_soundcloud(query,offset=0):
    from source import resolve_artist_query,track_version
    query=resolve_artist_query(clean(query)[:150])
    def fetch():
        data=api('search/playlists',{'q':query,'limit':10,'offset':offset,'linked_partitioning':1})
        rows=[a for raw in data.get('collection',[]) if (a:=public_album(raw))]
        if not track_version(query):rows=[a for a in rows if not track_version(a['title'])]
        words=lambda value:set(re.findall(r'[^\W_]+',value.casefold().replace('ё','е')))
        wanted=words(query)
        rows.sort(key=lambda a:(-len(wanted&words(a['artist']+' '+a['title'])),a['trackCount']==0,a['kind']!='album'))
        return {'tracks':[],'albums':rows,'nextOffset':offset+10 if data.get('next_href') else None,'metadataVersion':10,'providerState':'ok' if rows else 'empty'}
    return cached('search:'+query.casefold()+':'+str(offset),fetch)

def album_details(ident):
    if not re.fullmatch(r'\d{1,20}',str(ident)):raise ValueError('Invalid album ID')
    def fetch():
        raw=api('playlists/'+str(ident))
        if str(raw.get('id'))!=str(ident) or not public_album(raw):raise RuntimeError('Альбом недоступен.')
        return raw
    return cached('detail:'+str(ident),fetch,21600)

def open_soundcloud(ident):
    from source import normalize_track,valid_url
    from source_cli import flat_track
    raw=album_details(ident);album=public_album(raw)
    if not album:raise RuntimeError('Альбом недоступен.')
    entries=raw.get('tracks',[])[:200];missing=[str(t['id']) for t in entries if not t.get('title') and re.fullmatch(r'\d{1,20}',str(t.get('id','')))]
    enriched={}
    for start in range(0,len(missing),50):
        ids=','.join(missing[start:start+50]);allowed=set(ids.split(','))
        batch=cached('soundcloud-album-tracks-v1:'+ids,lambda:api('tracks',{'ids':ids}),21600)
        for t in batch:
            if isinstance(t,dict) and str(t.get('id')) in allowed:enriched[str(t['id'])]=t
    rows=[]
    for pos,item in enumerate(entries):
        item=enriched.get(str(item.get('id')),item)
        if not item.get('title') or item.get('policy') in {'BLOCK','SNIP'}:continue
        # A set's owner may be a reuploader, not the recording's performer.
        # Publisher credits and catalogue evidence must confirm each track.
        row=normalize_track(flat_track(item),set())
        if 0<row['duration']<=1080 and valid_url(row['url']):rows.append({**row,'albumTitle':album['title'],'albumId':album['id'],'albumPosition':pos+1})
    return {'tracks':rows,'albums':[],'album':album,'nextOffset':None,'metadataVersion':10,'providerState':'ok' if rows else 'empty','unavailableCount':max(0,min(200,album['trackCount'])-len(rows)),'truncated':album['trackCount']>200}

def words(value):return set(re.findall(r'[^\W_]+',value.casefold().replace('ё','е')))

def prewarm(rows):
    # At most two outstanding tasks; an active search never queues a large
    # hidden download. Detail pages contain metadata only and share open's cache.
    for row in rows[:2]:
        ident=row['id']
        with _warm_lock:
            if ident in _warming or len(_warming)>=2:continue
            _warming.add(ident)
        def run(ident=ident):
            try:open_album(ident)
            except Exception:pass
            finally:
                with _warm_lock:_warming.discard(ident)
        _warm.submit(run)

def search_albums(query,offset=0,provider='SoundCloud',warm=True,for_track=False,on_partial=None,accept=None):
    from music_albums import search_albums as youtube_search
    if provider not in {'all','SoundCloud','YouTube'}:raise ValueError('Invalid album provider')
    query=clean(query)[:150]
    functions={'SoundCloud':search_soundcloud,'YouTube':lambda q,o:youtube_search(q,o,first_page=for_track)}
    selected=list(functions) if provider=='all' else [provider]
    futures={name:_providers[name].submit(functions[name],query,offset) for name in selected}
    pages={};errors={}
    lookup={future:name for name,future in futures.items()}
    try:
        for future in as_completed(lookup,timeout=6):
            name=lookup[future]
            try:pages[name]=future.result()
            except Exception:errors[name]='Источник временно не отвечает.'
            if accept and name in pages:
                accepted=accept(pages[name].get('albums',[]))
                if accepted:
                    for pending in futures.values():pending.cancel()
                    return {'tracks':[],'albums':accepted,'membershipMatches':True,'provider':provider,'providerErrors':errors,'providerState':'ok','metadataVersion':12}
            if on_partial and any(p.get('albums') for p in pages.values()):
                wanted=words(query);partial_rows=[a for p in pages.values() for a in p.get('albums',[])]
                partial_rows.sort(key=lambda a:(-len(wanted&words(a['artist']+' '+a['title'])),a.get('trackCount')==0,a['kind']!='album',a['source']!='YouTube'))
                try:on_partial({'tracks':[],'albums':partial_rows,'provider':provider,'pendingProviders':[n for n in selected if n not in pages and n not in errors],'providerErrors':dict(errors),'providerState':'ok','metadataVersion':11})
                except Exception:pass
    except TimeoutError:pass
    for future,name in lookup.items():
        if name not in pages and name not in errors:
            future.cancel();errors[name]='Источник отвечает долго. Повтори поиск позже.'
    if not pages:raise RuntimeError('Источники альбомов временно недоступны. Попробуй ещё раз.')
    rows=[a for page in pages.values() for a in page.get('albums',[])]
    wanted=words(query)
    rows.sort(key=lambda a:(-len(wanted&words(a['artist']+' '+a['title'])),a.get('trackCount')==0,a['kind']!='album',a['source']!='YouTube'))
    if warm:prewarm([a for a in rows if a['kind']=='album'])
    return {'tracks':[],'albums':rows,'nextOffset':offset+10 if any(p.get('nextOffset') is not None for p in pages.values()) else None,'metadataVersion':11,'provider':provider,'pendingProviders':[],'providerErrors':errors,'providerState':'ok' if rows else 'empty'}

def open_album(ident):
    if str(ident).startswith('yt-album-'):
        from music_albums import open_album as youtube_open
        return youtube_open(ident)
    return open_soundcloud(ident)

def release_key(title,artist=''):
    # A reupload may prepend the release artist. Remove only that exact prefix,
    # retaining genuine subtitles and edition labels.
    from library import clean_title
    parts=re.split(r'\s+[—–-]\s+',title,maxsplit=1)
    if len(parts)==2 and recording_key({'artist':parts[0],'title':'_'})==recording_key({'artist':artist,'title':'_'}):title=parts[1]
    return recording_key({'artist':'_','title':clean_title(title)}).split(':',1)[1]

def album_recording_matches(candidate,track,album,reference):
    if not candidate.get('metadataConfirmed') or not track.get('metadataConfirmed'):return False
    if abs(candidate.get('duration',0)-reference)>3:return False
    if recording_key(candidate)==recording_key(track):return True
    # Music album rows can omit guest credits. Only official releases may use
    # a subset of credits, with the same title/edition and confirmed lead.
    if album.get('source')!='YouTube' or not str(album.get('id','')).startswith('yt-album-MPREb_'):return False
    actual_artists,actual_title=recording_key(candidate).split(':',1)
    wanted_artists,wanted_title=recording_key(track).split(':',1)
    lead=recording_key({'artist':track.get('mainArtist') or track['artist'].split(', ')[0],'title':'_'}).split(':',1)[0]
    actual=set(actual_artists.split('+'));wanted=set(wanted_artists.split('+'))
    return actual_title==wanted_title and lead in actual and actual<=wanted

def related_album_recording(candidate,track,album,reference):
    # Album discovery is distinct from identifying an interchangeable audio file.
    if album.get('source')!='YouTube' or not str(album.get('id','')).startswith('yt-album-MPREb_'):return False
    if not candidate.get('metadataConfirmed') or not track.get('metadataConfirmed'):return False
    duration=candidate.get('duration',0)
    if not reference or not duration or abs(duration-reference)>max(5,reference*.20):return False
    found,title=recording_key(candidate).split(':',1);wanted,original=recording_key(track).split(':',1)
    lead=recording_key({'artist':track.get('mainArtist') or track['artist'].split(', ')[0],'title':'_'}).split(':',1)[0]
    if lead not in found.split('+') or not set(found.split('+'))<=set(wanted.split('+')):return False
    from track_versions import version_labels
    if set(version_labels(candidate.get('original') or candidate['title']))!=set(version_labels(track.get('original') or track['title'])):return False
    if title==original:return True
    # Cross-script transliteration only; never fuzzy-match arbitrary same-script titles.
    from query_normalizer import phonetic
    cyr=lambda value:bool(re.search('[а-яё]',value,re.I))
    return cyr(title)!=cyr(original) and len(phonetic(original))>=6 and phonetic(title)==phonetic(original)

def albums_for_track(track,provider='all',on_partial=None):
    identity=json.dumps([provider,track.get('source'),track.get('id'),track.get('artist'),track.get('title'),track.get('original'),track.get('duration'),track.get('catalogueAlbum'),track.get('referenceDuration'),track.get('tagSchemaVersion'),track.get('albumId')],ensure_ascii=False,sort_keys=True)
    return cached('membership-v8-first-page:'+identity,lambda:_albums_for_track(track,provider,on_partial=on_partial),lambda result:300 if result.get('albums') else 30)

def _albums_for_track(track,provider='all',on_partial=None):
    # Use the actual release ID supplied by the song catalogue, before guessing
    # titles across providers. Membership must still contain this exact recording.
    ident=track.get('albumId','')
    if track.get('source')=='YouTube' and provider in ('all','YouTube') and re.fullmatch(r'yt-album-MPREb_[\w-]{5,100}',ident):
        try:
            from music_albums import album_membership
            known=album_membership(track)
            if known:
                album={**known,'matchType':'release','kind':'album'}
                return {'tracks':[],'albums':[album],'nextOffset':None,'metadataVersion':12,'provider':provider,'providerState':'ok'}
        except Exception:pass # Provider outage or stale release ID keeps the search fallback.
    if track.get('source')=='SoundCloud' and provider in ('all','SoundCloud') and re.fullmatch(r'\d{1,20}',str(ident)):
        try:
            detail=album_details(ident);album=public_album(detail)
            if album and any(str(t.get('id'))==str(track['id']) and t.get('policy') not in {'BLOCK','SNIP'} for t in detail.get('tracks',[])):
                album={**album,'matchType':'release' if album['kind']=='album' else 'membership'}
                return {'tracks':[],'albums':[album],'nextOffset':None,'metadataVersion':12,'provider':provider,'providerState':'ok'}
        except Exception:pass
    from tag_resolver import canonicalize
    verified=canonicalize(track,enqueue=True)
    # Cached verification is immediate. Never trust a random set owner as the
    # performer, nor infer a release name merely from a song name.
    title=verified.get('catalogueAlbum') if verified.get('catalogueState')=='verified' else track.get('catalogueAlbum','') if track.get('catalogueState')=='verified' else ''
    # Catalogue resolution already runs in the background. A button click must
    # not wait for its provider pacing and another artist catalogue download.
    if title and verified.get('catalogueState')!='verified' and track.get('catalogueState')=='verified':verified={**verified,'catalogueState':'verified','referenceDuration':track.get('referenceDuration',track.get('duration',0))}
    query=verified['artist']+' '+(title or verified['title'])
    expected=release_key(title,verified['artist']) if title else ''
    def release_update(page):
        if not on_partial or not expected or verified.get('catalogueState')!='verified':return
        main=verified.get('mainArtist') or verified['artist'].split(', ')[0]
        anchor=recording_key({'artist':main,'title':'_'}).split(':',1)[0]
        rows=[{**a,'kind':'album','matchType':'release'} for a in page['albums'] if a['source']=='YouTube' and a['id'].startswith('yt-album-MPREb_') and release_key(a['title'],verified['artist'])==expected and anchor in recording_key({'artist':a['artist'],'title':'_'}).split(':',1)[0].split('+')]
        if rows:on_partial({**page,'albums':rows})
    def confirmed_release(album):
        # Matching a known official release needs no membership worker. Keep
        # these already established identity checks ahead of slow playlist I/O.
        if not expected or verified.get('catalogueState')!='verified' or album.get('source')!='YouTube' or not str(album.get('id','')).startswith('yt-album-MPREb_'):return None
        if release_key(album['title'],verified['artist'])!=expected:return None
        main=verified.get('mainArtist') or verified['artist'].split(', ')[0]
        anchor=recording_key({'artist':main,'title':'_'}).split(':',1)[0]
        names=recording_key({'artist':album['artist'],'title':'_'}).split(':',1)[0].split('+')
        return {**album,'kind':'album','matchType':'release'} if anchor in names else None
    def matches(album):
        # With a known release, unrelated playlists need not even be opened.
        if expected and release_key(album['title'],verified['artist'])!=expected:return None
        if expected and album['source']=='YouTube' and str(album.get('id','')).startswith('yt-album-MPREb_'):
            # MPRE IDs describe Music releases, not user-created playlists. An
            # exact release name and confirmed main artist already identify it.
            main=verified.get('mainArtist') or verified['artist'].split(', ')[0]
            names=recording_key({'artist':album['artist'],'title':'_'}).split(':',1)[0].split('+')
            anchor=recording_key({'artist':main,'title':'_'}).split(':',1)[0]
            if anchor in names:return {**album,'kind':'album','matchType':'release'}
        try:
            if album['source']=='SoundCloud':
                from source import normalize_track
                from source_cli import flat_track
                detail=album_details(album['id']);actual=public_album(detail)
                if not actual:return None
                if expected and release_key(actual['title'],verified['artist'])!=expected:return None
                candidates=[]
                for item in detail.get('tracks',[])[:200]:
                    if item.get('policy') in {'BLOCK','SNIP'}:continue
                    if str(item.get('id'))==verified['id'] and verified.get('source')=='SoundCloud':candidates.append({'id':verified['id'],'source':'SoundCloud'})
                    elif item.get('title'):candidates.append(normalize_track(flat_track(item),set()))
                album=actual
            else:
                opened=open_album(album['id']);candidates=opened['tracks'];album=opened['album']
            for candidate in candidates:
                exact=candidate.get('source')==verified.get('source') and candidate['id']==verified['id']
                reference=verified.get('referenceDuration') if verified.get('catalogueState')=='verified' else verified.get('duration',0)
                identity=album_recording_matches(candidate,verified,album,reference)
                related=not exact and not identity and related_album_recording(candidate,verified,album,reference)
                if exact or identity or related:
                    # Only an actual album with matching release evidence may
                    # auto-open. Other genuine memberships remain playlists.
                    release=album['kind']=='album' and (bool(expected) or album['source']=='YouTube')
                    return {**album,'kind':'album' if release else 'playlist','matchType':'related-release' if related else 'release' if release else 'membership',**({'recordingMatch':'different','recordingDurationDelta':round(candidate.get('duration',0)-reference,2)} if related else {})}
        except Exception:pass
        return None
    # A confirmed Music release is enough to answer the button. Do not wait
    # through four waves of unrelated community-playlist membership requests.
    probes={}
    def probe(album):
        if album['id'] not in probes:probes[album['id']]=_pool.submit(matches,album)
        return probes[album['id']]
    def fast_membership(available):
        for album in available:
            direct=confirmed_release(album)
            if direct:return [direct]
        selected=[a for a in available if a['source']=='YouTube'][:3];ready=[]
        try:
            for future in as_completed([probe(a) for a in selected],timeout=2):
                matched=future.result()
                if matched and matched['matchType'] in ('release','related-release'):ready.append(matched);break
        except TimeoutError:pass
        if ready:
            for future in probes.values():future.cancel()
        return ready
    page=search_albums(query,provider=provider,warm=False,for_track=True,on_partial=release_update,accept=fast_membership)
    candidates=[a for a in page['albums'] if a['source']=='YouTube'][:6]+[a for a in page['albums'] if a['source']!='YouTube'][:6]
    selected={a['id'] for a in candidates};candidates.extend([a for a in page['albums'] if a['id'] not in selected][:12-len(candidates)])
    pending=set() if page.get('membershipMatches') else {probe(album) for album in candidates};rows=list(page['albums']) if page.get('membershipMatches') else []
    try:
        for future in as_completed(pending,timeout=6):
            matched=future.result()
            if matched:
                rows.append(matched)
                if matched['source']=='YouTube' and matched['matchType'] in ('release','related-release'):break
    except TimeoutError:pass
    for future in pending:future.cancel()
    rows.sort(key=lambda a:(a['matchType']!='release',a['source']!='YouTube'))
    prewarm([a for a in rows if a['matchType']=='release'])
    return {'tracks':[],'albums':rows,'nextOffset':None,'metadataVersion':12,'provider':provider,'providerErrors':page.get('providerErrors',{}),'providerState':'ok' if rows else 'empty'}
