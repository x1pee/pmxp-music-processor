"""Rank public search pages without extra provider requests or changing identity."""
import math,re,unicodedata
from query_normalizer import translit
from track_versions import audio_version

def counter(value):
    # Provider JSON counters are integers. Booleans, strings, NaN and absurd
    # values are not popularity evidence and must not corrupt stable ordering.
    return value if isinstance(value,int) and not isinstance(value,bool) and 0<=value<=10**12 else None

def provider_counts(row):
    result={}
    for field,aliases in [('playCount',('playCount','playback_count','view_count')),('likeCount',('likeCount','likes_count','favoritings_count','like_count')),('repostCount',('repostCount','reposts_count'))]:
        for alias in aliases:
            value=counter(row.get(alias))
            if value is not None:result[field]=value;break
    return result

def word_parts(value):
    # Music providers accept names in every script. Preserve combining marks
    # that distinguish recordings; punctuation still separates word tokens.
    text=unicodedata.normalize('NFKC',str(value)).casefold().replace('ё','е')
    parts=''.join(c if unicodedata.category(c)[0] in 'LNM' else ' ' for c in text).split()
    return [part for part in parts if any(unicodedata.category(c)[0] in 'LN' for c in part)]

def text_key(value):
    return ''.join(word_parts(value))

def tokens(value):
    return set(word_parts(value))

def relevance(query,row):
    # Query intent stays a song search even when an artist has the same name.
    # Only complete title/credits matches earn the highest band. Popularity
    # never promotes a partial or unrelated title ahead of an exact recording.
    title=row.get('title') or row.get('track') or ''
    artist=row.get('artist') or row.get('creator') or row.get('uploader') or ''
    if row.get('metadataConfirmed') is False:artist=row.get('uploader') or row.get('originalArtist') or artist
    best=5
    for q,t,a in [(query,title,artist),(translit(query),translit(title),translit(artist))]:
        qk,tk,ak=text_key(q),text_key(t),text_key(a)
        qt,tt,at=tokens(q),tokens(t),tokens(a)
        if not qk:continue
        if qk==tk or (tk and ak and qk in (tk+ak,ak+tk)):best=min(best,0)
        elif qt and qt<=tt:best=min(best,1)
        elif qt and qt<=tt|at and qt&tt:best=min(best,1)
        elif qk==ak or qt and qt<=at:best=min(best,2)
        elif len(qk)>=3 and qk in tk:best=min(best,3)
        elif qt and qt&(tt|at):best=min(best,4)
    return best

def edition_rank(query,row):
    wanted=audio_version(query)
    if not wanted:return 0
    actual=audio_version(row.get('original') or row.get('title','')) or audio_version(row.get('version',''))
    return 0 if wanted==actual else 1

def popularity(row):
    counts=provider_counts(row)
    # Log scale confines secondary social signals; a high like count cannot
    # outweigh a recording with many more genuine plays in the same match band.
    return math.log1p(counts.get('playCount',0))+.08*math.log1p(counts.get('likeCount',0))+.04*math.log1p(counts.get('repostCount',0))

def rank_tracks(query,rows,quality=None):
    quality=quality or (lambda row:0)
    return [row for _,row in sorted(enumerate(rows),key=lambda pair:(relevance(query,pair[1]),edition_rank(query,pair[1]),quality(pair[1]),-popularity(pair[1]),pair[0]))]

def displayed_plays(value):
    # Music sometimes supplies plays in its existing subtitle. Never mistake a
    # duration, album year or artist name for a count; unlabelled text is ignored.
    text=str(value).strip().casefold().replace('\u00a0',' ')
    match=re.fullmatch(r'([0-9][0-9., ]*)\s*(k|m|b|тыс\.?|млн\.?|млрд\.?)?\s*(?:plays?|views?|прослушивани[яйе]|прослушиваний|просмотров|просмотра|просмотр)',text)
    if not match:return None
    number,suffix=match.groups();number=number.replace(' ','')
    try:
        if suffix:
            amount=float(number.replace(',','.'))*({'k':10**3,'m':10**6,'b':10**9,'тыс':10**3,'млн':10**6,'млрд':10**9}[suffix.rstrip('.')])
        else:amount=int(number.replace(',','').replace('.',''))
        return counter(int(amount))
    except (ValueError,KeyError,OverflowError):return None
