from runtime_security import run as private_run, popen as private_popen
"""Persistent two-slot search workers; terminate only an owned timed-out child."""
import atexit,hashlib,json,queue,subprocess,sys,threading,time
from pathlib import Path
PROTOCOL=1
WARM_SECONDS=12

class Slot:
    def __init__(self,worker):self.worker=worker;self.lock=threading.Lock();self.process=None;self.replies=None;self.serial=0;self.warmed=False
    def stop(self):
        p=self.process;self.process=None;self.warmed=False
        if not p:return
        try:
            if p.poll() is None:p.terminate()
            p.wait(timeout=1)
        except Exception:
            try:p.kill();p.wait(timeout=1)
            except Exception:pass
        for stream in (p.stdin,p.stdout):
            try:stream.close()
            except Exception:pass
    def start(self,deadline):
        self.stop();self.replies=queue.Queue(maxsize=1)
        p=private_popen([sys.executable,'-u',str(self.worker)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True,encoding='utf-8',bufsize=1,close_fds=True)
        self.process=p;responses=self.replies
        def read():
            try:
                while True:
                    line=p.stdout.readline(2*1024*1024+1)
                    if not line:break
                    if len(line)>2*1024*1024:raise ValueError('Provider reply too large')
                    responses.put(json.loads(line),timeout=1)
            except Exception:pass
            finally:
                try:responses.put({'closed':True},timeout=1)
                except queue.Full:pass
        threading.Thread(target=read,name='provider-reader',daemon=True).start()
        if responses.get(timeout=max(.001,deadline-time.monotonic()))!={'type':'ready','protocol':PROTOCOL}:raise ValueError('Provider readiness mismatch')
    def request(self,payload,deadline):
        if self.process is None or self.process.poll() is not None:self.start(deadline)
        self.serial+=1;ident=self.serial
        self.process.stdin.write(json.dumps({'id':ident,'payload':payload},ensure_ascii=False)+'\n');self.process.stdin.flush()
        reply=self.replies.get(timeout=max(.001,deadline-time.monotonic()))
        if not isinstance(reply,dict) or reply.get('id')!=ident or reply.get('protocol')!=PROTOCOL or not isinstance(reply.get('ok'),bool):raise ValueError('Provider protocol mismatch')
        if not reply['ok']:raise RuntimeError(reply.get('error','YouTube Music временно недоступен.'))
        return reply['result']
    def warm(self,timeout=WARM_SECONDS):
        # Reserve before starting: requests cannot race this slot's readiness
        # or consume its warm reply. At most the existing two children exist.
        if not self.lock.acquire(blocking=False):return
        if self.warmed and self.process is not None and self.process.poll() is None:self.lock.release();return
        def initialize():
            try:
                result=self.request({'action':'warm','provider':'YouTube'},time.monotonic()+max(.01,min(WARM_SECONDS,float(timeout))))
                if result!={'warmed':True}:raise ValueError('Provider warm mismatch')
                self.warmed=True
            except Exception:self.stop()  # A later search can lazily start fresh.
            finally:self.lock.release()
        try:threading.Thread(target=initialize,name='provider-prewarm',daemon=True).start()
        except Exception:self.lock.release()
    def call(self,payload,timeout):
        deadline=time.monotonic()+max(.01,min(40,float(timeout)))
        if not self.lock.acquire(timeout=max(0,deadline-time.monotonic())):raise RuntimeError('YouTube Music отвечает долго. Повтори поиск.')
        try:
            return self.request(payload,deadline)
        except queue.Empty:
            self.stop();raise RuntimeError('YouTube Music отвечает долго. Повтори поиск.') from None
        except (OSError,ValueError,KeyError):
            self.stop();raise RuntimeError('YouTube Music временно недоступен. Повтори поиск.') from None
        finally:self.lock.release()

class ProviderPool:
    def __init__(self,worker=None):
        worker=Path(worker or Path(__file__).with_name('provider_worker.py'))
        self.slots=[Slot(worker) for _ in range(1)]
    def slot(self,payload):
        key=str(payload.get('query','')).casefold()
        return self.slots[int(hashlib.sha256(key.encode()).hexdigest()[:8],16)%2]
    def call(self,payload,timeout=40):return self.slot(payload).call(payload,timeout)
    def warm(self,timeout=WARM_SECONDS):
        for slot in self.slots:slot.warm(timeout)
    def wait_ready(self,timeout=WARM_SECONDS):
        deadline=time.monotonic()+max(.01,min(WARM_SECONDS,float(timeout)))
        for slot in self.slots:
            if slot.warmed and slot.process is not None and slot.process.poll() is None:continue
            if not slot.lock.acquire(timeout=max(0,deadline-time.monotonic())):return False
            try:
                if not slot.warmed or slot.process is None or slot.process.poll() is not None:return False
            finally:slot.lock.release()
        return True
    def close(self):
        for slot in self.slots:slot.stop()

_pool=ProviderPool()
atexit.register(_pool.close)
def search(payload,timeout=40):return _pool.call(payload,timeout)
def warm():_pool.warm()
def wait_ready(timeout=WARM_SECONDS):return _pool.wait_ready(timeout)
