"""Private, durable listening preferences; no network or media work on import."""
import hashlib,json,os,re,threading,time,unicodedata,math,uuid
from contextlib import contextmanager
from pathlib import Path
from media import ROOT
from library import clean_artist,clean_track_tags,listening_key
from received_tracks import receipt_evidence,compact_received,provider_key,recording_facts,recording_duration,is_received,IDENTITY_FIELDS

_lock=threading.RLock()
LEGACY_OWNER=1807122506
def user_work(owner):
    if isinstance(owner,bool) or not isinstance(owner,int) or owner<=0 or owner>9007199254740991:raise ValueError('Invalid user')
    return ROOT/'work' if owner==LEGACY_OWNER else ROOT/'work/users'/str(owner)
def taste_path(owner):return user_work(owner)/'taste.json'
def identity(value):
    return re.sub(r'\W','',unicodedata.normalize('NFKC',str(value)).casefold().replace('ё','е'))

def _load(owner,path):
    try:data=json.loads(path.read_text(encoding='utf-8'))
    except FileNotFoundError:data={'owner':owner,'revision':0,'events':[],'tracks':{}}
    # Never replace another user's store, including a caller's wrong explicit path.
    if not isinstance(data,dict) or isinstance(data.get('owner'),bool) or data.get('owner')!=owner:raise ValueError('Private history owner mismatch')
    data.setdefault('receivedTracks',{});data.setdefault('receivedEvents',{})
    return data

def _safe_path(path):
    if path.is_symlink() or any(parent.is_symlink() for parent in path.parents):raise ValueError('Private history symlink')

@contextmanager
def _disk_lock(path):
    _safe_path(path);path.parent.mkdir(parents=True,exist_ok=True)
    lock_path=path.with_suffix('.lock');_safe_path(lock_path)
    descriptor=os.open(lock_path,os.O_CREAT|os.O_RDWR|getattr(os,'O_NOFOLLOW',0),0o600)
    file=os.fdopen(descriptor,'r+b');locked=False
    try:
        if os.name=='nt':
            import msvcrt
            limit=time.monotonic()+10
            while True:
                try:file.seek(0);msvcrt.locking(file.fileno(),msvcrt.LK_NBLCK,1);locked=True;break
                except OSError:
                    if time.monotonic()>=limit:raise
                    time.sleep(.01)
        else:
            import fcntl
            fcntl.flock(file.fileno(),fcntl.LOCK_EX);locked=True
        _safe_path(path)
        yield
    finally:
        if locked:
            if os.name=='nt':file.seek(0);msvcrt.locking(file.fileno(),msvcrt.LK_UNLCK,1)
            else:fcntl.flock(file.fileno(),fcntl.LOCK_UN)
        file.close()

def _save(path,data):
    temporary=path.with_name(path.name+'.'+uuid.uuid4().hex+'.pending')
    _safe_path(temporary)
    descriptor=os.open(temporary,os.O_CREAT|os.O_EXCL|os.O_WRONLY|getattr(os,'O_NOFOLLOW',0),0o600)
    try:
        with os.fdopen(descriptor,'w',encoding='utf-8') as file:
            json.dump(data,file,ensure_ascii=False,separators=(',',':'));file.flush();os.fsync(file.fileno())
        os.replace(temporary,path)
        if os.name!='nt':
            descriptor=os.open(path.parent,os.O_RDONLY|getattr(os,'O_DIRECTORY',0))
            try:os.fsync(descriptor)
            finally:os.close(descriptor)
    finally:
        if temporary.exists():temporary.unlink()

def _remember(data,event,track):
    if event in data['events']:return False
    track={**track,'artist':str(track.get('artist',''))[:100],'title':str(track.get('title',''))[:200]}
    key=identity(track.get('artist',''))+':'+identity(track.get('title',''))
    if not key.strip(':'):return False
    old=data['tracks'].get(key,{})
    row={**old,**track,'count':old.get('count',0)+1,'lastSeen':track.get('lastSeen') or time.time()*1000}
    if old.get('source')=='Telegram' and track.get('source')!='Telegram':
        row.update({k:old[k] for k in ('id','source','file_id','format') if k in old})
    data['tracks'][key]=row;data['events']=(data['events']+[event])[-20000:]
    data['tracks']=dict(sorted(data['tracks'].items(),key=lambda x:x[1]['lastSeen'],reverse=True)[:3000])
    return True

def remember(owner,event,track,path=None):
    user_work(owner);path=Path(path or taste_path(owner))
    with _lock,_disk_lock(path):
        data=_load(owner,path)
        if not _remember(data,event,track):return False
        data['revision']+=1;_save(path,data);return True

def _received_key(row):
    provider=provider_key(row)
    if provider:value=['provider',*provider]
    else:
        facts=recording_facts(row)
        if not facts:return ''
        value=['recording',[(title,list(edition),sorted(credits)) for title,edition,credits in facts]]
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()

def remember_received(owner,event,track,receipt,path=None):
    """Learn a confirmed send once; preserve received compositions without a cap."""
    user_work(owner);evidence=receipt_evidence(receipt)
    if not evidence:return False
    row=compact_received(track,evidence)
    if not row:return False
    key=_received_key(row)
    if not key:return False
    event_key=hashlib.sha256(str(event).encode()).hexdigest();path=Path(path or taste_path(owner))
    with _lock,_disk_lock(path):
        data=_load(owner,path);seen=data['receivedEvents'].get(event_key)
        previous=data['receivedTracks'].get(key,{})
        row['receivedIdentity']=previous.get('receivedIdentity') or {k:v for k,v in (previous or row).items() if k in IDENTITY_FIELDS}
        row['receivedIdentityEvidence']=previous.get('receivedIdentityEvidence') or (evidence['receivedEvidence'] if not previous else 'unknown')
        row={**previous,**row}
        if previous.get('receivedEvidence')=='telegram-message' and evidence['receivedEvidence']=='legacy-sent-cache':
            row.update({k:previous[k] for k in ('receivedConfirmed','receivedEvidence','receivedMessageId') if k in previous})
            row.pop('receivedLegacyFileId',None)
        received_changed=previous!=row or seen!=key
        learned=False
        # Previously recorded events upgrade without a second preference count.
        legacy=evidence['receivedEvidence']=='legacy-sent-cache'
        may_learn=not legacy or (receipt.get('learnLegacy') is True and not previous)
        if not track.get('recommendationOnly') and seen is None and may_learn:learned=_remember(data,event,track)
        if not received_changed and not learned:return False
        data['receivedTracks'][key]=row;data['receivedEvents'][event_key]=key
        data['revision']+=1;_save(path,data);return True

def snapshot(owner,path=None):
    user_work(owner)
    with _lock:
        try:
            target=Path(path or taste_path(owner));_safe_path(target)
            data=json.loads(target.read_text(encoding='utf-8'))
        except (OSError,ValueError):return {'revision':0,'tracks':[],'receivedTracks':[]}
        def tags(t):
            guests=t.get('featuredArtists',[]);guests=guests if isinstance(guests,list) else []
            guests=[g if isinstance(g,str) else str(g.get('name') or '') for g in guests if isinstance(g,(str,dict))]
            return clean_track_tags({**t,'featuredArtists':guests})
        return {'revision':data['revision'],'tracks':[{**tags(t),'tasteKey':key} for key,t in data['tracks'].items()],
            'receivedTracks':list(data.get('receivedTracks',{}).values())} if not isinstance(data.get('owner'),bool) and data.get('owner')==owner else {'revision':0,'tracks':[],'receivedTracks':[]}

def rebase_profile_revision(owner,current_revision,path=None):
    """Advance only the clock; reload current rows under the existing disk lock."""
    user_work(owner)
    if type(current_revision) is not int or not 0<=current_revision<9007199254740991:raise ValueError('Invalid profile revision floor')
    target=Path(path or taste_path(owner))
    with _lock,_disk_lock(target):
        if not target.is_file():raise ValueError('Missing source profile; cannot rebase an empty replacement')
        data=_load(owner,target);revision=data.get('revision')
        if type(revision) is not int or not 0<=revision<=9007199254740991:raise ValueError('Invalid stored profile revision')
        if revision<=current_revision:
            data['revision']=current_revision+1;_save(target,data)
        return data['revision']

def backfill(owner):
    try:cache=json.loads((ROOT/'work/sent-cache.json').read_text(encoding='utf-8'))
    except (OSError,ValueError):return
    profile=snapshot(owner);existing=profile['tracks'];affinity=set();verified={}
    for known in existing:
        composition=listening_key({**known,'artist':', '.join(track_artists(known))});affinity.add(composition)
        independent=known.get('metadataVerified') is True or known.get('catalogueState')=='verified'
        if known.get('metadataConfirmed') is True and independent:verified.setdefault(composition,[]).append(recording_duration(known))
    for known in profile.get('receivedTracks',[]):
        original=known.get('receivedIdentity') if isinstance(known,dict) else None
        if not is_received(known) or known.get('receivedEvidence')!='telegram-message' or known.get('receivedIdentityEvidence')!='telegram-message' or not isinstance(original,dict) or original.get('metadataConfirmed') is not True:continue
        composition=listening_key({**original,'artist':', '.join(track_artists(original))})
        verified.setdefault(composition,[]).append(recording_duration(original))
    for key,row in cache.items():
        if not isinstance(row,dict) or isinstance(row.get('owner'),bool) or row.get('owner')!=owner or not isinstance(row.get('file_id'),str) or not row['file_id'].strip():continue
        track={**row,'id':str(key).split(':')[0],'source':row.get('source','SoundCloud'),
            'metadataConfirmed':row.get('metadataConfirmed') is True,'lastSeen':row.get('created',time.time())*1000}
        composition=listening_key({**track,'artist':', '.join(track_artists(track))})
        # A positive cache file ID proves delivery, never the uploader's credits.
        # Only independent verified canonical history can confirm absent tags.
        if not track['metadataConfirmed']:
            duration=recording_duration(track)
            track['metadataConfirmed']=any(not duration or not known_duration or abs(duration-known_duration)<=max(5,.05*max(duration,known_duration)) for known_duration in verified.get(composition,()))
        learn=composition not in affinity and not track.get('recommendationOnly')
        if remember_received(owner,'cache:'+str(key),track,{'legacyFileId':row['file_id'],'learnLegacy':learn}) and learn:affinity.add(composition)

def forwarded_id(unique):return 'tg-'+hashlib.sha256(str(unique).encode()).hexdigest()[:24]

def track_artists(row):
    """Complete credited performers, including features stored outside artist."""
    guests=row.get('featuredArtists',[])
    guests=guests if isinstance(guests,list) else []
    guests=[g if isinstance(g,str) else str(g.get('name') or '') for g in guests[:12] if isinstance(g,(str,dict))]
    names=[str(row.get('artist') or ''),*guests]
    fixed=clean_track_tags({**row,'artist':clean_artist(', '.join(names)),'featuredArtists':guests})
    return list({identity(name):name for name in clean_artist(fixed.get('artist','')).split(', ') if identity(name)}.values())

def artist_statistics(rows,now=None):
    now=time.time()*1000 if now is None else now;artists={};recordings={}
    for row in rows:
        if not row.get('metadataConfirmed'):continue
        members=track_artists(row)
        recording=listening_key({**row,'artist':', '.join(members)})
        shares=recordings.setdefault(recording,{})
        for member in members:
            key=identity(member)
            if not key or 'неизвест' in member.casefold() or 'не подтвержд' in member.casefold():continue
            old=artists.get(key,{'key':key,'name':member,'tracks':0,'events':0,'lastSeen':0,'mass':0,'eventMass':0,'moment':0})
            count=max(1,min(100000,row.get('count',1)));share=shares.setdefault(key,{'count':0,'share':1/max(1,len(members)),'lastSeen':0});share['count']=min(100000,share['count']+count);share['lastSeen']=max(share['lastSeen'],row.get('lastSeen',now));artists[key]=old
    for shares in recordings.values():
        for key,row in shares.items():
            old=artists[key];old['tracks']+=1;old['events']+=row['count'];old['mass']+=row['share'];old['eventMass']+=min(64,row['count'])*row['share'];old['lastSeen']=max(old['lastSeen'],row['lastSeen'])
    for a in artists.values():a['weight']=(math.sqrt(a['mass'])+.45*math.log1p(a['eventMass']))*(.75+.25*math.exp(-max(0,now-a['lastSeen'])/(30*86400000)))
    return sorted(artists.values(),key=lambda a:a['weight'],reverse=True)

def preferences(rows,now=None):return [a['name'] for a in artist_statistics(rows,now)]
