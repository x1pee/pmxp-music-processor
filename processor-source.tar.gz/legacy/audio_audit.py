from runtime_security import run as private_run, popen as private_popen
"""Bounded edge-silence analysis of already downloaded audio; never fetch a URL."""
import json,os,re,subprocess,threading,time
from pathlib import Path
from media import ROOT,ffmpeg_path
from media_security import local_input

FIELDS=('audioAuditState','audioDuration','leadingSilence','trailingSilence','audioAuditVersion')
_lock=threading.RLock()
VERSION=1
_entries={};_loaded=None

def _read():
    global _entries,_loaded
    path=ROOT/'work/audio-audit.json'
    try:
        stamp=(str(path),path.stat().st_mtime_ns)
        if stamp!=_loaded:_entries=json.loads(path.read_text(encoding='utf-8'));_loaded=stamp
        return dict(_entries)
    except (OSError,ValueError):return {}

def _key(track):return str(track.get('source','SoundCloud'))+':'+str(track['id'])

def cached(track,source=None):
    # External downloads already inspect completeness and both edges in their
    # subprocess. Reuse that exact file measurement instead of decoding twice.
    if track.get('source') in ('YouTube','Bandcamp'):
        from external_sources import completed_download
        file,saved=completed_download(track)
        result=saved.get('audit',{})
        try:
            if file is not None and (source is None or Path(file).resolve()==Path(source).resolve()) and result.get('audioAuditState')=='verified' and result.get('audioAuditVersion')==VERSION and abs(float(track.get('duration') or saved['sourceDuration'])-saved['sourceDuration'])<=1:return {k:result[k] for k in FIELDS}
        except (KeyError,TypeError,ValueError):pass
    with _lock:entry=_read().get(_key(track))
    if not entry or entry.get('version')!=VERSION:return {}
    try:
        path=ROOT/'work'/entry['file']
        if path.is_symlink() or source is not None and Path(source).is_symlink():return {}
        stat=path.stat()
        if source is not None and path.resolve()!=Path(source).resolve():return {}
        if [stat.st_size,stat.st_mtime_ns]!=entry['stamp']:return {}
        if abs(float(track.get('duration') or entry['sourceDuration'])-entry['sourceDuration'])>1:return {}
    except (OSError,KeyError,TypeError,ValueError):return {}
    return entry['result']

def _run(args,deadline):
    remaining=deadline-time.monotonic()
    if remaining<=0:raise TimeoutError('Audio scan budget exceeded')
    return private_run([ffmpeg_path(),'-hide_banner','-nostdin','-threads','1',*args],capture_output=True,timeout=remaining)

def silence_intervals(log,duration):
    intervals=[];start=None
    for kind,value in re.findall(r'silence_(start|end):\s*(-?\d+(?:\.\d+)?)',log):
        value=max(0,min(duration,float(value)))
        if kind=='start':start=value
        elif start is not None:intervals.append((start,value));start=None
    if start is not None:intervals.append((start,duration))
    return intervals

def inspect(source):
    deadline=time.monotonic()+4
    source=Path(source)
    if not source.is_file() or source.is_symlink():raise ValueError('Not a local audio file')
    probe=_run(local_input(source),deadline)
    found=re.search(r'Duration: (\d+):(\d+):(\d+(?:\.\d+)?)',probe.stderr.decode('utf-8',errors='replace'))
    if not found:raise ValueError('No audio duration')
    duration=int(found[1])*3600+int(found[2])*60+float(found[3])
    if not 0<duration<=1085:raise ValueError('Invalid audio duration')
    def window(offset,length):
        run=_run(['-ss',str(offset),*local_input(source),'-t',str(length),'-map','0:a:0','-vn','-af','silencedetect=noise=-60dB:duration=0.5','-progress','pipe:1','-nostats','-f','null','-'],deadline)
        if run.returncode:raise ValueError('Audio edge scan failed')
        log=run.stderr.decode('utf-8',errors='replace')
        times=re.findall(r'^out_time_us=(\d+)$',run.stdout.decode('utf-8',errors='replace'),re.M)
        if not times:raise ValueError('No decoded duration')
        decoded=min(length,int(times[-1])/1000000)
        if decoded<=0:raise ValueError('No decoded audio')
        return silence_intervals(log,decoded),decoded
    length=min(20,duration);head,head_length=window(0,length)
    tail,tail_length=(head,head_length) if duration<=20 else window(duration-length,length)
    duration=(duration-length)+tail_length
    leading=max((end for start,end in head if start<=.05),default=0)
    trailing=max((tail_length-start for start,end in tail if end>=tail_length-.08),default=0)
    # A window filled with silence only provides a lower bound, not its full length.
    if leading>=head_length-.08 or trailing>=tail_length-.08:return {'audioAuditState':'inconclusive','audioAuditVersion':VERSION}
    return {'audioAuditState':'verified','audioDuration':round(duration,2),'leadingSilence':round(leading,2),'trailingSilence':round(trailing,2),'audioAuditVersion':VERSION}

def analyze(track,source):
    existing=cached(track,source)
    if existing:return existing
    try:
        result=inspect(source);path=Path(source);stat=path.stat()
        if path.parent.resolve()!=(ROOT/'work').resolve():return result
        with _lock:
            entries=_read();entries[_key(track)]={'version':VERSION,'file':path.name,'stamp':[stat.st_size,stat.st_mtime_ns],'sourceDuration':float(track.get('duration') or result.get('audioDuration',0)),'time':time.time(),'result':result}
            entries=dict(sorted(entries.items(),key=lambda x:x[1]['time'])[-1000:])
            temp=ROOT/'work/audio-audit.pending.json';temp.write_text(json.dumps(entries),encoding='utf-8');os.chmod(temp,0o600);temp.replace(ROOT/'work/audio-audit.json')
        return result
    except Exception:return {'audioAuditState':'unavailable','audioAuditVersion':VERSION}

def analyze_available(track):
    existing=cached(track)
    if existing:return existing
    if not re.fullmatch(r'(?:\d{1,20}|yt-[\w-]{11}|bc-[a-f0-9]{24})',str(track.get('id',''))):return {}
    for extension in ('m4a','mp3','opus','ogg','webm'):
        source=ROOT/'work'/('sc-'+str(track['id'])+'.'+extension)
        if source.is_file() and not source.is_symlink():return analyze(track,source)
    return {}

def effective_duration(track,audit=None):
    audit=audit if audit is not None else track
    total=float(audit.get('audioDuration',track.get('duration',0)))
    if audit.get('audioAuditState')!='verified':return total
    return max(0,total-max(0,float(audit.get('leadingSilence',0)))-max(0,float(audit.get('trailingSilence',0))))

def comparison_duration(track,audit=None,reference=None):
    """Keep catalogue edges unknown; silence may explain an excess, not create one."""
    import math
    audit=audit if audit is not None else track
    raw=float(audit.get('audioDuration',track.get('duration',0)))
    reference=float(reference if reference is not None else track.get('referenceDuration') or 0)
    if audit.get('audioAuditState')!='verified' or not math.isfinite(raw) or not math.isfinite(reference) or reference<=0:return raw
    trimmed=effective_duration(track,audit)
    return trimmed if math.isfinite(trimmed) and abs(trimmed-reference)<abs(raw-reference) else raw

def duration_tolerance(track):
    # A small catalogue difference can be rounding, an edit, or unmatched edges.
    # Do not classify it as an incorrect version or a change of playback speed.
    reference=float(track.get('referenceDuration') or track.get('duration') or 0)
    return max(3.0,min(5.0,reference*.02))

def notice(track,audit):
    verified=track.get('catalogueState')=='verified' and float(track.get('referenceDuration') or 0)>0
    delta=(comparison_duration(track,audit)-track['referenceDuration']) if verified else 0
    edges=[]
    if audit.get('audioAuditState')=='verified':
        for name,field in [('В начале','leadingSilence'),('В конце','trailingSilence')]:
            if audit.get(field,0)>=1.5:edges.append(name+' ≈'+str(round(audit[field]))+' с тишины')
    measured=audit.get('audioAuditState')=='verified'
    seconds=int(abs(delta)+.5)
    difference=('С учётом тишины на ' if measured else 'С каталогом: на ')+str(seconds)+' с '+('дольше' if delta>0 else 'короче')+' каталожной версии' if verified and measured and abs(delta)>duration_tolerance(track) else ''
    if difference and measured:difference+=' — это не подтверждает изменение скорости'
    elif difference:difference+=' — тишина ещё не проверена'
    elif verified and measured and edges:difference='Длительность в пределах допуска каталога'
    if not edges and not difference:return ''
    return '. '.join([x for x in [difference,*edges] if x])+'.'
