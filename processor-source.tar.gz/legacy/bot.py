"""Telegram client extracted from owned bot source; no bot loop."""
import json,time,urllib.request,urllib.parse
from pathlib import Path
MAX_INPUT=20*1024*1024

class TelegramWriteUncertain(RuntimeError):
    """Telegram may have accepted a write; never create an automatic fallback."""

class TelegramError(RuntimeError):
    def __init__(self,description='',retry_after=0):
        super().__init__('Telegram временно недоступен; попробуй ещё раз')
        self.message_missing=any(x in description.lower() for x in ('message to edit not found','message to delete not found'))
        self.not_modified='message is not modified' in description.lower()
        self.retry_after=retry_after
        self.text_edit_rejected=any(x in description.lower() for x in ('there is no text in the message to edit','message can\'t be edited','message cannot be edited'))
        self.media_edit_rejected=any(x in description.lower() for x in ('message to edit not found','message can\'t be edited','message cannot be edited','there is no media in the message to edit','method not found'))

class Telegram:
    def __init__(self,token):
        self.bot_id=token.split(':',1)[0];self.base='https://api.telegram.org/bot'+token+'/';self.filebase='https://api.telegram.org/file/bot'+token+'/'
        from telegram_transport import Transport
        self.transport=Transport(self.base)
    def call(self,method,fields,files=None,*,wait_on_rate_limit=True,timeout=75,on_progress=None):
        if files:
            from telegram_transport import Multipart
            body=Multipart(fields,files,on_progress=on_progress);ctype='multipart/form-data; boundary='+body.boundary
        else: body=json.dumps(fields,ensure_ascii=False).encode();ctype='application/json'
        writes_message=method.startswith(('send','editMessage'))
        try:
            status,data=self.transport.request(method,body,ctype) if timeout==75 else self.transport.request(method,body,ctype,timeout=timeout)
        except Exception:
            if writes_message:raise TelegramWriteUncertain('Не удалось подтвердить результат запроса Telegram') from None
            raise
        if writes_message and (status>=500 or not isinstance(data.get('ok'),bool) or (data.get('ok') and 'result' not in data)):
            raise TelegramWriteUncertain('Не удалось подтвердить результат запроса Telegram')
        if status==429:
            retry=data.get('parameters',{}).get('retry_after',3)
            if wait_on_rate_limit:time.sleep(min(60,retry))
            raise TelegramError(data.get('description',''),retry_after=max(1,float(retry)))
        if status>=400:raise TelegramError(data.get('description',''))
        if not data.get('ok'): raise TelegramError(data.get('description',''))
        return data['result']
    def queue_call(self,method,fields):
        return self.call(method,fields,wait_on_rate_limit=False,timeout=3)
    def text(self,chat,text,keyboard=None):
        fields={'chat_id':chat,'text':text[:4000]}
        if keyboard: fields['reply_markup']={'inline_keyboard':keyboard}
        return self.call('sendMessage',fields)
    def download(self,file_id,target):
        data=self.call('getFile',{'file_id':file_id})
        if data.get('file_size',0)>MAX_INPUT: raise ValueError('Файл больше 20 МБ')
        path=data['file_path']
        if '..' in path or path.startswith('/') or ':' in path: raise ValueError('Unexpected Telegram file path')
        with urllib.request.urlopen(self.filebase+urllib.parse.quote(path,safe='/'),timeout=60) as response: blob=response.read(MAX_INPUT+1)
        if len(blob)>MAX_INPUT: raise ValueError('Файл больше 20 МБ')
        Path(target).write_bytes(blob)
