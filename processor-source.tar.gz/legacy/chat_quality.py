from runtime_security import run as private_run, popen as private_popen
"""Inspect local media without decoding it or claiming an invented quality gain."""
import re,subprocess
from pathlib import Path
from media import ffmpeg_path
from media_security import local_input

def inspect(source):
    source=Path(source)
    if source.is_symlink() or not source.is_file():raise ValueError('Invalid quality input')
    run=private_run([ffmpeg_path(),'-hide_banner','-nostdin',*local_input(source)],capture_output=True,timeout=20)
    text=run.stderr.decode('utf-8',errors='replace')
    line=next((line for line in text.splitlines() if 'Stream #' in line and 'Audio:' in line),'')
    if not line:raise ValueError('No audio stream')
    codec=re.search(r'Audio:\s*([\w.-]+)',line)
    sample=re.search(r'(\d+) Hz',line)
    bitrate=re.search(r'(\d+(?:\.\d+)?) kb/s',line)
    total=re.search(r'Duration:.*?bitrate:\s*(\d+(?:\.\d+)?) kb/s',text)
    duration=re.search(r'Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)',text)
    channels=re.search(r'\b(mono|stereo|[0-9]+(?:\.[0-9]+)? channels)\b',line)
    container=re.search(r'Input #0, (.+?), from ',text)
    return {'codec':codec[1] if codec else None,'sampleRateHz':int(sample[1]) if sample else None,
        'bitrateKbps':float(bitrate[1]) if bitrate else None,'containerBitrateKbps':float(total[1]) if total else None,
        'channels':channels[1] if channels else None,'duration':int(duration[1])*3600+int(duration[2])*60+float(duration[3]) if duration else None,
        'bytes':source.stat().st_size,'sourceFormat':container[1] if container else None,'measured':True}

def describe(info,tr=lambda value:value):
    unknown=tr('Неизвестно')
    lines=[tr('Исходное качество'),tr('Кодек')+': '+str(info.get('codec') or unknown)]
    if info.get('sourceFormat'):lines.append(tr('Формат')+': '+info['sourceFormat'])
    bitrate=info.get('bitrateKbps')
    lines.append(tr('Битрейт аудио')+': '+(str(round(bitrate))+' kb/s' if bitrate else unknown))
    if not bitrate and info.get('containerBitrateKbps'):
        lines.append(tr('Битрейт контейнера')+': '+str(round(info['containerBitrateKbps']))+' kb/s')
    if info.get('sampleRateHz'):lines.append(tr('Частота')+': '+str(info['sampleRateHz'])+' Hz')
    if info.get('channels'):lines.append(tr('Каналы')+': '+info['channels'])
    if info.get('duration'):
        seconds=round(info['duration']);lines.append(tr('Длительность')+': '+str(seconds//60)+':'+str(seconds%60).zfill(2))
    lines.append(tr('Размер')+': '+str(round(info['bytes']/1024/1024,2))+' MB')
    return '\n'.join(lines)+'\n\n'+tr('Увеличение битрейта не улучшает исходную запись.')
