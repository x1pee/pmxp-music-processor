"""Fixed subprocess capability; provider children never inherit service/bot secrets."""
import os
import subprocess
import sys
from pathlib import Path

_CODE = Path(__file__).resolve().parent
_SCRIPTS = {'source_cli.py', 'external_sources.py', 'provider_worker.py', 'download_worker.py'}


def child_environment():
    return {key: value for key, value in os.environ.items()
            if key not in {'TELEGRAM_BOT_TOKEN', 'MINI_PROCESSOR_SECRET'} and not key.lower().endswith('_proxy')}


def check(command, kwargs):
    if not isinstance(command, (list, tuple)) or not command or kwargs.get('shell'):
        raise PermissionError('Arbitrary shell execution blocked')
    executable = Path(command[0]).resolve()
    if executable == Path(sys.executable).resolve():
        scripts = [Path(arg).resolve() for arg in command[1:] if isinstance(arg, str) and arg.endswith('.py')]
        if len(scripts) != 1 or scripts[0].parent != _CODE or scripts[0].name not in _SCRIPTS:
            raise PermissionError('Unapproved provider subprocess')
    elif Path(command[0]).name not in {'ffmpeg', 'ffmpeg.exe'}:
        raise PermissionError('Unapproved executable')
    kwargs['env'] = child_environment()


def run(command, *args, **kwargs):
    check(command, kwargs)
    return subprocess.run(command, *args, **kwargs)


def popen(command, *args, **kwargs):
    check(command, kwargs)
    return subprocess.Popen(command, *args, **kwargs)
