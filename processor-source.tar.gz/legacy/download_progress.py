from runtime_security import run as private_run, popen as private_popen
"""Bounded local status channel; source JSON stdout and download speed stay intact."""
import json,math,os,re,subprocess,tempfile,threading,time
from pathlib import Path
from media import ROOT

def finite(value):
    return isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value)

def progress_hook(path):
    if not path:return lambda status:None
    target=Path(path).resolve();work=(ROOT/'work').resolve()
    if target.parent!=work or not re.fullmatch(r'progress-[a-zA-Z0-9_-]+\.json',target.name):raise ValueError('Invalid progress channel')
    last=[0]
    def hook(status):
        try:
            now=time.monotonic()
            if now-last[0]<.5 and status.get('status')!='finished':return
            done,total=status.get('downloaded_bytes'),status.get('total_bytes')
            fragments,count=status.get('fragment_index'),status.get('fragment_count')
            row={'stage':'download','updatedAt':round(time.time()*1000)}
            if finite(done) and done>=0 and finite(total) and total>0:row.update(bytesDone=min(done,total),bytesTotal=total)
            elif finite(fragments) and fragments>=0 and finite(count) and count>0:row.update(fragmentsDone=min(fragments,count),fragmentsTotal=count)
            else:return # Estimated filesize is not an observed total.
            speed=status.get('speed')
            if finite(speed) and speed>0:row['speedBytesPerSecond']=speed
            pending=target.with_suffix('.pending.json');pending.write_text(json.dumps(row),encoding='utf-8');os.chmod(pending,0o600);pending.replace(target);last[0]=now
        except (OSError,ValueError,TypeError):pass # Status never fails audio delivery.
    return hook

def run_with_progress(command,payload,timeout,on_progress):
    work=ROOT/'work';work.mkdir(parents=True,exist_ok=True)
    fd,name=tempfile.mkstemp(prefix='progress-',suffix='.json',dir=work);os.close(fd);target=Path(name)
    stop=threading.Event();last=[None]
    def read():
        try:
            if target.stat().st_size>2048:return
            row=json.loads(target.read_text(encoding='utf-8'))
            if row!=last[0]:last[0]=row;on_progress(row)
        except Exception:pass
    def watch():
        while not stop.wait(.3):read()
    thread=threading.Thread(target=watch,name='download-progress',daemon=True);thread.start()
    try:
        return private_run(command,input=json.dumps({**payload,'progressPath':str(target.resolve())},ensure_ascii=False),capture_output=True,text=True,encoding='utf-8',timeout=timeout)
    finally:
        stop.set();thread.join(.5);read()
        target.unlink(missing_ok=True);target.with_suffix('.pending.json').unlink(missing_ok=True)
