"""Prefer a ready container only when the source audio is technically equivalent."""
import math
def number(value):
    return value if isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value) else None

def ready_audio_selector(info):
    # yt-dlp supplies formats in its normal worst-to-best preference order.
    audio=[f for f in info.get('formats',[]) if f.get('vcodec')=='none' and f.get('acodec') not in (None,'none') and not f.get('has_drm')]
    if not audio:
        combined=[f for f in info.get('formats',[]) if f.get('vcodec') not in (None,'none') and f.get('acodec') not in (None,'none') and not f.get('has_drm')]
        if combined:yield combined[-1]
        return
    best=audio[-1]
    if best.get('ext')=='m4a' and best.get('protocol') in ('http','https') and best.get('acodec','').startswith(('aac','mp4a')):
        yield best;return
    if not best.get('acodec','').startswith(('aac','mp4a')):
        yield best;return # AAC and Opus cannot be ranked by bitrate alone.
    def equivalent(f):
        if f.get('ext')!='m4a' or f.get('protocol') not in ('http','https') or f.get('acodec')!=best.get('acodec'):return False
        if number(best.get('abr')) is None or best['abr']<=0:return False
        for key in ('quality','preference','source_preference','language_preference','abr','asr','audio_channels'):
            old,new=number(best.get(key)),number(f.get(key))
            if (old is None)!=(new is None) or old is not None and new<old:return False
        return True
    yield next((f for f in reversed(audio) if equivalent(f)),best)
