"""Artist top songs from public Music catalogue, with bounded reusable pages."""
import hashlib,itertools,json,re,time
from media import ROOT
from query_normalizer import variants,artist_matches,remember_artist,resolve_known
from work_cache import atomic_json,keyed_lock
def nodes(value,wanted):
    if isinstance(value,dict):
        for key,child in value.items():
            if key in wanted:yield child
            else:yield from nodes(child,wanted)
    elif isinstance(value,list):
        for child in value:yield from nodes(child,wanted)
def artist_entry(renderer,entry):
    if not entry or renderer.get('playlistItemData',{}).get('videoId'):return entry
    ident=entry.get('id','')
    if not re.fullmatch(r'UC[\w-]{22}',ident):return entry
    columns=renderer.get('flexColumns') or []
    runs=columns[0].get('musicResponsiveListItemFlexColumnRenderer',{}).get('text',{}).get('runs',[]) if columns else []
    name=''.join(r.get('text','') for r in runs)
    return {**entry,'_pmx_artist_name':name} if name else entry
def load(path):
    try:
        data=json.loads(path.read_text(encoding='utf-8'))
        return data if time.time()-data.get('time',0)<1800 else None
    except (OSError,ValueError):return None
def save(path,data):
    atomic_json(path,data)
    # Metadata only; retain at most 512 artist searches on disk.
    try:
        older=sorted(path.parent.glob('*.json'),key=lambda p:p.stat().st_mtime)
        for item in older[:-512]:item.unlink(missing_ok=True)
    except OSError:pass

def artist_songs(ie,query,offset,parse):
    query=resolve_known(query);signature=hashlib.sha256(('v3-music-art:'+query.casefold()).encode()).hexdigest()[:24]
    folder=ROOT/'work/music-catalogue';path=folder/(signature+'.json')
    with keyed_lock(('music-catalogue',signature)):
        cached=load(path)
        if cached is None:
            index=folder/(signature+'-identity.json');identity=None
            try:
                saved=json.loads(index.read_text())
                endpoint=saved.get('endpoint')
                if time.time()-saved['time']<21600 and artist_matches(query,saved['artist']) and isinstance(endpoint,dict) and isinstance(endpoint.get('browseId'),str):identity=saved
            except (OSError,ValueError,KeyError,TypeError):pass
            if identity:
                try:
                    endpoint=identity['endpoint'];data=ie._extract_response(item_id=endpoint['browseId'],ep='browse',query=endpoint,default_client='web_music')
                    cached={'time':time.time(),'artist':identity['artist'],'rows':[],'continuation':None};append_page(cached,data,ie,parse)
                    if cached['rows']:save(path,cached)
                    else:cached=None
                except Exception:cached=None
            if cached is None:
                chosen=[]
                # Latin-to-Cyrillic keyboard guesses add an extra request to every
                # ordinary English song query, without helping artist detection.
                candidates=variants(query) if re.search(r'[а-яё]',query,re.I) else [query]
                for variant in candidates:
                    found=list(itertools.islice(ie._search_results(variant,ie._SECTIONS['artists'],default_client='web_music'),5))
                    chosen=[a for a in found if a.get('_pmx_artist_name') and artist_matches(query,a['_pmx_artist_name'])]
                    if chosen:break
                    if len(candidates)==1:break
                names={a['_pmx_artist_name'].casefold() for a in chosen}
                if len(names)!=1:
                    save(path,{'time':time.time(),'artist':None});return None
                artist=chosen[0];name=artist['_pmx_artist_name']
                data=ie._extract_response(item_id=artist['id'],ep='browse',query={'browseId':artist['id']},default_client='web_music')
                shelves=list(nodes(data,{'musicShelfRenderer'}))
                shelf=next((s for s in shelves if s.get('bottomEndpoint',{}).get('browseEndpoint') and any(
                    item.get('musicResponsiveListItemRenderer',{}).get('playlistItemData',{}).get('videoId') for item in s.get('contents',[]))),None)
                if shelf is None:save(path,{'time':time.time(),'artist':None});return None
                endpoint=shelf['bottomEndpoint']['browseEndpoint']
                save(index,{'time':time.time(),'artist':name,'endpoint':{k:endpoint[k] for k in ('browseId','params') if k in endpoint}})
                data=ie._extract_response(item_id=endpoint['browseId'],ep='browse',query={k:endpoint[k] for k in ('browseId','params') if k in endpoint},default_client='web_music')
                cached={'time':time.time(),'artist':name,'rows':[],'continuation':None};append_page(cached,data,ie,parse)
                remember_artist(query,name);save(path,cached)
        if not cached.get('artist'):return None
        # Follow real continuation tokens; do not hard-stop after 100 songs.
        for _ in range(4):
            if len(cached['rows'])>=offset+11 or not cached.get('continuation'):break
            token=cached['continuation'];data=ie._extract_response(item_id=cached['artist'],ep='browse',query=token,default_client='web_music')
            append_page(cached,data,ie,parse)
            if cached.get('continuation')==token:cached['continuation']=None
            save(path,cached)
        rows=cached['rows'][offset:offset+10]
        return {'entries':rows,'nextOffset':offset+10 if offset+10<len(cached['rows']) or cached.get('continuation') else None,'resolvedQuery':cached['artist'],'ranking':'artist-top-songs'}
def append_page(cached,data,ie,parse):
    shelves=list(nodes(data,{'musicPlaylistShelfRenderer','musicPlaylistShelfContinuation','musicShelfRenderer','musicShelfContinuation'}))
    # A playlist can contain a second recommendation shelf; only its own songs.
    ids={r['id'] for r in cached['rows']}
    if not shelves:cached['continuation']=None;return
    shelf=shelves[0]
    for wrapped in shelf.get('contents',[]):
        renderer=wrapped.get('musicResponsiveListItemRenderer')
        if not renderer:continue
        ident=renderer.get('playlistItemData',{}).get('videoId','')
        title_runs=(renderer.get('flexColumns') or [{}])[0].get('musicResponsiveListItemFlexColumnRenderer',{}).get('text',{}).get('runs',[])
        row=parse(renderer,{'id':ident,'title':''.join(r.get('text','') for r in title_runs)})
        credits=re.split(r'\s*(?:,|&)\s*',row.get('artist','')) if row else []
        if row and any(artist_matches(cached['artist'],credit) for credit in credits) and ident not in ids and len(cached['rows'])<10000:
            cached['rows'].append(row);ids.add(ident)
    cached['continuation']=ie._extract_continuation(shelf) if len(cached['rows'])<10000 else None
