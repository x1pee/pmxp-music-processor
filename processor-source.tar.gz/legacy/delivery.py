import json,secrets,time,threading,hashlib,weakref
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from pathlib import Path
from media import ROOT,convert_audio,download_cover,safe_name,telegram_audio_details,prepare_cover_thumbnail
from source import download_track
from telegram_identity import document_id
from library import clean_title,clean_artist
from audio_audit import analyze,analyze_available,cached as cached_audit
from silence_trim import trim_plan,trim_percent
from extended_tags import optional_fields,fields_key

cache_lock=threading.Lock()
track_locks=weakref.WeakValueDictionary()
prepare_slots=threading.BoundedSemaphore(1)
# Two preparations can overlap two uploads, with at most four cold jobs holding
# ready temporary files. Cached Telegram IDs bypass both network/preparation gates.
pipeline_slots=threading.BoundedSemaphore(1)
upload_slots=threading.BoundedSemaphore(1)

class StageTimings:
    """Bounded monotonic intervals; parallel work overlaps instead of being summed."""
    STAGES=frozenset(('wait','cache','cover','download','convert','thumbnail','upload','cached-send'))
    LIMIT=24
    MAX_MS=3600000
    def __init__(self,on_update=None,started=None,clock=None,mode='measured'):
        self.clock=clock or time.monotonic;self.started=self.clock() if started is None else started
        self.mode='coarse' if mode=='coarse' else 'measured';self.run_id=secrets.token_hex(16)
        self.on_update=on_update;self.lock=threading.RLock();self.rows=[];self.revision=1;self.finished=None;self.truncated=False
    def offset(self,now):
        value=max(0,int((now-self.started)*1000))
        if value>self.MAX_MS and not self.truncated:self.truncated=True;self.revision+=1
        return min(self.MAX_MS,value)
    def snapshot(self):
        with self.lock:
            elapsed=self.offset(self.finished if self.finished is not None else self.clock())
            return {'timingVersion':1,'timingRunId':self.run_id,'timingRevision':self.revision,'timingMode':self.mode,
                    'workerElapsedMs':elapsed,'cumulativeStageTimings':[dict(row) for row in self.rows],
                    **({'timingTruncated':True} if self.truncated else {})}
    def notify(self):
        if self.on_update:
            try:self.on_update(self.snapshot())
            except Exception:pass  # Best-effort telemetry cannot fail delivery.
    def begin(self,stage):
        with self.lock:
            if not isinstance(stage,str) or stage not in self.STAGES or self.finished is not None:return None
            if len(self.rows)>=self.LIMIT:
                if not self.truncated:self.truncated=True;self.revision+=1
                ident=None
            else:
                ident=len(self.rows)+1;self.rows.append({'id':ident,'stage':stage,'startOffsetMs':self.offset(self.clock()),'durationMs':None,'status':'running'});self.revision+=1
        self.notify();return ident
    def end(self,ident,status='done'):
        with self.lock:
            if not isinstance(ident,int) or isinstance(ident,bool) or not 1<=ident<=len(self.rows) or self.finished is not None:return
            row=self.rows[ident-1]
            if row['status']!='running':return
            row['durationMs']=max(0,self.offset(self.clock())-row['startOffsetMs']);row['status']='failed' if status=='failed' else 'done';self.revision+=1
        self.notify()
    def finish(self,failed=False):
        with self.lock:
            if self.finished is not None:return self.snapshot()
            self.finished=self.clock();end=self.offset(self.finished)
            for row in self.rows:
                if row['status']=='running':row['durationMs']=max(0,end-row['startOffsetMs']);row['status']='failed' if failed else 'done'
            self.revision+=1
        self.notify();return self.snapshot()
    def transition(self,stage):
        # Imported Telegram files currently expose serial stage callbacks only.
        # Mark these intervals coarse rather than inventing unobserved stages.
        with self.lock:active=[row['id'] for row in self.rows if row['status']=='running']
        for ident in active:self.end(ident)
        return self.begin(stage)
    def call(self,stage,fn,*args,**kwargs):
        ident=self.begin(stage)
        try:result=fn(*args,**kwargs)
        except BaseException:self.end(ident,'failed');raise
        self.end(ident)
        message=result.get('message_id') if isinstance(result,dict) else None
        if stage in ('upload','cached-send') and isinstance(message,int) and not isinstance(message,bool) and message>0:self.finish()
        return result

@contextmanager
def timing_wait(timings):
    ident=timings.begin('wait') if timings else None
    def ready():
        if timings:timings.end(ident)
    try:yield ready
    except BaseException:
        if timings:timings.end(ident,'failed')
        raise
    finally:
        if timings:timings.end(ident)

@contextmanager
def preparation_permit():
    prepare_slots.acquire()
    released=False
    def release():
        nonlocal released
        if not released:
            released=True
            prepare_slots.release()
    try:yield release
    finally:release()

site_slots=threading.BoundedSemaphore(1)
inspection_slots=threading.BoundedSemaphore(1)
inspection_pool=ThreadPoolExecutor(max_workers=1,thread_name_prefix='delivery-audit')
def inspect_later(track,source):
    if not inspection_slots.acquire(blocking=False):return None
    try:future=inspection_pool.submit(analyze,track,source)
    except Exception:inspection_slots.release();return None
    future.add_done_callback(lambda _:inspection_slots.release())
    return future

site_pool=ThreadPoolExecutor(max_workers=1,thread_name_prefix='site-audio')
def publish_later(task):
    # Optional site work has bounded capacity and never occupies a delivery slot.
    if not site_slots.acquire(blocking=False):return None
    try:future=site_pool.submit(task)
    except Exception:site_slots.release();return None
    future.add_done_callback(lambda _:site_slots.release())
    return future

def publish_prepared(owner,track,result,prepared,publisher):
    if not publisher:return
    def run():
        variant=prepared.get('_variant',{});recording=variant.get('recording_id')
        fields=prepared['fields'];meta={'title':fields['title'],'artist':fields['performer'],'duration':result.get('audio',{}).get('duration',prepared.get('duration',0))}
        if not recording:
            source=(prepared.get('files') or {}).get('audio')
            if isinstance(source,tuple):source=source[0]
            if source and Path(source).stat().st_size<=15*1024*1024:
                recording=publisher('recording_prepare',{'file':Path(source).name,'metadata':meta}).get('id')
            else:
                with cache_lock:
                    try:cache=json.loads((ROOT/'work/sent-cache.json').read_text())
                    except (OSError,ValueError):cache={}
                    recording=next((r.get('recording_id') for r in cache.values() if r.get('owner')==owner and r.get('file_id')==result['audio']['file_id']),None)
        if not recording:return
        publisher('recording_sent',{'documentId':document_id(result['audio'].get('file_unique_id')),'id':recording,'metadata':meta})
        with cache_lock:
            path=ROOT/'work/sent-cache.json'
            try:cache=json.loads(path.read_text())
            except (OSError,ValueError):return
            for row in cache.values():
                if row.get('owner')==owner and row.get('file_id')==result['audio']['file_id']:row['recording_id']=recording
            from work_cache import atomic_json
            atomic_json(path,cache)
    def safe():
        try:run()
        except Exception:print('Prepared site mapping deferred.',flush=True)
    publish_later(safe)

def record_sent(api,owner,track,fmt,result,prepared=None):
    audio=result.get('audio') or {}
    if not audio.get('file_id'):return
    variant=dict((prepared or {}).get('_variant') or {})
    percent=trim_percent(variant.get('trimPercent',track.get('trimPercent',0)))
    fields=(prepared or {}).get('fields') or {}
    title=variant.get('title',fields.get('title',track['title']))
    artist=variant.get('artist',fields.get('performer',track['artist']))
    key=track['id']+':'+fmt+(':tail'+str(percent) if percent else '')
    path=ROOT/'work/sent-cache.json'
    with cache_lock:
        try:cache=json.loads(path.read_text(encoding='utf-8'))
        except (FileNotFoundError,ValueError):cache={}
        old=cache.get(key)
        art=variant.get('artwork_key',artwork_cache_key(track))
        tags_key=fields_key(track)
        if old and (old.get('owner'),old.get('title'),old.get('artist'),old.get('artwork_key'),old.get('tagFieldsKey'))!=(owner,title,artist,art,tags_key):
            stamp=hashlib.sha256(json.dumps([old.get('owner'),old.get('artist'),old.get('title'),old.get('artwork_key'),old.get('tagFieldsKey')],ensure_ascii=False).encode()).hexdigest()[:20]
            cache[key+':'+stamp]=old
        cache[key]={**variant,'botId':getattr(api,'bot_id',None),'source':track.get('source','SoundCloud'),'owner':owner,
                    'title':title,'artist':artist,'artwork_key':art,'trimPercent':percent,'manualTagsVersion':2,'tagFieldsKey':tags_key,
                    'file_id':audio['file_id'],'document_id':document_id(audio.get('file_unique_id')),
                    'duration':audio.get('duration',fields.get('duration',track.get('duration',0))),'created':time.time(),
                    'recommendationOnly':bool(track.get('recommendationOnly'))}
        from work_cache import atomic_json
        atomic_json(path,cache)

def after_send(task,*args):
    # Once Telegram returned a message ID, optional bookkeeping cannot turn
    # that delivery into a failure that invites a duplicate user retry.
    try:return task(*args)
    except Exception:print('Telegram delivery confirmed; cache maintenance deferred.',flush=True)

_active_foreground=0
def foreground_active():
    with cache_lock:return _active_foreground>0

def prepare_tracks(api,owner,tracks,fmt):
    prepared=[]
    for track in tracks[:3]:
        if foreground_active():break
        try:send_track(api,owner,track,fmt,prepare_only=True);prepared.append(track['id'])
        except Exception:pass
    return {'prepared':prepared}

def cover_candidates(track):
    original=track.get('tagsMode','corrected')=='original' or track.get('manualTags',{}).get('coverMode',track.get('coverMode'))=='original'
    if not original and track.get('manualTags',{}).get('coverUrl'):
        return [track['manualTags']['coverUrl']]
    if original:return list(dict.fromkeys(filter(None,[track.get('originalDownloadCover'),track.get('originalCover'),track.get('downloadCover'),track.get('cover')])))
    return list(dict.fromkeys(filter(None,[track.get('catalogueCover'),track.get('downloadCover'),track.get('cover')])))

def artwork_cache_key(track):
    urls=cover_candidates(track)
    return hashlib.sha256(((urls[0] if urls else '')+':catalogue-art-v1').encode()).hexdigest() if urls or track.get('source')=='YouTube' or track.get('catalogueCover') or track.get('manualTags',{}).get('coverMode') else None

def download_track_cover(track,target):
    # A Music song has square album artwork; the video thumbnail is a fallback.
    last_error=None
    for url in cover_candidates(track):
        try:
            cover=download_cover(url,target)
            try:prepare_cover_thumbnail(cover)
            except Exception:pass  # Optional warming cannot change artwork selection.
            return cover
        except Exception as error:last_error=error
    if last_error:raise last_error
    return None

class TransferAPI:
    def __init__(self,api,callback):self.api=api;self.callback=callback
    def __getattr__(self,name):return getattr(self.api,name)
    def call(self,method,fields,files=None):
        if method=='sendAudio' and files:return self.api.call(method,fields,files,on_progress=self.callback)
        return self.api.call(method,fields,files)

def delivery_track(track,enqueue=False):
    if track.get('tagsMode','corrected')!='original':
        from tag_resolver import canonicalize
        return canonicalize({**track,'title':clean_title(track['title']),'artist':clean_artist(track['artist'])},enqueue=enqueue)
    return {**track,'title':track.get('original') or track['title'],'artist':track.get('originalArtist') or track['artist'],'cover':track.get('originalCover',track.get('cover','')),'downloadCover':track.get('originalDownloadCover',track.get('downloadCover',''))}

def send_track(api,owner,track,fmt,on_stage=None,publisher=None,prepare_only=False,on_progress=None,timings=None):
    if on_progress:api=TransferAPI(api,on_progress)
    started=time.monotonic()
    if prepare_only:timings=None  # A speculative preparation is not a user send.
    from prepared_cache import identity,leased,store
    # Resolve cached local metadata before locking its exact private variant.
    # Source download_track already deduplicates the public original by track ID.
    track=delivery_track(track,enqueue=True)
    key=identity(track,fmt,owner,getattr(api,'bot_id',None))
    with cache_lock:
        lock=track_locks.setdefault(key,threading.Lock())
    global _active_foreground
    if not prepare_only:
        with cache_lock:_active_foreground+=1
    waiting=timings.begin('wait') if timings else None
    try:
        with lock,leased(key,pipeline_slots) as prepared:
            if timings:timings.end(waiting)
            print('Audio wait='+str(round(time.monotonic()-started,2)),flush=True)

            if prepared:
                if prepare_only:return prepared
                cached=not bool(prepared.get('files'))
                if cached:
                    if on_stage:on_stage('cached-send')
                    result=timings.call('cached-send',api.call,'sendAudio',prepared['fields']) if timings else api.call('sendAudio',prepared['fields'])
                else:
                    with timing_wait(timings) as ready,upload_slots:
                        ready()
                        if on_stage:on_stage('upload')
                        result=timings.call('upload',api.call,'sendAudio',prepared['fields'],prepared['files']) if timings else api.call('sendAudio',prepared['fields'],prepared['files'])
                after_send(record_sent,api,owner,track,fmt,result,prepared)
                after_send(publish_prepared,owner,track,result,prepared,publisher)
                # Future reuse should send Telegram's exact variant by ID.
                retained={**prepared,'fields':{**prepared['fields'],'audio':result['audio']['file_id']},'files':{}}
                after_send(store,key,retained)
                return {'message_id':result['message_id'],'duration':result.get('audio',{}).get('duration',prepared.get('duration')),
                        'cached':cached,'preparedReused':True,'trimFacts':prepared.get('_variant',{}).get('trimFacts'),
                        'trackAudit':{'id':track['id'],**prepared.get('_variant',{}).get('trackAudit',{})},**(timings.snapshot() if timings else {})}
            prepared=_send_track(api,owner,track,fmt,on_stage,publisher,prepare_only=prepare_only,on_progress=on_progress,_canonical=True,_timings=timings)
            if prepare_only:store(key,prepared)
            return {**prepared,**timings.snapshot()} if timings else prepared
    except BaseException:
        if timings:timings.finish(failed=True)
        raise
    finally:
        if not prepare_only:
            with cache_lock:_active_foreground-=1

from bot_media_cache import same_bot,archive_file

def _send_track(api,owner,track,fmt,on_stage=None,publisher=None,_prepared=False,prepare_only=False,on_progress=None,_canonical=False,_release_prepare=None,_timings=None):
    corrected=track.get('tagsMode','corrected')!='original'
    if not _canonical:track=delivery_track(track,enqueue=True)
    def timed(stage,fn,*args,**kwargs):
        started=time.monotonic()
        if on_stage and stage!='cover':on_stage(stage)
        try:return _timings.call(stage,fn,*args,**kwargs) if _timings else fn(*args,**kwargs)
        finally:print('Audio '+stage+'='+str(round(time.monotonic()-started,2))+' at='+str(round(time.time(),3)),flush=True)
    if fmt not in {'mp3','m4a'}:raise ValueError('Unsupported format')
    cache_path=ROOT/'work'/'sent-cache.json'
    try:cache=json.loads(cache_path.read_text(encoding='utf-8'))
    except (FileNotFoundError,ValueError):cache={}
    percent=trim_percent(track.get('trimPercent',0))
    key=track['id']+':'+fmt+(':tail'+str(percent) if percent else '')
    artwork_key=artwork_cache_key(track)
    # Retain each tag variant rather than evicting the previous original/corrected
    # upload. A failed optional site publication must not disable Telegram's cache.
    variants=[row for saved,row in cache.items() if (saved==key or saved.startswith(key+':')) and row.get('trimPercent',0)==percent and row.get('owner')==owner and row.get('title')==track['title'] and row.get('artist')==track['artist'] and row.get('tagFieldsKey')==fields_key(track) and (not track.get('manualTags') or row.get('manualTagsVersion')==2) and (artwork_key is None or row.get('artwork_key')==artwork_key)]
    # Prefer a reusable current-bot file over an older migration row. Keep
    # owner and exact metadata/artwork matching before considering bot IDs.
    cached=next((row for row in variants if row.get('file_id') and same_bot(row,api)),next(iter(variants),None))
    if cached and not same_bot(cached,api):
        local=archive_file(cached)
        if local:
            fields={'chat_id':owner,'title':track['title'],'performer':track['artist'],'duration':cached.get('duration',track.get('duration',0)),'disable_notification':True}
            files={'audio':(local,safe_name(track['artist'],track['title'])+'.'+fmt)}
            try:
                _,thumb=timed('thumbnail',telegram_audio_details,local,ROOT/'work'/('migration-'+secrets.token_hex(6)+'-thumb.jpg'))
                if thumb:files['thumbnail']=thumb
            except Exception:pass
            if prepare_only:return {'fields':fields,'files':files,'duration':fields['duration'],'_variant':dict(cached)}
            old_file=cached.get('file_id')
            if _release_prepare:_release_prepare()
            with timing_wait(_timings) as ready,upload_slots:
                ready();result=timed('upload',api.call,'sendAudio',fields,files)
            def retain_migration():
                with cache_lock:
                    fresh=json.loads(cache_path.read_text(encoding='utf-8'))
                    for row in fresh.values():
                        if row.get('file_id')==old_file and row.get('owner')==owner:
                            row['file_id']=result['audio']['file_id'];row['botId']=getattr(api,'bot_id',None);row['document_id']=document_id(result['audio'].get('file_unique_id'))
                    temp=cache_path.with_suffix('.pending.json');temp.write_text(json.dumps(fresh),encoding='utf-8');temp.replace(cache_path)
            after_send(retain_migration)
            if publisher and cached.get('recording_id'):
                def publish_migrated():
                    try:publisher('recording_sent',{'documentId':document_id(result['audio'].get('file_unique_id')),'id':cached['recording_id'],'metadata':{'title':track['title'],'artist':track['artist'],'duration':fields['duration']}})
                    except Exception:pass
                publish_later(publish_migrated)
            return {'message_id':result['message_id'],'duration':result.get('audio',{}).get('duration',fields['duration']),'has_thumbnail':bool(result.get('audio',{}).get('thumbnail')),'cached':False,'preparedReused':True,'trimFacts':cached.get('trimFacts'),'trackAudit':{'id':track['id'],**cached.get('trackAudit',{})}}
        cached=None
    if cached:
        audit=cached_audit(track)
        if not audit and abs(float(track.get('duration') or 0)-float(cached.get('auditSourceDuration') or 0))<=1:audit=cached.get('trackAudit',{})
        fields={'chat_id':owner,'audio':cached['file_id'],'title':track['title'],'performer':track['artist'],'disable_notification':True}
        if prepare_only:return {'fields':fields,'files':{},'duration':cached.get('duration',track.get('duration',0)),'_variant':dict(cached)}
        result=timed('cached-send',api.call,'sendAudio',fields)
        if publisher and cached.get('recording_id'):
            def map_cached():
                try:publisher('recording_sent',{'documentId':document_id(result.get('audio',{}).get('file_unique_id')),'id':cached['recording_id'],'metadata':{'title':track['title'],'artist':track['artist'],'duration':cached.get('duration',track.get('duration',0))}})
                except Exception:pass
            publish_later(map_cached)
        return {'message_id':result['message_id'],'duration':result.get('audio',{}).get('duration'),'has_thumbnail':bool(result.get('audio',{}).get('thumbnail')),'cached':True,'trimFacts':cached.get('trimFacts'),'trackAudit':{'id':track['id'],**audit}}
    if not _prepared:
        waiting=time.monotonic()
        with timing_wait(_timings) as ready,pipeline_slots,preparation_permit() as release:
            ready()
            print('Audio prepare-wait='+str(round(time.monotonic()-waiting,2)),flush=True)
            # Recheck the private variant after waiting, using the same tags.
            # Release preparation capacity as soon as immutable ready bytes exist.
            return _send_track(api,owner,track,fmt,on_stage,publisher,True,prepare_only,on_progress,_canonical=True,_release_prepare=release,_timings=_timings)
    cover=None;nonce=secrets.token_hex(6);prepared_cover_urls=cover_candidates(track)
    # Fetch artwork alongside audio instead of adding another serial network wait.
    with ThreadPoolExecutor(max_workers=1) as pool:
        pending=pool.submit(timed,'cover',download_track_cover,track,ROOT/'work'/('sc-'+nonce+'-cover.jpg')) if cover_candidates(track) else None
        original=timed('download',lambda t:download_track(t,on_progress=on_progress),track) if on_progress else timed('download',download_track,track)
        if pending:
            try:cover=pending.result()
            except Exception:
                if track.get('manualTags',{}).get('coverUrl'):raise RuntimeError('Не удалось загрузить выбранную обложку. Повтори отправку.') from None
    output_id=track['id'] if track['id'].isdigit() else str(int(hashlib.sha256(track['id'].encode()).hexdigest()[:15],16))
    output=ROOT/'work'/('sc-'+output_id+'-'+nonce+'.'+fmt)
    if corrected:
        from tag_resolver import canonicalize
        track=canonicalize(track)
        # Retry only when metadata supplied different candidates. Repeating
        # the identical failed list adds another complete network timeout.
        if cover_candidates(track) and cover_candidates(track)!=prepared_cover_urls:
            try:cover=timed('cover',download_track_cover,track,ROOT/'work'/('sc-'+nonce+'-cover.jpg'))
            except Exception:
                if track.get('manualTags',{}).get('coverUrl'):raise RuntimeError('Не удалось загрузить выбранную обложку. Повтори отправку.') from None
        artwork_key=artwork_cache_key(track)
    trim=trim_plan(original,percent) if percent else None
    inspection=inspect_later(track,original)
    extra=optional_fields(track)
    timed('convert',convert_audio,original,output,track['artist'],track['title'],cover,corrected and not track.get('manualTags'),trim.get('endAt') if trim else None,**({'extra_tags':extra} if extra else {}))
    if output.stat().st_size>49*1024*1024:raise RuntimeError('Файл слишком большой для Telegram. Выбери другой трек.')
    duration,thumb=timed('thumbnail',telegram_audio_details,output,ROOT/'work'/('sc-'+nonce+'-thumb.jpg'),cover)
    # Ready audio does not wait for optional analysis. No unbounded work queue.
    audit=inspection.result() if inspection and inspection.done() else cached_audit(track)
    recording=None;delivery_ready=threading.Event();delivered={}
    def prepare_recording():
        try:return publisher('recording_prepare',{'file':output.name,'metadata':{'title':track['title'],'artist':track['artist'],'duration':duration}}).get('id')
        except Exception:print('Site audio staging unavailable; desktop fallback retained.',flush=True)
    files={'audio':(output,safe_name(track['artist'],track['title'])+'.'+fmt)}
    if thumb:files['thumbnail']=thumb
    fields={'chat_id':owner,'title':track['title'],'performer':track['artist'],'duration':duration,'disable_notification':True}
    if prepare_only:return {'fields':fields,'files':files,'duration':duration,'_variant':{'title':track['title'],'artist':track['artist'],'artwork_key':artwork_key,'trimPercent':percent,'trimFacts':trim,'trackAudit':audit,'auditSourceDuration':track.get('duration',0)}}
    def finish_site():
        recording=prepare_recording()
        if not recording or not delivery_ready.wait(90) or not delivered:return
        result=delivered['result']
        try:publisher('recording_sent',{'documentId':document_id(result.get('audio',{}).get('file_unique_id')),'id':recording,'metadata':{'title':track['title'],'artist':track['artist'],'duration':duration}})
        except Exception:print('Site message mapping unavailable; desktop fallback retained.',flush=True)
        # The user may have sent another tag/format variant in the meantime.
        with cache_lock:
            try:cache=json.loads(cache_path.read_text(encoding='utf-8'))
            except (OSError,ValueError):return
            changed=False
            for saved,row in cache.items():
                if (saved==key or saved.startswith(key+':')) and row.get('owner')==owner and row.get('file_id')==result['audio']['file_id'] and row.get('title')==track['title'] and row.get('artist')==track['artist'] and row.get('artwork_key')==artwork_key:
                    row['recording_id']=recording;changed=True
            if changed:
                temp=cache_path.with_suffix('.pending.json');temp.write_text(json.dumps(cache),encoding='utf-8');temp.replace(cache_path)
    if _release_prepare:_release_prepare()
    with timing_wait(_timings) as ready,upload_slots:
        ready()
        # Report upload only when a network permit is actually available.
        if publisher and output.stat().st_size<=15*1024*1024:publish_later(finish_site)
        try:result=timed('upload',api.call,'sendAudio',fields,files)
        except BaseException:
            delivery_ready.set();raise
    after_send(record_sent,api,owner,track,fmt,result,{'fields':fields,'_variant':{'title':track['title'],'artist':track['artist'],'artwork_key':artwork_key,'trimPercent':percent,'trimFacts':trim,'trackAudit':audit,'auditSourceDuration':track.get('duration',0),'recording_id':recording}})
    delivered['result']=result;delivery_ready.set()
    return {'message_id':result['message_id'],'duration':duration,'has_thumbnail':bool(result.get('audio',{}).get('thumbnail')),'cached':False,'trimFacts':trim,'trackAudit':{'id':track['id'],**audit}}
