"""Match public catalogue artwork; never infer originality from image contents."""
import re,urllib.parse
from library import clean,clean_title,clean_artist,clean_track_tags,recording_key

def safe_cover(value):
    try:
        url=urllib.parse.urlsplit(value or '')
        return value if url.scheme=='https' and not url.username and not url.password and url.port in (None,443) and (url.hostname=='images.genius.com' or re.fullmatch(r'is\d+-ssl\.mzstatic\.com',url.hostname or '')) else ''
    except ValueError:return ''

def safe_reference(value,provider):
    try:
        url=urllib.parse.urlsplit(value or '')
        host='genius.com' if provider=='Genius' else 'music.apple.com'
        return value if url.scheme=='https' and url.hostname==host and not url.username and not url.password and url.port in (None,443) else ''
    except ValueError:return ''

def artwork(row,provider):
    cover=safe_cover(row.get('artworkUrl100',''))
    if not cover:return {}
    cover=re.sub(r'/\d+x\d+bb\.(jpg|png)$',r'/600x600bb.\1',cover)
    return {'catalogueCover':cover,'coverProvider':provider}

def untranslated(value):
    # Genius adds English translations in brackets to Cyrillic catalogue names.
    text=clean(value)
    if re.search('[а-яё]',text,re.I):
        text=re.sub(r'\s*\((?=[^)]*[a-z])(?![^)]*\b(?:slowed|slow|sped|speed|nightcore|remix|live|instrumental|feat|ft)\b)[^а-яё)]*\)\s*$', '',text,flags=re.I)
    return text.strip()

def genius_match(track,data,artwork_required=True):
    wanted=clean_track_tags(track);wanted_key=recording_key(wanted);artist_key=wanted_key.split(':',1)[0]
    matches=[]
    for hit in data.get('response',{}).get('hits',[]):
        if hit.get('type')!='song':continue
        song=hit.get('result',{});source=safe_reference(song.get('url'),'Genius');cover=safe_cover(song.get('song_art_image_url'))
        if not source or artwork_required and not cover:continue
        names=[song.get('primary_artist',{}).get('name',''),*[a.get('name','') for a in song.get('featured_artists',[])]]
        # Search results can omit featured_artists even for co-primary credits.
        # artist_names carries the complete public credit list. Require the
        # primary entity to belong to it, then retain the exact identity check.
        full=clean_artist(untranslated(song.get('artist_names','')))
        key=lambda name:set(recording_key({'artist':name,'title':'_'}).split(':',1)[0].split('+'))
        if full and names[0] and key(names[0])<=key(full):names=[full]
        candidate=clean_track_tags({'artist':', '.join(untranslated(a) for a in names),'title':untranslated(song.get('title','')),'metadataConfirmed':True,'featuredArtists':[untranslated(a.get('name','')) for a in song.get('featured_artists',[])]})
        if recording_key(candidate).split(':',1)[0]!=artist_key:continue
        exact=recording_key(candidate)==wanted_key
        # An unreleased upload may use only one part of a compound title.
        parts=[p.strip() for p in candidate['title'].split('/')]
        partial=len(clean_title(wanted['title']))>=6 and len(parts)==2 and any(recording_key({**candidate,'title':p})==wanted_key for p in parts)
        if not exact and not partial:continue
        matches.append((exact,candidate,source,cover))
    if not matches:return {}
    exact=[m for m in matches if m[0]];matches=exact or matches
    if len({recording_key(m[1]) for m in matches})!=1:return {}
    _,candidate,source,cover=matches[0]
    return {**{k:candidate[k] for k in ('mainArtist','featuredArtists') if k in candidate},'artist':clean_artist(candidate['artist']),'title':candidate['title'],'metadataConfirmed':True,'metadataVerified':True,'tagProvider':'Genius','metadataSourceUrl':source,'catalogueCover':cover,'coverProvider':'Genius'}

def genius_lookup(track,request):
    term=track['artist']+' '+clean_title(track['title'])
    data=request('https://genius.com/api/search?'+urllib.parse.urlencode({'q':term,'per_page':20}),'Genius')
    return genius_match(track,data)



def localized_catalogue_rows(track,rows,request):
    """Resolve a storefront's translated primary name through its artist ID.

    Never transliterate or guess aliases. All other credits and the exact title
    must already match; the ID's localized profile must close the full identity.
    Returned rows still undergo normal duration/version/ambiguity verification.
    """
    key=lambda name:recording_key({'artist':name,'title':'_'}).split(':',1)[0]
    wanted_track=clean_track_tags({**track,'metadataConfirmed':True})
    wanted=set(key(wanted_track.get('artist','')).split('+'))
    title=recording_key({'artist':'_','title':wanted_track.get('title','')})
    eligible=[]
    for index,row in enumerate(rows):
        row_tags=clean_track_tags({'artist':row.get('artistName',''),'title':row.get('trackName',''),'metadataConfirmed':True})
        if row.get('wrapperType')!='track' or recording_key({'artist':'_','title':row_tags['title']})!=title:continue
        credits=clean_artist(row_tags['artist']).split(', ')
        if not credits or set(key(row.get('artistName','')).split('+'))==wanted:continue
        rest={key(c) for c in credits[1:]}
        artist_id=row.get('artistId')
        if len(rest)!=len(credits)-1 or not rest<=wanted or len(wanted-rest)!=1:continue
        if isinstance(artist_id,bool) or not isinstance(artist_id,int) or artist_id<=0:continue
        eligible.append((index,row,credits,artist_id))
    ids={x[3] for x in eligible}
    if len(ids)>2:return rows
    profiles={}
    for artist_id in sorted(ids):
        try:
            data=request('https://itunes.apple.com/lookup?'+urllib.parse.urlencode({'id':artist_id,'country':'kz','lang':'ru_ru'}),'Apple Music')
            names={clean_artist(r.get('artistName','')) for r in data.get('results',[]) if r.get('wrapperType')=='artist' and r.get('artistId')==artist_id and not isinstance(r.get('artistId'),bool)}
            if len(names)==1:
                name=next(iter(names))
                if name and key(name) in wanted:profiles[artist_id]=name
        except Exception:pass
    out=list(rows)
    for index,row,credits,artist_id in eligible:
        name=profiles.get(artist_id)
        if not name:continue
        canonical=', '.join([name,*credits[1:]])
        if key(canonical)==key(track['artist']):out[index]={**row,'artistName':canonical}
    return localized_guest_rows(wanted_track,out,request)

def localized_guest_rows(track,rows,request):
    """A translated guest needs an exact recording on their official catalogue.

    Artist-name similarity alone is not evidence. Keep all matching credits,
    require one differing guest, and bind to the same positive Apple track ID.
    """
    key=lambda name:recording_key({'artist':name,'title':'_'}).split(':',1)[0]
    wanted_names={key(n):n for n in clean_artist(track['artist']).split(', ') if n}
    if not 2<=len(wanted_names)<=8:return rows
    title=recording_key({'artist':'_','title':track['title']});out=list(rows);proofs={}
    for index,row in enumerate(rows):
        tags=clean_track_tags({'artist':row.get('artistName',''),'title':row.get('trackName',''),'metadataConfirmed':True})
        if row.get('wrapperType')!='track' or recording_key({'artist':'_','title':tags['title']})!=title:continue
        names=clean_artist(tags['artist']).split(', ');found={key(n) for n in names}
        missing=set(wanted_names)-found;extra=found-set(wanted_names);track_id=row.get('trackId')
        if len(missing)!=1 or len(extra)!=1 or len(found)!=len(wanted_names) or not found&set(wanted_names):continue
        if isinstance(track_id,bool) or not isinstance(track_id,int) or track_id<=0:continue
        wanted=next(iter(missing));other=next(iter(extra));cache_key=(wanted,track_id)
        if cache_key not in proofs:
            if len(proofs)>=2:continue
            proofs[cache_key]=False
            try:
                query={'term':wanted_names[wanted],'entity':'musicArtist','limit':25,'country':'kz','lang':'ru_ru'}
                entities=request('https://itunes.apple.com/search?'+urllib.parse.urlencode(query),'Apple Music').get('results',[])
                ids={e.get('artistId') for e in entities if e.get('wrapperType')=='artist' and key(e.get('artistName',''))==wanted and isinstance(e.get('artistId'),int) and not isinstance(e.get('artistId'),bool) and e['artistId']>0}
                if not 1<=len(ids)<=3:continue
                proven=[]
                for artist_id in sorted(ids):
                    query={'id':artist_id,'entity':'song','limit':200,'country':'kz'}
                    songs=request('https://itunes.apple.com/lookup?'+urllib.parse.urlencode(query),'Apple Music').get('results',[])
                    if any(s.get('wrapperType')=='track' and s.get('trackId')==track_id and not isinstance(s.get('trackId'),bool) and recording_key({'artist':'_','title':clean_track_tags({'artist':s.get('artistName',''),'title':s.get('trackName',''),'metadataConfirmed':True})['title']})==title for s in songs):proven.append(artist_id)
                proofs[cache_key]=len(proven)==1
            except Exception:pass
        if proofs[cache_key]:out[index]={**row,'artistName':', '.join(wanted_names[wanted] if key(n)==other else n for n in names)}
    return out

def artist_profile_entities(track,rows,request):
    key=lambda name:recording_key({'artist':name,'title':'_'}).split(':',1)[0]
    wanted=key(track['artist']);members=set(wanted.split('+'))
    # ID evidence comes from the complete credited artist set. A solo row
    # cannot establish the identity of a similarly named collaborator.
    ids={r['artistId'] for r in rows if isinstance(r.get('artistId'),int) and not isinstance(r.get('artistId'),bool) and r['artistId']>0 and key(r.get('artistName',''))==wanted}
    if not ids or len(ids)>2:return {}
    resolved={};conflicts=set()
    for artist_id in ids:
        data=request('https://itunes.apple.com/lookup?'+urllib.parse.urlencode({'id':artist_id,'country':'kz'}),'Apple Music')
        for row in data.get('results',[]):
            name=clean_artist(row.get('artistName',''));identity=key(name)
            if row.get('wrapperType')!='artist' or row.get('artistId')!=artist_id or identity not in members or not name:continue
            if identity in resolved and resolved[identity]['id']!=artist_id:conflicts.add(identity)
            resolved[identity]={'name':name,'id':artist_id}
    return {k:v for k,v in resolved.items() if k not in conflicts}

def preferred_artist_spelling(track,rows,request):
    wanted=clean_track_tags(track);key=lambda name:recording_key({'artist':name,'title':'_'}).split(':',1)[0]
    credits=clean_artist(wanted['artist']).split(', ')
    if wanted.get('artistProvider')=='Apple Music':
        return {**{k:wanted[k] for k in ['artist','mainArtist','featuredArtists'] if k in wanted},'artistProvider':'Apple Music','artistSpellingVersion':1,'artistSpellingState':'verified'}
    try:official=artist_profile_entities(wanted,rows,request)
    except Exception:official={}
    from_genius={}
    if not all(key(c) in official for c in credits):
        try:from_genius=genius_artist_spelling(wanted,request)
        except Exception:pass
    base=clean_artist(from_genius.get('artist') or wanted['artist']).split(', ')
    canonical=', '.join(official.get(key(c),{}).get('name') or c for c in base)
    if not official and not from_genius:return {}
    if key(canonical)!=key(wanted['artist']):return {}
    roles=clean_track_tags({**wanted,'artist':canonical})
    return {**{k:roles[k] for k in ['artist','mainArtist','featuredArtists'] if k in roles},'artistProvider':'Apple Music' if official else 'Genius','artistSpellingVersion':1,'artistSpellingState':'verified' if from_genius or len(official)==len(credits) else 'partial'}

def genius_artist_spelling(track,request):
    """Use artist entities on an exact recording; do not infer letter case."""
    wanted=clean_track_tags(track)
    data=request('https://genius.com/api/search?'+urllib.parse.urlencode({'q':wanted['artist']+' '+wanted['title'],'per_page':20}),'Genius')
    matched=genius_match(wanted,data,artwork_required=False)
    if not matched or recording_key(matched)!=recording_key(wanted):return {}
    credits=clean_artist(wanted['artist']).split(', ');key=lambda name:recording_key({'artist':name,'title':'_'}).split(':',1)[0]
    entities={}
    for hit in data.get('response',{}).get('hits',[]):
        song=hit.get('result',{})
        if hit.get('type')!='song':continue
        evidence=genius_match(wanted,{'response':{'hits':[hit]}},artwork_required=False)
        if not evidence or recording_key(evidence)!=recording_key(wanted):continue
        for artist in [song.get('primary_artist',{}),*song.get('primary_artists',[]),*song.get('featured_artists',[])]:
            if not isinstance(artist,dict):continue
            name=clean_artist(untranslated(artist.get('name','')));identity=key(name)
            if not name or identity not in {key(c) for c in credits}:continue
            artist_id=artist.get('id');url=artist.get('url','')
            try:u=urllib.parse.urlsplit(url);safe=u.scheme=='https' and u.hostname=='genius.com' and not u.username and not u.password and u.port in (None,443) and bool(re.fullmatch(r'/artists/[A-Za-z0-9-]+',u.path))
            except ValueError:continue
            if isinstance(artist_id,bool) or not isinstance(artist_id,int) or artist_id<=0 or not safe:continue
            if identity in entities and entities[identity]['id']!=artist_id:return {}
            entities[identity]={'id':artist_id,'name':name,'url':url}
    if len(entities)>8:return {}
    resolved={}
    for index,(identity,entity) in enumerate(entities.items()):
        name=entity['name']
        try:
            # Limit cold profile requests. Remaining credits already carry
            # matched Genius artist entities; shared request cache is reused.
            profile=request('https://genius.com/api/artists/'+str(entity['id']),'Genius').get('response',{}).get('artist',{}) if index<2 else {}
            detailed=clean_artist(untranslated(profile.get('name','')))
            if profile.get('id')==entity['id'] and key(detailed)==identity:name=detailed
        except Exception:pass # The matched song already supplied this exact artist entity.
        resolved[identity]=name
    if not resolved:return {}
    canonical=', '.join(resolved.get(key(c),c) for c in credits)
    if key(canonical)!=key(wanted['artist']):return {}
    roles=clean_track_tags({**wanted,'artist':canonical})
    return {**{k:roles[k] for k in ['artist','mainArtist','featuredArtists'] if k in roles},'artistProvider':'Genius','artistSpellingVersion':1,'artistSpellingState':'verified'}

def artist_profile(track,rows,request):
    """Canonical spelling comes from a matched artist entity, not a name table."""
    key=lambda name:recording_key({'artist':name,'title':'_'}).split(':',1)[0]
    wanted=key(track['artist'])
    ids={r['artistId'] for r in rows if isinstance(r.get('artistId'),int) and r['artistId']>0 and key(r.get('artistName',''))==wanted}
    if len(ids)!=1:return ''
    data=request('https://itunes.apple.com/lookup?'+urllib.parse.urlencode({'id':next(iter(ids)),'country':'kz'}),'Apple Music')
    names={clean_artist(r.get('artistName','')) for r in data.get('results',[]) if r.get('wrapperType')=='artist' and r.get('artistId') in ids and key(r.get('artistName',''))==wanted}
    return next(iter(names)) if len(names)==1 else ''


def source_artist(track):
    """Restore equivalent source credits while keeping upload accounts separate."""
    key=lambda name:recording_key({'artist':name,'title':'_'}).split(':',1)[0]
    wanted=key(track['artist'])
    parts=re.split(r'\s*[—–]\s*|\s+-\s+',clean(track.get('original','')),maxsplit=1)
    choices=([parts[0]] if len(parts)==2 else [])+[track.get('originalArtist','')]
    return next((clean_artist(a) for a in choices if a and key(a)==wanted),track['artist'])
