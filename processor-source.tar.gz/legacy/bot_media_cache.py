"""Private content-verified audio copies survive a change of Telegram bot."""
import hashlib,re
from media import ROOT

def same_bot(row,api):
    stored=row.get('botId',row.get('fileBotId'))
    return stored is None or str(stored)==str(getattr(api,'bot_id',None))

def archive_file(row):
    name=row.get('localAudio')
    if not isinstance(name,str) or not re.fullmatch(r'[a-f0-9]{64}\.audio',name):return None
    folder=ROOT/'work/migration-audio'
    path=folder/name
    if folder.is_symlink() or path.is_symlink() or not path.is_file():return None
    if path.resolve().parent!=folder.resolve():return None
    if hashlib.sha256(path.read_bytes()).hexdigest()!=name[:-6]:return None
    return path
