import json,re,sys,threading,http.client,urllib.parse
from pathlib import Path
from media import ROOT,ffmpeg_path
sys.path.insert(0,str(Path(__file__).resolve().parent/'vendor'))
import yt_dlp
class Quiet:
    def debug(self,*a):pass
    def warning(self,*a):pass
    def error(self,*a):pass

_search_context=None
_search_lock=threading.Lock()
_search_connection=None
_independent=threading.local()

def options():
    return {'quiet':True,'logger':Quiet(),'socket_timeout':15,'retries':1,'fragment_retries':1,'cachedir':str(ROOT/'work'/'sc-cache'),'noplaylist':True,'hls_prefer_native':True,'external_downloader':{'default':'native'}}

def warm_search():
    global _search_context
    from yt_dlp.extractor.soundcloud import SoundcloudSearchIE
    with _search_lock:
        if _search_context is None:
            y=yt_dlp.YoutubeDL({**options(),'extract_flat':True,'skip_download':True})
            extractor=SoundcloudSearchIE(y);extractor.initialize()
            _search_context=(y,extractor)

def request_page(extractor,query,offset,session=None):
    global _search_connection
    params={'q':query,'limit':10,'offset':offset,'linked_partitioning':1,'client_id':extractor._CLIENT_ID}
    try:
        connection=session.get('connection') if session is not None else _search_connection
        if connection is None:
            connection=http.client.HTTPSConnection('api-v2.soundcloud.com',timeout=4 if session is not None else 8)
            if session is not None:session['connection']=connection
            else:_search_connection=connection
        connection.request('GET','/search/tracks?'+urllib.parse.urlencode(params),headers={'User-Agent':extractor._USER_AGENT,'Accept':'application/json'})
        response=connection.getresponse();blob=response.read(2*1024*1024+1)
        if response.status!=200 or len(blob)>2*1024*1024:raise ValueError('Unavailable page')
        data=json.loads(blob)
        if not isinstance(data.get('collection'),list):raise ValueError('Invalid page')
        return data
    except Exception:
        connection=session.get('connection') if session is not None else _search_connection
        if connection is not None:connection.close()
        if session is not None:session['connection']=None
        else:_search_connection=None
        # Extractor refreshes an expired public client ID and handles provider errors.
        return extractor._call_api(extractor._API_V2_BASE+'search/tracks',query,headers=extractor._HEADERS,query=params)

def independent_session():
    """A persistent extractor per bounded request thread."""
    session=getattr(_independent,'session',None)
    if session is None:
        from yt_dlp.extractor.soundcloud import SoundcloudSearchIE
        y=yt_dlp.YoutubeDL({**options(),'socket_timeout':4,'retries':0,'extract_flat':True,'skip_download':True},auto_init=False)
        extractor=SoundcloudSearchIE(y);extractor.initialize()
        session={'extractor':extractor,'connection':None};_independent.session=session
    return session

def search_independent(query,offset=0):
    # Import only: the first selected track can reuse an isolated ready child.
    # Failure to prewarm never changes search results or starts an audio fetch.
    try:
        from download_process import warm
        warm()
    except Exception:pass
    session=independent_session()
    data=request_page(session['extractor'],query,offset,session)
    return {'entries':[flat_track(t) for t in data.get('collection',[]) if t.get('policy') not in {'BLOCK','SNIP'}],
            'nextOffset':offset+10 if data.get('next_href') else None}

def search(payload,options):
    warm_search()
    with _search_lock:
        _,extractor=_search_context
        query=payload['query'];offset=max(0,min(10000,int(payload.get('offset',0))))
        data=request_page(extractor,query,offset)
        entries=[]
        for raw in data.get('collection',[]):
            if raw.get('policy') in {'BLOCK','SNIP'}:continue
            entries.append(flat_track(raw))
        return {'entries':entries,'nextOffset':offset+10 if data.get('next_href') else None}

def flat_track(raw):
    # Metadata is already in the page. The generic extractor HEAD-checks artwork
    # for EVERY result; search only needs a predictable 500px artwork variant.
    user=raw.get('user') or {};publisher=raw.get('publisher_metadata') or {}
    artwork=raw.get('artwork_url') or user.get('avatar_url') or ''
    artwork=re.sub(r'-[0-9a-z]+\.(?:jpg|png)$','-t500x500.jpg',artwork)
    artist=publisher.get('artist')
    from search_ranking import provider_counts
    return {**provider_counts(raw),'id':str(raw['id']),'title':raw.get('title') or '',
        'artist':artist if isinstance(artist,str) else None,'uploader':user.get('username') or '',
        'duration':(raw.get('duration') or 0)/1000,'thumbnail':artwork,'webpage_url':raw.get('permalink_url') or ''}

def main(payload=None):
    payload=payload if payload is not None else json.loads(sys.stdin.read());action=payload['action']
    settings=options()
    if action=='search':
        return search(payload,settings)
    if action=='download':
        from source import valid_url
        if not valid_url(payload['url']) or not re.fullmatch(r'\d{1,20}',payload['id']):raise ValueError('Invalid track')
        target=ROOT/'work'/('sc-'+payload['id'])
        # Completed originals remain reusable across formats and metadata edits.
        # Never treat fragments, partial files or empty downloads as complete.
        for extension in ['m4a','mp3','opus','ogg','webm']:
            cached=target.with_suffix('.'+extension)
            if cached.is_file() and not cached.is_symlink() and 0<cached.stat().st_size<=49*1024*1024:return str(cached)
        from native_audio import ready_audio_selector
        settings.update(format=ready_audio_selector,outtmpl=str(target)+'.%(ext)s',max_filesize=45*1024*1024,ffmpeg_location=ffmpeg_path(),overwrites=False,concurrent_fragment_downloads=1,skip_unavailable_fragments=False,
            match_filter=lambda info,**kwargs:'Слишком длинный трек' if (info.get('duration') or 0)>1080 else None)
        if payload.get('progressPath'):
            from download_progress import progress_hook
            settings['progress_hooks']=[progress_hook(payload['progressPath'])]
        with yt_dlp.YoutubeDL(settings,auto_init=False) as y:
            from yt_dlp.extractor.soundcloud import SoundcloudIE as BaseSoundcloudIE
            class SoundcloudIE(BaseSoundcloudIE):
                def _extract_thumbnails(self,info):return []
            # Delivery already downloads the selected search artwork separately.
            # Keep audio extraction intact and skip redundant artwork HEAD calls.
            y.add_info_extractor(SoundcloudIE(y))
            # Search already supplies a trusted public numeric ID. Resolve that ID
            # directly and retain extractor quality selection and the identity check.
            info=y.extract_info('https://api.soundcloud.com/tracks/'+payload['id'],download=True)
            if str(info.get('id'))!=payload['id']:raise ValueError('Track identity changed')
            path=Path(y.prepare_filename(info))
            if path.is_symlink() or not path.is_file() or path.stat().st_size>49*1024*1024:raise ValueError('Missing or large file')
            return str(path)
    raise ValueError('Unknown action')
if __name__=='__main__':
    try:print(json.dumps({'ok':True,'result':main()},ensure_ascii=False))
    except Exception:print(json.dumps({'ok':False,'error':'SoundCloud не отдал этот трек. Возможно, он недоступен в регионе или требует подписку. Попробуй другой результат.'},ensure_ascii=False))
