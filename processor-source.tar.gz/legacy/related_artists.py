"""Bounded public artist similarity metadata; never account history or audio."""
import hashlib,json,re,threading,time,urllib.parse,urllib.request
from concurrent.futures import ThreadPoolExecutor
from media import ROOT
from work_cache import keyed_lock,atomic_json
from library import clean_artist
from taste import identity

_pool=ThreadPoolExecutor(max_workers=1,thread_name_prefix='similarity-metadata')
_pending=set();_lock=threading.RLock();_mb_lock=threading.Lock();_mb_next=0
UA='PMXP-MusicBot/1.0 (https://pmxp.fun)'

def cache_path(name):return ROOT/'work/related-artists'/(hashlib.sha256(identity(name).encode()).hexdigest()+'.json')

def read(name):
    try:
        saved=json.loads(cache_path(name).read_text(encoding='utf-8'))
        if saved.get('version')==1 and time.time()-saved['time']<(7*86400 if saved['links'] else 600):return saved['links']
    except (OSError,ValueError,KeyError,TypeError):pass
    return None

def get(name,schedule=True):
    name=clean_artist(name)[:100];saved=read(name)
    if saved is not None:return saved,False
    key=identity(name)
    if not key:return [],False
    if schedule:
        with _lock:
            if key not in _pending and len(_pending)<4:
                _pending.add(key)
                def run():
                    try:refresh(name)
                    finally:
                        with _lock:_pending.discard(key)
                _pool.submit(run)
            pending=key in _pending
        return [],pending
    return [],False

def parse_youtube(data,seed):
    from music_catalogue import nodes
    rows=[];seen={identity(seed)}
    for shelf in nodes(data,{'musicCarouselShelfRenderer'}):
        titles=list(nodes(shelf.get('header',{}),{'title'}))
        label=identity(' '.join(''.join(r.get('text','') for r in t.get('runs',[])) for t in titles if isinstance(t,dict)))
        if not any(x in label for x in ('fansmightalsolike','similarartists','relatedartists','похожиеисполнители','вамтакжеможетпонравиться')):continue
        for renderer in nodes(shelf.get('contents',[]),{'musicTwoRowItemRenderer','musicResponsiveListItemRenderer'}):
            ident=renderer.get('navigationEndpoint',{}).get('browseEndpoint',{}).get('browseId','')
            if not re.fullmatch(r'UC[\w-]{22}',ident):continue
            value=renderer.get('title',{})
            if not value and renderer.get('flexColumns'):value=renderer['flexColumns'][0].get('musicResponsiveListItemFlexColumnRenderer',{}).get('text',{})
            name=clean_artist(''.join(r.get('text','') for r in value.get('runs',[])))[:100];key=identity(name)
            if not key or key in seen:continue
            seen.add(key);rows.append({'name':name,'key':key,'source':'YouTube Music','sourceArtistId':ident,'score':max(.35,1-len(rows)*.045)})
    return rows[:16]

def youtube(name):
    from music_albums import context
    from music_catalogue import nodes
    from query_normalizer import artist_matches
    ie=context();data=ie._extract_response(item_id=name,ep='search',query={'query':name,'params':ie._SECTIONS['artists']},default_client='web_music');found={}
    for renderer in nodes(data,{'musicResponsiveListItemRenderer','musicTwoRowItemRenderer'}):
        endpoint=renderer.get('navigationEndpoint',{}).get('browseEndpoint',{});ident=endpoint.get('browseId','');value=renderer.get('title',{})
        if not value and renderer.get('flexColumns'):value=renderer['flexColumns'][0].get('musicResponsiveListItemFlexColumnRenderer',{}).get('text',{})
        label=''.join(r.get('text','') for r in value.get('runs',[]))
        if re.fullmatch(r'UC[\w-]{22}',ident) and artist_matches(name,label):found[ident]=label
    if len(found)!=1:return []
    ident=next(iter(found));data=ie._extract_response(item_id=ident,ep='browse',query={'browseId':ident},default_client='web_music')
    return parse_youtube(data,name)

def request(url,as_json=True):
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':UA}),timeout=5) as response:
        raw=response.read(1024*1024+1)
        if len(raw)>1024*1024:raise ValueError('Similarity response too large')
    return json.loads(raw) if as_json else raw.decode('utf-8')

def listenbrainz(name):
    global _mb_next
    from query_normalizer import artist_matches
    # MusicBrainz asks for at most one request per second per client.
    with _mb_lock:
        time.sleep(max(0,_mb_next-time.monotonic()));_mb_next=time.monotonic()+1.05
        query='artist:"'+name.replace('"','')+'"';raw=request('https://musicbrainz.org/ws/2/artist/?'+urllib.parse.urlencode({'query':query,'fmt':'json','limit':5}))
    found=[a for a in raw.get('artists',[]) if int(a.get('score',0))>=95 and (artist_matches(name,a.get('name','')) or any(artist_matches(name,x.get('name','')) for x in a.get('aliases',[])))]
    ids={a.get('id') for a in found}
    if len(ids)!=1:return []
    mbid=next(iter(ids))
    if not re.fullmatch(r'[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}',mbid or ''):return []
    # Discover the currently supported dataset algorithm, rather than inventing
    # a provider recommendation or pinning an obsolete dataset identifier.
    html=request('https://labs.api.listenbrainz.org/similar-artists',False)
    options=re.findall(r'<option\b[^>]*\bid="([\w-]{1,200})"',html)
    if not options:return []
    raw=request('https://labs.api.listenbrainz.org/similar-artists/json?'+urllib.parse.urlencode({'artist_mbids':mbid,'algorithm':options[0]}))
    if not isinstance(raw,list):return []
    rows=[];seen={identity(name)};maximum=max([float(a.get('score') or 0) for a in raw if isinstance(a,dict)]+[1])
    for item in raw:
        if not isinstance(item,dict):continue
        artist=clean_artist(item.get('name',''))[:100];key=identity(artist);score=float(item.get('score') or 0)
        if not key or key in seen or score<=0:continue
        seen.add(key);rows.append({'name':artist,'key':key,'source':'ListenBrainz','sourceArtistId':item.get('artist_mbid'),'score':min(1,max(.2,score/maximum))})
    return rows[:16]

def refresh(name):
    with keyed_lock(('similarity',identity(name))):
        saved=read(name)
        if saved is not None:return saved
        links=[]
        for fetch in (youtube,listenbrainz):
            try:links=fetch(name)
            except Exception:links=[]
            if links:break
        atomic_json(cache_path(name),{'version':1,'time':time.time(),'artist':name,'links':links})
        try:
            files=sorted(cache_path(name).parent.glob('*.json'),key=lambda p:p.stat().st_mtime)
            for p in files[:-256]:p.unlink(missing_ok=True)
        except OSError:pass
        return links
