"""Single public-source download RPC; never accepts search or Telegram writes."""
import json,os,sys,threading,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent/'vendor'))
PROTOCOL=1
IDLE_SECONDS=60
MAX_REQUESTS=16
MAX_REQUEST_BYTES=65536
parent=os.getppid();state_lock=threading.Lock();last_active=time.monotonic();busy=False

def lifecycle():
    while True:
        time.sleep(.5)
        with state_lock:expired=not busy and time.monotonic()-last_active>=IDLE_SECONDS
        if os.getppid()!=parent or expired:os._exit(0)

threading.Thread(target=lifecycle,name='download-parent-and-idle',daemon=True).start()
# This is all prewarming does: public code import, without a provider request.
import yt_dlp
import source_cli,external_sources
with state_lock:last_active=time.monotonic()
print(json.dumps({'type':'ready','protocol':PROTOCOL}),flush=True)
requests=0
while requests<MAX_REQUESTS:
    line=sys.stdin.readline(MAX_REQUEST_BYTES+1)
    if not line:break
    if len(line.encode('utf-8'))>MAX_REQUEST_BYTES or not line.endswith('\n'):break
    ident=None
    with state_lock:busy=True
    try:
        request=json.loads(line);ident=request['id'];payload=request['payload']
        if not isinstance(ident,str) or len(ident)!=32 or any(c not in '0123456789abcdef' for c in ident):raise ValueError('Invalid download request')
        if not isinstance(payload,dict) or payload.get('action')!='download':raise ValueError('Download only')
        provider=payload.get('provider')
        if provider=='SoundCloud':result=source_cli.main(payload)
        elif provider in ('YouTube','Bandcamp'):
            if payload.get('track',{}).get('source')!=provider:raise ValueError('Provider mismatch')
            result=external_sources.main(payload)
        else:raise ValueError('Invalid source')
        reply={'id':ident,'ok':True,'result':result}
    except Exception as error:
        provider=payload.get('provider') if isinstance(locals().get('payload'),dict) else None
        message='SoundCloud не отдал этот трек. Попробуй другой результат.' if provider=='SoundCloud' else external_sources.user_error(error,provider)
        reply={'id':ident,'ok':False,'error':message[:300]}
    finally:
        with state_lock:busy=False;last_active=time.monotonic()
    print(json.dumps(reply,ensure_ascii=False),flush=True)
    requests+=1
    # Do not retain the previous request's track, progress path, or result.
    for name in ('request','payload','result','reply','ident','line','provider'):globals().pop(name,None)
