"""Confirmed receipts and conservative recording identities; no IO on import."""
import math,re,unicodedata
from functools import lru_cache
from urllib.parse import urlparse,parse_qs
from library import clean_artist,clean_title,FEATURE_RE,FEATURE_ARTIST_RE
from track_versions import version_labels

MAX_SAFE_INTEGER=9007199254740991
IDENTITY_FIELDS=('id','source','url','artist','title','original','originalTitle','featuredArtists','versionLabels','version','metadataConfirmed','duration','sourceDuration','auditSourceDuration','trimPercent')

def positive_message_id(value):
    return isinstance(value,int) and not isinstance(value,bool) and 0<value<=MAX_SAFE_INTEGER

def receipt_evidence(receipt):
    if not isinstance(receipt,dict):return None
    if any(receipt.get(k) for k in ('failed','uncertain','deliveryUncertain')):return None
    if receipt.get('ok') is False or receipt.get('deliveryConfirmed') is False:return None
    if str(receipt.get('state') or receipt.get('status') or '').lower() in ('failed','uncertain','cancelled','canceled'):return None
    result=receipt.get('result')
    if isinstance(result,dict):
        if any(result.get(k) for k in ('failed','uncertain','deliveryUncertain')) or result.get('ok') is False or result.get('deliveryConfirmed') is False:return None
        if str(result.get('state') or result.get('status') or '').lower() in ('failed','uncertain','cancelled','canceled'):return None
    message_id=receipt.get('message_id')
    if message_id is None and isinstance(result,dict):message_id=result.get('message_id')
    if positive_message_id(message_id):
        return {'receivedConfirmed':True,'receivedEvidence':'telegram-message','receivedMessageId':message_id}
    # Only internal migration callers supply this proven positive sent-cache field.
    legacy=receipt.get('legacyFileId')
    if isinstance(legacy,str) and legacy.strip():
        return {'receivedConfirmed':True,'receivedEvidence':'legacy-sent-cache','receivedLegacyFileId':True}
    return None

def is_received(row):
    if not isinstance(row,dict) or row.get('receivedConfirmed') is not True:return False
    if any(row.get(k) for k in ('failed','uncertain','deliveryUncertain')):return False
    if row.get('deliveryConfirmed') is False or str(row.get('state') or row.get('status') or '').lower() in ('failed','uncertain','cancelled','canceled'):return False
    kind=row.get('receivedEvidence')
    return (kind=='telegram-message' and positive_message_id(row.get('receivedMessageId'))) or (kind=='legacy-sent-cache' and row.get('receivedLegacyFileId') is True)

def compact_received(track,evidence):
    if not isinstance(track,dict) or not evidence:return None
    row={k:track[k] for k in IDENTITY_FIELDS if k in track}
    for k in ('id','source','url','artist','title','original','originalTitle','version'):
        if k in row:
            if isinstance(row[k],(str,int)) and not isinstance(row[k],bool):row[k]=str(row[k])[:2048 if k=='url' else 512]
            else:row.pop(k)
    for k in ('featuredArtists','versionLabels'):
        values=row.get(k);values=values if isinstance(values,list) else []
        row[k]=[v[:200] if isinstance(v,str) else str(v.get('name') or '')[:200] for v in values[:24] if isinstance(v,(str,dict))]
    row['metadataConfirmed']=track.get('metadataConfirmed') is True
    for k in ('duration','sourceDuration','auditSourceDuration','trimPercent'):
        value=row.get(k)
        if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or value<0:row.pop(k,None)
    return {**row,**evidence}

def normalized(value):
    text=unicodedata.normalize('NFKC',str(value or '')).lower().replace('ё','е')
    return ''.join(c for c in text if unicodedata.category(c)[0] in ('L','N'))

def provider_key(track):
    source=normalized(track.get('source') or track.get('sourceLabel'))
    ident=track.get('id')
    ident=str(ident) if isinstance(ident,(str,int)) and not isinstance(ident,bool) else ''
    if source in ('youtube','youtubemusic','ytmusic') or ident.startswith('yt-'):provider='youtube';ident=ident.removeprefix('yt-')
    elif source=='soundcloud':provider='soundcloud'
    elif source=='bandcamp' or ident.startswith('bc-'):provider='bandcamp';ident=ident.removeprefix('bc-')
    elif source=='telegram' or ident.startswith('tg-'):provider='telegram';ident=ident.removeprefix('tg-')
    else:return None
    if not ident:
        url=track.get('url')
        if isinstance(url,str):
            parsed=urlparse(url);host=(parsed.hostname or '').lower()
            if provider=='youtube' and host in ('youtube.com','www.youtube.com','music.youtube.com','youtu.be'):
                ident=parsed.path.strip('/') if host=='youtu.be' else parse_qs(parsed.query).get('v',[''])[0]
            elif provider in ('soundcloud','bandcamp') and (host=='soundcloud.com' or host.endswith('.bandcamp.com')):ident=host+parsed.path.rstrip('/')
    return (provider,ident) if ident else None

_EDITION_PATTERNS=(
 ('nightcore',r'\bnight?core\b'),('spedup',r'\b(?:sped[\s_-]*up|speed[\s_-]*(?:up|songs?)|sped[\s_-]*songs?|ускор\w*)\b'),
 ('slowed',r'\b(?:slowed|замедл\w*)\b'),('reverb',r'\breverb\b'),('remix',r'\b(?:remix|ремикс\w*)\b'),
 ('bassboosted',r'\bbass[\s_-]*boost(?:ed)?\b'),('pitch',r'\bpitch(?:ed)?\b'),('8d',r'\b8d\b'),
 ('acoustic',r'\bacoustic\b'),('live',r'\blive(?:[\s_-]+(?:session|version|ver\.?))?\b'),('snippet',r'\bsnippet\b'),
 ('demo',r'\bdemo\b'),('radioedit',r'\bradio[\s_-]+edit\b'),('instrumental',r'\binstrumental\b'),
 ('uncensored',r'без\s+цензуры|\buncensored\b|\bexplicit\b'),('clean',r'\bclean[\s_-]+(?:version|edit)\b|\bcensored\b'))

def _editions(text,labels):
    found=set()
    for value in labels:
        if not normalized(value) or normalized(value)=='площадки':continue
        recognized={label for label,pattern in _EDITION_PATTERNS if re.search(pattern,str(value),re.I)}
        found.update(recognized or {normalized(value)})
    for label,pattern in _EDITION_PATTERNS:
        if re.search(pattern,text,re.I):found.add(label)
    for bracket in re.findall(r'[\[(]([^\])]+)[\])]',text):
        if not re.search(r'\b(?:remix|live|acoustic|demo|radio[\s_-]+edit)\b',bracket,re.I):continue
        rest=bracket
        for _,pattern in _EDITION_PATTERNS:rest=re.sub(pattern,'',rest,flags=re.I)
        rest=re.sub(r'\b(?:version|ver|session|edit)\b','',rest,flags=re.I)
        if normalized(rest):found.add('detail:'+normalized(bracket))
    return tuple(sorted(found))

def _credit_names(track,texts):
    if track.get('metadataConfirmed') is not True:return frozenset()
    guests=track.get('featuredArtists');guests=guests if isinstance(guests,list) else []
    names=[track.get('artist') or '']
    names.extend(g if isinstance(g,str) else str(g.get('name') or '') for g in guests if isinstance(g,(str,dict)))
    for text in texts:
        names.extend(FEATURE_RE.findall(text))
        inline=FEATURE_ARTIST_RE.search(text)
        if inline:names.append(inline[1].strip(' )]'))
    names=[n for raw in names if isinstance(raw,str) for n in clean_artist(raw).split(', ') if n]
    keys={normalized(name) for name in names if not re.search(r'неизвест|не\s*подтверж|unknown\s*artist',name,re.I)}
    return frozenset(keys-{''})

def recording_facts(track):
    if not isinstance(track,dict):return ()
    # Cache only pure immutable metadata, never owner profiles or receipt state.
    texts=tuple(v[:2048] for k in ('title','originalTitle','original') if isinstance(v:=track.get(k),str) and v.strip())
    guests=track.get('featuredArtists');guests=guests if isinstance(guests,list) else []
    guests=tuple(g if isinstance(g,str) else str(g.get('name') or '') for g in guests[:24] if isinstance(g,(str,dict)))
    labels=track.get('versionLabels');labels=tuple(v for v in labels[:24] if isinstance(v,str)) if isinstance(labels,list) else ()
    version=track.get('version');labels=(*labels,version) if isinstance(version,str) and version.strip() else labels
    artist=str(track.get('artist') or '')[:2048]
    return _cached_recording_facts(artist,texts,guests,labels,track.get('metadataConfirmed') is True)

@lru_cache(maxsize=4096)
def _cached_recording_facts(artist,texts,guests,labels,confirmed):
    track={'artist':artist,'featuredArtists':list(guests),'metadataConfirmed':confirmed}
    return _recording_facts(track,list(dict.fromkeys(texts)),list(labels))

def _recording_facts(track,texts,labels):
    """Original titles use confirmed current credits; uploader names never do."""
    credits=_credit_names(track,texts)
    if not credits:return ()
    # A corrected title cannot turn a received sped/remix/live source into normal.
    source_labels=list(dict.fromkeys([*labels,*(v for text in texts for v in version_labels(text))]))
    editions=_editions(' '.join(texts),source_labels)
    result=[]
    for text in texts:
        title=clean_title(text)
        # Only a matching canonical artist prefix is presentation, never uploader.
        prefix=clean_artist(track.get('artist') or '')
        for delimiter in re.finditer(r'\s+[—–-]\s+',title):
            if normalized(title[:delimiter.start()])==normalized(prefix):title=title[delimiter.end():];break
        title=FEATURE_RE.sub('',title)
        inline=FEATURE_ARTIST_RE.search(title)
        if inline:title=title[:inline.start()]
        # Remove standardized edition presentation, retaining named remix/version qualifiers.
        title=re.sub(r'[\[(]\s*(?:live(?:[\s_-]+(?:session|version|ver\.?))?|acoustic(?:\s+(?:version|ver\.?))?|night?core|sped[\s_-]*up|speed[\s_-]*songs?|slowed|reverb|remix|snippet|demo|radio[\s_-]+edit|instrumental|clean[\s_-]+(?:version|edit))\s*[\])]', '',title,flags=re.I)
        title=re.sub(r'\s+(?:[-—–]\s*)?(?:live(?:[\s_-]+session)?|sped[\s_-]*up|slowed)\s*$', '',title,flags=re.I)
        name=normalized(title)
        if name:result.append((name,editions,credits))
    return tuple(dict.fromkeys(result))

def recording_duration(track):
    for key in ('sourceDuration','auditSourceDuration','duration'):
        value=track.get(key)
        if key=='duration' and track.get('trimPercent',0):continue
        if not isinstance(value,bool) and isinstance(value,(int,float)) and math.isfinite(value) and value>0:return float(value)
    return None

def _build_identity_index(rows):
    exact={};songs={}
    for row in rows:
        provider=provider_key(row)
        if provider:exact[provider]=True
        aliases=[row]
        if isinstance(row.get('receivedIdentity'),dict):aliases.append(row['receivedIdentity'])
        for alias in aliases:
            duration=recording_duration(alias)
            for title,edition,credits in recording_facts(alias):songs.setdefault((title,edition),[]).append((credits,duration))
    return {'exact':exact,'songs':songs}

def build_received_index(profile):
    rows=profile.get('receivedTracks',[]) if isinstance(profile,dict) else []
    rows=list(rows.values()) if isinstance(rows,dict) else rows
    rows=rows if isinstance(rows,list) else []
    return _build_identity_index(row for row in rows if is_received(row))

def build_owned_index(profile):
    """A confirmed incoming Telegram collection is owned, not bot receipt proof."""
    rows=profile.get('tracks',[]) if isinstance(profile,dict) else []
    rows=rows if isinstance(rows,list) else []
    return _build_identity_index(row for row in rows if isinstance(row,dict) and row.get('source')=='Telegram' and row.get('metadataConfirmed') is True)

def has_owned(track,index):return has_received(track,index)

def has_received(track,index):
    if not isinstance(track,dict) or not isinstance(index,dict):return False
    facts=recording_facts(track);provider=provider_key(track)
    # A provider ID denotes the same source audio despite edited display metadata.
    if provider and index.get('exact',{}).get(provider):return True
    duration=recording_duration(track)
    for title,edition,credits in facts:
        for heard_credits,heard_duration in index.get('songs',{}).get((title,edition),()):
            if not (credits<=heard_credits or heard_credits<=credits):continue
            if duration and heard_duration and abs(duration-heard_duration)>max(5,.05*max(duration,heard_duration)):continue
            return True
    return False
