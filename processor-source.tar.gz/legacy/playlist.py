"""Extracted explicit playlist job only; no polling/monitor/bootstrap."""
import json,os,threading,time,uuid,hashlib,secrets

from concurrent.futures import ThreadPoolExecutor

from pathlib import Path

from media import ROOT

from delivery import send_track,record_sent,after_send

from taste import remember_received

def keyboard(session,token):
    stem='pl:'+session+':'+token+':'
    return {'inline_keyboard':[[{'text':'Нравится','style':'success','callback_data':stem+'l'},{'text':'Не нравится','style':'danger','callback_data':stem+'d'}],[{'text':'Ещё 3','callback_data':stem+'n'},{'text':'Стоп','callback_data':stem+'s'}]]}

def track_key(track,fmt,bot_id=None,owner=None):
    from prepared_cache import identity
    return identity(track,fmt,owner,bot_id)

class Playlist:
    def __init__(self,api,owner,call,path=None,prepare=None):
            self.api=api;self.owner=owner;self.call=call;self.path=Path(path or __import__('taste').user_work(owner)/'playlist-state.json');self.prepare=prepare or (lambda track,fmt:send_track(api,owner,track,fmt,prepare_only=True));self.lock=threading.RLock();self.callbacks=threading.BoundedSemaphore(2);self.wake=threading.Event();self.next_send=0
            try:self.saved=json.loads(self.path.read_text(encoding='utf-8'))
            except (OSError,ValueError):self.saved={'sessions':{},'cleanup':[]}
            self.saved.setdefault('cleanup',[])
            self.saved.setdefault('cleared',[])
    def save(self):
            self.path.parent.mkdir(parents=True,exist_ok=True)
            temporary=self.path.with_suffix('.pending.json');temporary.write_text(json.dumps(self.saved,ensure_ascii=False),encoding='utf-8');os.chmod(temporary,0o600);temporary.replace(self.path)
    def session(self,session):
            with self.lock:
                data=self.saved['sessions'].setdefault(session,{'deliveries':{},'attempts':{},'prepared':{},'updated':time.time()});data['updated']=time.time()
                # Keep durable receipts long enough for a lost complete acknowledgment.
                self.saved['sessions']={k:v for k,v in self.saved['sessions'].items() if k==session or time.time()-v['updated']<86400}
                return data
    def clear(self,message_id):
            if not message_id:return
            with self.lock:
                if message_id in self.saved['cleared']:return
            try:
                self.api.call('editMessageReplyMarkup',{'chat_id':self.owner,'message_id':message_id,'reply_markup':{'inline_keyboard':[]}})
                with self.lock:self.saved['cleared']=(self.saved['cleared']+[message_id])[-128:];self.save()
            except Exception as error:
                if getattr(error,'message_missing',False) or getattr(error,'not_modified',False):
                    with self.lock:self.saved['cleared']=(self.saved['cleared']+[message_id])[-128:];self.save()
                if not getattr(error,'message_missing',False) and not getattr(error,'not_modified',False):
                    with self.lock:
                        if message_id not in self.saved['cleanup']:self.saved['cleanup'].append(message_id)
                        self.saved['cleanup']=self.saved['cleanup'][-32:];self.save()
    def encode_prepared(self,row):
            return {**row,'files':{k:[str(v[0]),v[1]] if isinstance(v,tuple) else str(v) for k,v in row.get('files',{}).items()}}
    def decode_prepared(self,row):
            files={}
            for key,value in row.get('files',{}).items():
                raw=value[0] if isinstance(value,list) else value;path=Path(raw).resolve()
                if path.parent!=(ROOT/'work').resolve() or not path.name.startswith('sc-') or not path.is_file():return None
                files[key]=(path,value[1]) if isinstance(value,list) else path
            return {**row,'files':files}
    def prepared(self,session,track,fmt):
            data=self.session(session);key=track_key(track,fmt,getattr(self.api,'bot_id',None),self.owner)
            with self.lock:row=data['prepared'].get(key)
            row=self.decode_prepared(row) if row else None
            if row:return row
            row=self.prepare(track,fmt)
            with self.lock:
                data['prepared'][key]=self.encode_prepared(row);data['prepared']=dict(list(data['prepared'].items())[-3:]);self.save()
            return row
    def process(self,job):
            self.wake.set()
            with ThreadPoolExecutor(max_workers=1,thread_name_prefix='playlist-ahead') as pool:return self._process(job,pool)
    def telegram_write(self,method,fields,files):
            for attempt in range(3):
                try:return self.api.call(method,fields,files)
                except Exception as error:
                    retry=float(getattr(error,'retry_after',0) or 0)
                    # An explicit 429 confirms rejection. A lost wire response never
                    # enters this branch and must never replay an audio upload.
                    if not retry or attempt==2:raise
                    # Telegram.call already waits for up to sixty seconds.
                    if retry>60:time.sleep(min(300,retry-60))
    def _process(self,job,pool):
            lease={'id':job['id'],'claim':job['claim']};reply=self.call('playlist',{'action':'plan',**lease})
            if reply.get('stopped'):return {'stopped':True}
            plan=reply['plan'];session=reply['playlistId'];fmt=reply['format'];data=self.session(session)
            if not plan['tracks']:raise RuntimeError('Подходящие треки закончились. Открой рекомендации и попробуй продолжить.')
            indexes=list(range(len(plan['tracks'])))
            if plan['order']=='reverse':indexes.reverse()
            delivered=[];ahead=None
            for position,index in enumerate(indexes):
                if self.call('playlist',{'action':'check',**lease}).get('stopped'):break
                track=plan['tracks'][index];stamp=job['id']+':'+str(index)
                with self.lock:receipt=data['deliveries'].get(stamp);attempt=data['attempts'].get(stamp)
                if not receipt:
                    if attempt:raise RuntimeError('Telegram мог принять файл до потери связи. Повторная отправка остановлена; проверь чат и запусти новую порцию.')
                    row=ahead.result() if ahead else self.prepared(session,track,fmt);ahead=None
                    if position+1<len(indexes):ahead=pool.submit(self.prepared,session,plan['tracks'][indexes[position+1]],fmt)
                    if self.call('playlist',{'action':'check',**lease}).get('stopped'):break
                    if reply['operation']!='replace':
                        time.sleep(max(0,self.next_send-time.monotonic()));self.next_send=time.monotonic()+1.05
                        if self.call('playlist',{'action':'check',**lease}).get('stopped'):break
                    token=secrets.token_hex(8);fields={**row['fields'],'reply_markup':keyboard(session,token)};files=row.get('files') or None
                    # Fence a non-idempotent Telegram send before it reaches the wire.
                    with self.lock:data['attempts'][stamp]={'token':token,'at':time.time()};self.save()
                    if reply['operation']=='replace':
                        media={k:v for k,v in fields.items() if k in ('title','performer','duration')};media.update({'type':'audio','media':fields.get('audio','attach://audio'),'caption':''})
                        if files and 'thumbnail' in files:media['thumbnail']='attach://thumbnail'
                        result=self.telegram_write('editMessageMedia',{'chat_id':self.owner,'message_id':reply['messageId'],'media':media,'reply_markup':fields['reply_markup']},files)
                    else:result=self.telegram_write('sendAudio',fields,files)
                    receipt={'message_id':result['message_id'],'token':token,'duration':result.get('audio',{}).get('duration'),'audio':result.get('audio',{}),'prepared':self.encode_prepared(row)}
                    after_send(remember_received,self.owner,'playlist:'+stamp,{**track,'recommendationOnly':True},receipt)
                    with self.lock:
                        self.saved['cleared']=[m for m in self.saved['cleared'] if m!=receipt['message_id']];data['deliveries'][stamp]=receipt;self.save()
                # Record actual receipt even if stop won the later website acknowledgment.
                after_send(remember_received,self.owner,'playlist:'+stamp,{**track,'recommendationOnly':True},receipt)
                # The durable receipt precedes cache registration. A lost worker
                # acknowledgment can repair cache without sending Telegram twice.
                if receipt.get('audio',{}).get('file_id'):
                    ready=self.decode_prepared(receipt.get('prepared',{})) or receipt.get('prepared',{})
                    record_sent(self.api,self.owner,{**track,'recommendationOnly':True},fmt,{'message_id':receipt['message_id'],'audio':receipt['audio']},ready)
                    updated={**ready,'fields':{**ready.get('fields',{}),'audio':receipt['audio']['file_id']},'files':{}}
                    with self.lock:data['prepared'][track_key(track,fmt,getattr(self.api,'bot_id',None),self.owner)]=self.encode_prepared(updated);self.save()
                ack=self.call('playlist',{'action':'activate',**lease,'index':index,'messageId':receipt['message_id'],'token':receipt['token']})
                if ack.get('stopped'):self.clear(receipt['message_id']);break
                previous=ack.get('previous')
                if previous and previous!=receipt['message_id']:self.clear(previous)
                delivered.append(receipt['message_id'])
            # A spare is converted without uploading, counting as history, or making
            # any Telegram message. Dislike/continue can then use those exact bytes.
            if plan.get('standby') and not self.call('playlist',{'action':'check',**lease}).get('stopped'):
                try:self.prepared(session,plan['standby'],fmt);self.call('playlist',{'action':'prepared',**lease,'ready':True})
                except Exception:pass
            return {'playlistId':session,'messages':delivered}
