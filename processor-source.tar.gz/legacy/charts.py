"""Real public chart metadata; audio still comes from SoundCloud."""
import datetime,json,os,random,threading,time,urllib.request
from media import ROOT
from library import clean_artist,recording_key

_lock=threading.Lock();_started=False
def refresh():
    rows=[]
    for country in ('ru','us'):
        try:
            url=f'https://rss.marketingtools.apple.com/api/v2/{country}/music/most-played/100/songs.json'
            with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'PMXP-MusicBot/0.3'}),timeout=5) as r:
                raw=r.read(1024*1024+1)
                if len(raw)>1024*1024:raise ValueError('Large chart')
                feed=json.loads(raw)['feed']
            for rank,t in enumerate(feed['results'][:100],1):
                if isinstance(t.get('name'),str) and isinstance(t.get('artistName'),str):
                    rows.append({'artist':clean_artist(t['artistName'])[:100],'title':t['name'][:200],'releaseDate':t.get('releaseDate'),'rank':rank,'region':country,'kind':'current','chartUpdated':feed.get('updated')})
        except Exception:pass
    if rows:
        path=ROOT/'work/chart-current.json';temp=path.with_suffix('.pending.json')
        with _lock:
            previous=[]
            try:previous=json.loads(path.read_text())['tracks']
            except (OSError,ValueError):pass
            regions={r['region'] for r in rows};rows+=[r for r in previous if r.get('region') not in regions]
            temp.write_text(json.dumps({'time':time.time(),'tracks':rows},ensure_ascii=False),encoding='utf-8');os.chmod(temp,0o600);temp.replace(path)

def start_charts():
    global _started
    if _started:return
    _started=True
    def run():
        while True:refresh();time.sleep(6*3600)
    threading.Thread(target=run,name='chart-metadata',daemon=True).start()

def targets(day=None):
    bundled=json.loads((ROOT/'chart-seeds.json').read_text(encoding='utf-8'));rows=bundled['tracks']
    try:
        current=json.loads((ROOT/'work/chart-current.json').read_text())
        regions={r['region'] for r in current['tracks']};rows=[r for r in rows if r.get('kind')!='current' or r.get('region') not in regions]+current['tracks']
    except (OSError,ValueError):pass
    today=day or datetime.datetime.now(datetime.timezone.utc).date();rng=random.Random(today.isoformat())
    buckets={'fresh':[],'ru':[],'us':[],'archive':[]};seen=set()
    for row in rows:
        t={**row,'artist':clean_artist(row['artist'])};key=recording_key(t)
        if key in seen:continue
        seen.add(key)
        if t['kind']=='archive':bucket='archive';t['label']=f"Хиты {t['year']}"
        else:
            age=9999
            try:age=(today-datetime.date.fromisoformat(t.get('releaseDate',''))).days
            except (ValueError,TypeError):pass
            bucket='fresh' if 0<=age<=90 else t['region']
            t['label']=('Новинка · последние '+('7 дней' if age<=7 else '30 дней' if age<=30 else '90 дней')) if bucket=='fresh' else 'В чарте · '+('Россия' if t['region']=='ru' else 'США')
        buckets[bucket].append(t)
    # Spread an artist's tracks across the whole source pool, including new albums.
    for name,items in buckets.items():
        rng.shuffle(items);grouped={}
        for t in items:grouped.setdefault(t['artist'],[]).append(t)
        buckets[name]=[ts[i] for i in range(max((len(ts) for ts in grouped.values()),default=0)) for ts in grouped.values() if i<len(ts)]
    return [items[i] for i in range(max(map(len,buckets.values()),default=0)) for items in buckets.values() if i<len(items)]
