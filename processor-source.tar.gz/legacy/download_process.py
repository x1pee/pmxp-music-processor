from runtime_security import run as private_run, popen as private_popen
"""One prewarmed download child; a busy/missing child keeps the old CLI path.

Only readiness miss/busy before writing a request may return None. Once a
request is written, timeout/crash/protocol failure never repeats that download.
A shared two-child permit bounds this child plus the legacy CLI fallbacks.
"""
import atexit,contextlib,json,os,queue,re,secrets,subprocess,sys,tempfile,threading,time
from pathlib import Path
from media import ROOT

PROTOCOL=1
MAX_REPLY_BYTES=32768
MAX_REQUEST_BYTES=65536
STARTUP_SECONDS=8
IDLE_REUSE_SECONDS=55
MAX_REQUESTS=16
_children=threading.BoundedSemaphore(1)

class ChildLease:
    def __init__(self):self.lock=threading.Lock();self.released=False
    def release(self):
        with self.lock:
            if not self.released:self.released=True;_children.release()

@contextlib.contextmanager
def legacy_permit(timeout=180):
    started=time.monotonic();budget=max(.01,float(timeout))
    if not _children.acquire(timeout=budget):raise RuntimeError('Загрузчики заняты. Попробуй позже.')
    try:
        remaining=budget-(time.monotonic()-started)
        if remaining<=0:raise RuntimeError('Загрузчики заняты. Попробуй позже.')
        yield remaining
    finally:_children.release()

class DownloadSlot:
    def __init__(self,worker=None,root=None,startup_timeout=STARTUP_SECONDS):
        self.worker=Path(worker or Path(__file__).with_name('download_worker.py'))
        self.root=Path(root or ROOT);self.startup_timeout=startup_timeout
        self.lock=threading.Lock();self.state_lock=threading.Lock();self.process=None;self.replies=None
        self.ready=False;self.warming=False;self.warm_done=threading.Event();self.warm_done.set()
        self.child_lease=None;self.ready_at=0.;self.last_reply_at=0.;self.requests_used=0
    def usable(self):
        return self.ready and self.process is not None and self.process.poll() is None and self.requests_used<MAX_REQUESTS and time.monotonic()-max(self.ready_at,self.last_reply_at)<IDLE_REUSE_SECONDS
    def stop(self):
        p=self.process;lease=self.child_lease;self.process=None;self.child_lease=None;self.ready=False
        if p is None:
            if lease:lease.release()
            return
        try:
            if p.poll() is None:p.terminate()
            p.wait(timeout=1)
        except Exception:
            try:p.kill();p.wait(timeout=1)
            except Exception:pass
        for stream in (p.stdin,p.stdout):
            try:stream.close()
            except Exception:pass
        if lease and p.poll() is not None:lease.release()
    def start(self):
        self.stop();responses=queue.Queue(maxsize=2);self.replies=responses
        if not _children.acquire(blocking=False):raise RuntimeError('Source children occupied')
        lease=ChildLease();self.child_lease=lease
        try:
            p=private_popen([sys.executable,'-u',str(self.worker)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,
                               stderr=subprocess.DEVNULL,text=True,encoding='utf-8',bufsize=1,close_fds=True)
        except BaseException:
            lease.release();self.child_lease=None;raise
        self.process=p
        def reader():
            try:
                while True:
                    line=p.stdout.readline(MAX_REPLY_BYTES+1)
                    if not line:break
                    if len(line.encode('utf-8'))>MAX_REPLY_BYTES or not line.endswith('\n'):raise ValueError('Download reply too large')
                    value=json.loads(line)
                    if not isinstance(value,dict):raise ValueError('Invalid download reply')
                    responses.put(value,timeout=1)
            except Exception:pass
            finally:
                try:responses.put({'closed':True},timeout=1)
                except queue.Full:pass
                try:p.wait(timeout=1)
                except Exception:pass
                if p.poll() is not None:lease.release()
        threading.Thread(target=reader,name='download-reader',daemon=True).start()
        reply=responses.get(timeout=self.startup_timeout)
        if reply!={'type':'ready','protocol':PROTOCOL}:raise ValueError('Download readiness mismatch')
        self.ready=True;self.ready_at=time.monotonic();self.last_reply_at=0.;self.requests_used=0
    def warm(self):
        # Acquire before starting the thread: no request can mistake an import
        # still in progress for a busy download and create a third child.
        if not self.lock.acquire(blocking=False):return
        with self.state_lock:
            if self.usable():self.lock.release();return
            self.warming=True;self.warm_done.clear()
        def initialize():
            try:self.start()
            except Exception:self.stop()
            finally:
                with self.state_lock:self.warming=False
                self.lock.release();self.warm_done.set()
        try:threading.Thread(target=initialize,name='download-prewarm',daemon=True).start()
        except Exception:
            with self.state_lock:self.warming=False
            self.lock.release();self.warm_done.set()
    def wait_ready(self,timeout=STARTUP_SECONDS):
        self.warm_done.wait(max(0,timeout))
        return self.usable()
    def close(self):
        self.warm_done.wait(self.startup_timeout+1)
        with self.lock:self.stop()
    def _progress(self,payload,on_progress):
        """Fresh identity-bound channel; same polling cadence as legacy CLI."""
        if on_progress is None:return dict(payload),lambda:None
        work=self.root/'work';work.mkdir(parents=True,exist_ok=True)
        fd,name=tempfile.mkstemp(prefix='progress-',suffix='.json',dir=work);os.close(fd);target=Path(name)
        stop=threading.Event();last=[None]
        def read():
            try:
                if target.stat().st_size>2048:return
                value=json.loads(target.read_text(encoding='utf-8'))
                if value!=last[0]:last[0]=value;on_progress(value)
            except Exception:pass
        def watch():
            while not stop.wait(.3):read()
        thread=threading.Thread(target=watch,name='download-progress',daemon=True);thread.start()
        def finish():
            stop.set();thread.join(.5);read()
            for path in (target,target.with_suffix('.pending.json')):
                try:path.unlink(missing_ok=True)
                except OSError:pass # Optional status cleanup never fails ready audio.
        return {**payload,'progressPath':str(target.resolve())},finish
    def try_download(self,payload,timeout=180,on_progress=None):
        budget=max(.01,min(240,float(timeout)));deadline=time.monotonic()+budget
        with self.state_lock:warming=self.warming
        if warming and not self.warm_done.wait(max(0,deadline-time.monotonic())):
            # The warm import has not written this job. Do not launch another
            # child while it is still consuming one of the preparation slots.
            raise RuntimeError('Подготовка загрузчика отвечает долго. Попробуй позже.')
        if not self.lock.acquire(blocking=False):return None
        finish=lambda:None
        try:
            if not self.usable():
                self.stop();return None
            if not isinstance(payload,dict) or payload.get('action')!='download' or payload.get('provider') not in ('SoundCloud','YouTube','Bandcamp'):raise ValueError('Download only')
            payload,finish=self._progress(payload,on_progress);ident=secrets.token_hex(16)
            line=json.dumps({'id':ident,'payload':payload},ensure_ascii=False)+'\n'
            if len(line.encode('utf-8'))>MAX_REQUEST_BYTES:raise ValueError('Download request too large')
            # Any failure from this point is terminal for this request. Even a
            # broken write can have reached the child; never choose CLI fallback.
            try:
                self.process.stdin.write(line);self.process.stdin.flush()
                reply=self.replies.get(timeout=max(.001,deadline-time.monotonic()))
                if reply.get('id')!=ident or not isinstance(reply.get('ok'),bool):raise ValueError('Download correlation mismatch')
                self.requests_used+=1;self.last_reply_at=time.monotonic()
                if self.requests_used>=MAX_REQUESTS:self.stop()
                if not reply['ok']:raise RuntimeError(str(reply.get('error') or 'Источник не отдал аудио.')[:300])
                path=Path(reply.get('result',''));stat=path.stat()
                track=payload.get('track') or {};track_id=str(payload.get('id') if payload['provider']=='SoundCloud' else track.get('id',''))
                if path.is_symlink() or not path.is_file() or path.parent.resolve()!=(self.root/'work').resolve() or not re.fullmatch(r'sc-'+re.escape(track_id)+r'\.(?:m4a|mp3|opus|ogg|webm)',path.name) or not 0<stat.st_size<=49*1024*1024:raise ValueError('Invalid completed audio')
                return str(path)
            except RuntimeError:raise
            except (queue.Empty,OSError,ValueError,TypeError,KeyError):
                self.stop();raise RuntimeError('Загрузчик источника отвечает долго или недоступен. Попробуй позже.') from None
        finally:
            try:finish()
            finally:self.lock.release()

_slot=DownloadSlot()
atexit.register(_slot.close)
def warm():_slot.warm()
def wait_ready(timeout=STARTUP_SECONDS):return _slot.wait_ready(timeout)
def try_download(payload,timeout=180,on_progress=None):return _slot.try_download(payload,timeout,on_progress)
