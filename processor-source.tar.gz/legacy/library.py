"""Import Telegram HTML without executing its scripts or following its links."""
import argparse, csv, html, json, re, unicodedata
from track_versions import version_labels,clean_edition_bracket
from html.parser import HTMLParser
from pathlib import Path

class Node:
    def __init__(self, tag='', attrs=()):
        self.tag, self.attrs, self.children = tag, dict(attrs), []
    def has(self, name): return name in self.attrs.get('class', '').split()
    def text(self): return ''.join(x.text() if isinstance(x, Node) else x for x in self.children)
    def walk(self):
        yield self
        for x in self.children:
            if isinstance(x, Node): yield from x.walk()

class ExportParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.root=Node(); self.stack=[self.root]
    def handle_starttag(self, tag, attrs):
        node=Node(tag, attrs); self.stack[-1].children.append(node)
        if tag not in {'br','img','meta','link','hr','input','source','wbr'}: self.stack.append(node)
    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if self.stack[-1].tag==tag: self.stack.pop()
    def handle_endtag(self, tag):
        for i in range(len(self.stack)-1,0,-1):
            if self.stack[i].tag==tag: self.stack=self.stack[:i]; break
    def handle_data(self, text): self.stack[-1].children.append(text)

def clean(value):
    styled=str.maketrans({'ᴀ':'a','ʙ':'b','ᴄ':'c','ᴅ':'d','ᴇ':'e','ꜰ':'f','ɢ':'g','ʜ':'h','ɪ':'i','ᴊ':'j','ᴋ':'k','ʟ':'l','ᴍ':'m','ʍ':'m','ɴ':'n','ᴏ':'o','ᴘ':'p','ʀ':'r','ꜱ':'s','ᴛ':'t','ᴜ':'u','ᴠ':'v','ᴡ':'w','ʏ':'y','ᴢ':'z','ᴨ':'п','ᴩ':'р','ᴎ':'и'})
    value=unicodedata.normalize('NFKC', value).translate(styled)
    value=''.join(x for x in value if unicodedata.category(x)!='Cf')
    lookalikes=str.maketrans({'a':'а','c':'с','e':'е','m':'м','o':'о','p':'р','t':'т','x':'х','y':'у'})
    value=re.sub(r'[^\W\d_]+',lambda m:m[0].translate(lookalikes) if re.search('[а-яё]',m[0],re.I) else m[0],value)
    return re.sub(r'\s+', ' ', value).strip()

FEATURE_MARKER=r'(?:\b(?:feat|ft)\.?\s+(?=\S)|\b(?:feat|ft)\.(?=\S)|\bпри\s*(?:участии|уч\.?)(?=\s)\s+)'

def _balanced_credit_text(text):
    stack=[];remove=set();pairs={')':'(',']':'['}
    for index,char in enumerate(text):
        if char in '([':stack.append((char,index))
        elif char in ')]':
            if stack and stack[-1][0]==pairs[char]:stack.pop()
            else:remove.add(index)
    remove.update(index for _,index in stack)
    return ''.join(char for index,char in enumerate(text) if index not in remove).strip()

def _artist_feature_text(value):
    text=clean(value);pieces=[];guests=[];position=0
    for match in re.finditer(r'[\[(]\s*'+FEATURE_MARKER,text,re.I):
        if match.start()<position:continue
        stack=[];end=len(text);close=end
        for index in range(match.start(),len(text)):
            char=text[index]
            if char in '([':stack.append(char)
            elif char in ')]' and stack and {'(':')','[':']'}[stack[-1]]==char:
                stack.pop()
                if not stack:close=index;end=index+1;break
        guest=text[match.end():close].strip();guests.append(guest)
        pieces.extend([text[position:match.start()],', '+guest]);position=end
    pieces.append(text[position:]);text=''.join(pieces)
    inline=re.search(FEATURE_MARKER,text,re.I)
    if inline:guests.append(text[inline.end():])
    return re.sub(FEATURE_MARKER,', ',text,flags=re.I),guests

from functools import lru_cache

def clean_artist(value):
    # Artist cleanup is pure. Bound both cache entries and retained input size.
    return _cached_clean_artist(value) if isinstance(value,str) and len(value)<=200 else _clean_artist_uncached(value)

@lru_cache(maxsize=2048)
def _cached_clean_artist(value):
    return _clean_artist_uncached(value)

def _clean_artist_uncached(value):
    text,_=_artist_feature_text(value)
    text=re.sub(r'\s*,\s*', ', ', text).strip(' ,')
    parts=re.split(r'(\s*(?:&|,|\+)\s*|\s+[xх×]\s+)',text,flags=re.I)
    return ', '.join(dict.fromkeys(p for raw in parts[::2] if (p:=_balanced_credit_text(raw))))

FEATURE_ARTIST_RE=re.compile(FEATURE_MARKER+r'(.+)$',re.I)
FEATURE_RE=re.compile(r'[\[(]\s*'+FEATURE_MARKER+r'([^\])]+)[\])]',re.I)
PRODUCTION_RE=re.compile(r'(?:\s*[\[(]\s*|\s+)(?:p\.\s*|prod(?:\.\s*|\s+)|produced\s+by\s+)(?:by\s+)?([^\])]+)(?:[\])]|$)',re.I)

PRODUCTION_SUFFIX_RE=re.compile(r'[\[(]\s*([^()\[\]\n]{1,100}?)\s+prod\.?\s*[\])]',re.I)

def clean_track_tags(track,known_artists=()):
    producers=list(dict.fromkeys(clean(name) for raw in [track.get('title',''),track.get('original','')] for name in PRODUCTION_RE.findall(clean(raw)))) or track.get('productionCredits',[])
    producers=list(dict.fromkeys([*producers,*[clean(name) for raw in [track.get('title',''),track.get('original','')] for name in PRODUCTION_SUFFIX_RE.findall(clean(raw))]]))
    artist=clean_artist(track.get('artist',''));title=clean_title(track.get('title',''))
    confirmed=track.get('metadataConfirmed') is True and not track.get('manualTags') and track.get('catalogueState')!='custom' and track.get('tagsMode')!='original'
    raw_identity=lambda value:re.sub(r'\W','',clean_artist(value).casefold().replace('ё','е'))
    # This observed spelling pair is comparison-only and must be anchored to an
    # already declared contributor. It never transliterates arbitrary names.
    latin_paranoia=confirmed and any(raw_identity(part)=='paranoia' for part in artist.split(', '))
    identity=lambda value:'paranoia' if latin_paranoia and raw_identity(value) in {'паранойя','параноя'} else raw_identity(value)
    names={identity(p) for a in [*known_artists,artist] if a for p in clean_artist(a).split(', ')}
    members=lambda a:[p.strip() for p in re.split(r'\s*(?:&|,|\+)\s*|\s+[xх×]\s+',clean_artist(a),flags=re.I) if p.strip()]
    credit_keys=lambda value:{identity(p) for p in members(value) if identity(p)}
    artist_keys=credit_keys(artist)
    boundary=r'\s+[—–-]\s+|[—–]'+(r'|-{2,}' if confirmed else '')
    guests=[]
    # A structured feature credit before a clear upload separator has the same
    # meaning as a bracketed feature credit. Keep the guest in performer tags.
    if confirmed:
        feature_title=title
        upload=re.match(r'^(.+?)\s*-\s*('+FEATURE_MARKER+r'.+)$',title,re.I)
        if upload and credit_keys(upload[1])==artist_keys:feature_title=upload[2]
        featured_prefix=re.match(r'^'+FEATURE_MARKER+r'(.+?)(?:\s+[—–-]\s+|[—–]|-{2,})(.+)$',feature_title,re.I)
        if featured_prefix:
            features=members(featured_prefix[1]);song=featured_prefix[2].strip()
            if features and len(features)<=6 and len(featured_prefix[1])<=100 and song and len(song)<=200 and not re.search(r'[\[\]()]',featured_prefix[1]):
                guests.extend(features);artist=clean_artist(', '.join([artist,*features]));title=song
                artist_keys=credit_keys(artist);names.update(artist_keys)
    # No-dash collaboration suffixes need all declared performers, an explicit
    # credit separator and independent roster evidence for every extra name.
    # Ordinary mentions and a single trailing artist are intentionally retained.
    if confirmed and len(title)<=400:
        suffixes=[]
        for gap in re.finditer(r'\s+',title):
            song=title[:gap.start()].strip();suffix=title[gap.end():].strip()
            if not song or len(song)>200 or len(suffix)>100 or re.search(r'[\[\]()]',suffix) or not re.search(r'[&,+]|\s+[xх×]\s+',suffix,re.I):continue
            suffix_keys=credit_keys(suffix)
            if len(suffix_keys)>=2 and artist_keys and artist_keys<=suffix_keys and suffix_keys<=names:suffixes.append((song,suffix))
        if len(suffixes)==1:
            title,suffix=suffixes[0]
            canonical={identity(name):name for raw in [*known_artists,artist] for name in members(raw)}
            artist=artist if credit_keys(suffix)==artist_keys else ', '.join(canonical.get(identity(name),name) for name in members(suffix));artist_keys=credit_keys(artist)
    # Compare the complete credited name before splitting: an artist can itself
    # contain a hyphen, and an uploader can prepend a track ordinal. A compact
    # ASCII hyphen belongs to the name/title; it is not wrapper evidence.
    for delimiter in re.finditer(boundary,title):
        prefix=re.sub(r'^\d{1,3}[.)]\s*','',title[:delimiter.start()])
        suffix=title[delimiter.end():].strip()
        prefix_keys=credit_keys(prefix)
        # An upload may repeat only one of its already confirmed contributors.
        # Remove that wrapper while retaining the complete performer/role list.
        if artist_keys and suffix and (prefix_keys==artist_keys or track.get('metadataConfirmed') is True and prefix_keys and prefix_keys<artist_keys):title=suffix;break
    parts=re.split(boundary,title,maxsplit=1)
    if len(parts)==2 and parts[1]:
        prefix=clean_artist(parts[0]);credits=members(prefix)
        numbered=clean_artist(re.sub(r'^\d{1,3}[.)]\s*','',parts[0]))
        if numbered!=prefix and identity(numbered)==identity(artist):prefix=numbered;credits=members(prefix)
        # A known name in a song subtitle cannot replace confirmed artist data.
        if credits and all(identity(a) in names for a in credits) and (not track.get('metadataConfirmed') or artist_keys<=credit_keys(prefix)):
            artist=artist if credit_keys(prefix)==artist_keys else ' & '.join(dict.fromkeys(credits));title=parts[1]
        else:
            # Reversed upload titles are safe to split only when the whole suffix
            # resolves to known performers and retains confirmed main credits.
            suffix=clean_artist(parts[1]);credits=members(suffix)
            if credits and all(identity(a) in names for a in credits) and (not track.get('metadataConfirmed') or artist_keys<=credit_keys(suffix)):
                artist=artist if credit_keys(suffix)==artist_keys else suffix;title=parts[0]
    # Preserve roles separately while the complete credit list remains the identity.
    if artist and track.get('metadataConfirmed'):
        # Trailing upload credit (not a subtitle): 'Song при уч. Artist'.
        # Keep the contributor role and preserve the literal original field.
        if confirmed:
            inline=re.search(r'\s+'+FEATURE_MARKER+r'([^()\[\]]{1,100})$',title,re.I)
            if inline and title[:inline.start()].strip():
                names_inline=members(inline[1])
                if 0<len(names_inline)<=6 and not re.search(r'[—–]|-{2,}|\s+-\s+',inline[1]):guests.extend(names_inline);title=title[:inline.start()].strip()
        def feature(match):guests.append(match[1]);return ''
        title=clean(FEATURE_RE.sub(feature,title))
        artists=members(', '.join([artist,*guests]));seen=set();unique=[]
        for name in artists:
            key=re.sub(r'\W','',name.casefold().replace('ё','е'))
            if key not in seen:seen.add(key);unique.append(name)
        artist=', '.join(unique)
    labels=list(dict.fromkeys([*version_labels(clean(track.get('original') or track.get('title',''))),*version_labels(title),*(track.get('versionLabels',[]) if not track.get('original') else [])]))
    result={**track,'artist':clean_artist(artist),'title':title,'versionLabels':labels}
    if producers:result['productionCredits']=producers
    if artist and track.get('metadataConfirmed'):
        all_artists=members(artist)
        hinted=[*guests,*_artist_feature_text(track.get('artist',''))[1],*_artist_feature_text(track.get('originalArtist',''))[1],*FEATURE_RE.findall(clean(track.get('original',''))),*track.get('featuredArtists',[])]
        key=lambda name:re.sub(r'\W','',name.casefold().replace('ё','е'))
        guest_keys={key(n) for h in hinted for n in members(h)}
        featured=[n for n in all_artists if key(n) in guest_keys]
        primary=[n for n in all_artists if key(n) not in guest_keys]
        if featured and primary:result.update(mainArtist=', '.join(primary),featuredArtists=featured)
        else:result.pop('mainArtist',None);result.pop('featuredArtists',None)
    return result

def clean_title(value):
    title=clean(value)
    title=PRODUCTION_SUFFIX_RE.sub('',PRODUCTION_RE.sub('',title)).strip()
    title=re.sub(r'(?:[\[(]\s*live[\s_-]+session\s*[\])]|\s+(?:[-—–]\s*)?live[\s_-]+session\s*$)', ' (Live)', title, flags=re.I)
    # Keep actual versions, featured artists and meaningful subtitles.
    def bracket(match):
        text=match[0][1:-1].strip()
        edition=clean_edition_bracket(text)
        if not edition:return ''
        if edition!=text:return match[0][0]+edition+match[0][-1]
        noise=re.fullmatch(r'(?:HD|HQ|4K|1080p|720p|official(?:\s+(?:music|audio|video|lyric|lyrics))*|audio|video|lyrics?|visuali[sz]er|prod\.?\s+.+|produced by\s+.+|(?:а?ха)+\w*|(?:ha)+\w*|https?://\S+)',text,re.I)
        return '' if noise or not re.search(r'\w',text) else match[0]
    trimmed=re.sub(r'\([^()]*\)|\[[^\[\]]*\]',bracket,title)
    trimmed=re.sub(r'\s+(?:HD|HQ|4K)\s*$','',trimmed,flags=re.I).strip(' —–-')
    # Remove promotion appended by reuploaders, including bare domains.
    trimmed=re.sub(r'(?:\s*[-—–|]\s*|\s+)(?:https?://\S+|www\.\S+|[a-z0-9][a-z0-9.-]*\.(?:com|ru|net|org|io|cc|me|fun|su|xyz|online|site)(?:/\S*)?)\s*$', '',trimmed,flags=re.I).strip(' —–-|')
    trimmed=re.sub(r'\s+',' ',trimmed).strip()
    return trimmed or title

def recording_key(track):
    def key(value):
        value=clean(value).casefold().replace('ё','е')
        return re.sub(r'\W','',value) or value
    artist=clean_artist(track.get('artist',''))
    members=re.split(r'\s*(?:&|,|\+)\s*|\s+[xх×]\s+',artist,flags=re.I)
    return '+'.join(sorted(set(key(x) for x in members if x)))+':'+key(clean_title(track.get('title','')))

def listening_key(track):
    """Featured credits can live in either performer tags or the title."""
    title=clean_title(track.get('title',''));artists=[track.get('artist','')]
    def feature(match):
        artists.append(match[1]);return ''
    title=FEATURE_RE.sub(feature,title)
    return recording_key({'artist':', '.join(artists),'title':title.strip()})

def split_tags(raw, known_artists=()):
    raw=clean(raw)
    parts=re.split(r'\s+[–—-]\s+|[–—]',raw,maxsplit=1)
    artist,title=(parts if len(parts)==2 else ['',raw])
    source_artist=''; flags=[]
    # A nested artist/title delimiter is evidence, not a guess about a username.
    nested=re.split(r'\s+[–—-]\s+|[–—]', title, maxsplit=1)
    known={clean(x).casefold() for x in known_artists if clean(x)}
    if len(nested)==2 and all(x.strip() for x in nested) and nested[0].strip().casefold() in known:
        source_artist, artist, title=artist,nested[0].strip(),nested[1].strip()
        flags.append('Вложенные теги: проверь исполнителя')
    else:
        for prefix in sorted(known,key=len,reverse=True):
            if prefix!=artist.casefold() and title.casefold().startswith(prefix+' '):
                source_artist,artist,title=artist,title[:len(prefix)],title[len(prefix):].strip().lstrip('–—-').strip()
                flags.append('Имя артиста в названии: проверь совпадение')
                break
    title=re.sub(r'\s+[-–—]+\s*$','',title).strip()
    if re.search(r'\b(snippet|sped\s*up|slowed|remix|live)\b',title,re.I): flags.append('Особая версия: сохранить пометку')
    if not artist: flags.append('Исполнитель не указан')
    return artist.strip(),title,source_artist,flags

def parse_export(path):
    parser=ExportParser(); parser.feed(Path(path).read_text(encoding='utf-8-sig'))
    tracks=[]
    known_artists={split_tags(clean(x.text()))[0] for x in parser.root.walk() if x.has('title')}
    for msg in parser.root.walk():
        if not msg.has('message'): continue
        for audio in (x for x in msg.walk() if x.has('media_audio_file')):
            title=next((clean(x.text()) for x in audio.walk() if x.has('title')),'')
            status=next((clean(x.text()) for x in audio.walk() if x.has('status')),'')
            duration=re.search(r'(?:(\d+):)?(\d{1,2}):(\d{2})',status)
            seconds=(int(duration[1] or 0)*3600+int(duration[2])*60+int(duration[3])) if duration else None
            artist,name,uploader,flags=split_tags(title,known_artists)
            date=next((x.attrs.get('title','') for x in msg.walk() if x.has('date')),'')
            urls=[x.attrs['href'] for x in msg.walk() if x.tag=='a' and x.attrs.get('href','').startswith(('https://','http://'))]
            tracks.append(dict(message_id=msg.attrs.get('id'),date=date,original=title,artist=artist,title=name,
                source_artist=uploader,duration=seconds,status=status,urls=urls,audio_available=False,review=flags))
    return tracks

def write_catalog(tracks, out):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    (out/'catalog.json').write_text(json.dumps(tracks,ensure_ascii=False,indent=2),encoding='utf-8')
    with (out/'catalog.csv').open('w',encoding='utf-8-sig',newline='') as file:
        writer=csv.DictWriter(file,fieldnames=['artist','title','source_artist','duration','original','message_id','date'])
        writer.writeheader();writer.writerows({k:t[k] for k in writer.fieldnames} for t in tracks)
    rows=''.join('<tr><td>'+str(i+1)+'</td><td>'+html.escape(t['artist'])+'</td><td>'+html.escape(t['title'])+
        '</td><td>'+html.escape(t['source_artist'])+'</td><td>'+html.escape(t['status'])+'</td><td>'+html.escape('; '.join(t['review']))+'</td></tr>' for i,t in enumerate(tracks))
    report='''<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>PMXP · Музыкальная коллекция</title><style>
    :root{color-scheme:dark}body{background:#101116;color:#e9e9f0;font:15px system-ui;margin:32px auto;max-width:1200px;padding:0 20px}h1{font-size:30px}p{color:#a4a7b7}input{width:100%;box-sizing:border-box;border:1px solid #303441;border-radius:14px;padding:14px;background:#191c24;color:inherit;margin:12px 0 24px}table{width:100%;border-collapse:collapse}td,th{text-align:left;padding:14px 10px;border-bottom:1px solid #282b34}th{color:#a5a9bb;font-weight:500}td:first-child{color:#777c90}td:nth-child(4),td:last-child{font-size:12px;color:#9d91bd}.wrap{overflow:auto}</style>
    <h1>Твоя музыкальная коллекция</h1><p>COUNT записей · аудио не включено в экспорт. Исходные названия сохранены; исправления требуют сверки с каталогом.</p><input id="search" placeholder="Название или исполнитель" aria-label="Поиск по коллекции"><div class="wrap"><table><thead><tr><th>№</th><th>Исполнитель</th><th>Трек</th><th>Загрузивший</th><th>Длительность</th><th>Проверка</th></tr></thead><tbody>ROWS</tbody></table></div><script>document.querySelector('#search').addEventListener('input',e=>{const q=e.target.value.toLocaleLowerCase();for(const row of document.querySelectorAll('tbody tr'))row.hidden=!row.textContent.toLocaleLowerCase().includes(q)});</script></html>'''.replace('COUNT',str(len(tracks))).replace('ROWS',rows)
    (out/'collection.html').write_text(report,encoding='utf-8')
    unique=len({(t['artist'].casefold(),t['title'].casefold(),t['duration']) for t in tracks})
    return dict(entries=len(tracks),unique=unique,nested_tags=sum(bool(t['source_artist']) for t in tracks),audio_files=0)

if __name__=='__main__':
    args=argparse.ArgumentParser();args.add_argument('html');args.add_argument('--out',default='catalog')
    opt=args.parse_args(); print(json.dumps(write_catalog(parse_export(opt.html),opt.out),ensure_ascii=False))
