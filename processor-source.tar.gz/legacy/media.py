from runtime_security import run as private_run, popen as private_popen
import json, re, shutil, subprocess, sys, threading, urllib.parse, urllib.request, hashlib, time, secrets
from difflib import SequenceMatcher
from pathlib import Path
from library import clean,clean_title,clean_artist
from media_security import local_input,MAX_IMAGE_PIXELS

ROOT=Path(__import__('os').environ['PMP_RUNTIME_ROOT']).resolve()
sys.path.insert(0,str(ROOT/'vendor'))

def ffmpeg_path():
    found=shutil.which('ffmpeg')
    if found: return found
    import imageio_ffmpeg
    return imageio_ffmpeg.get_ffmpeg_exe()

conversion_slots=threading.BoundedSemaphore(1)
def run_ffmpeg(args,timeout=180):
    with conversion_slots:
        result=private_run([ffmpeg_path(),'-hide_banner','-loglevel','error','-nostdin','-threads','1','-filter_threads','1','-filter_complex_threads','1',*args],capture_output=True,timeout=timeout)
    if result.returncode: raise RuntimeError('Не удалось прочитать или обработать аудиофайл')

def convert_audio(source, output, artist, title, cover=None,correct_tags=True,end_at=None,extra_tags=None):
    if correct_tags:artist,title=clean_artist(artist),clean_title(title)
    source,output=Path(source),Path(output)
    if not source.is_file() or source.resolve()==output.resolve(): raise ValueError('Original must remain unchanged')
    if output.suffix not in {'.mp3','.m4a'}: raise ValueError('Unsupported output')
    # No network protocols inside ffmpeg, even if a file masquerades as a playlist.
    args=['-y',*local_input(source)]
    if cover: args+=local_input(cover,image=True)
    args+=['-map','0:a:0']
    if cover: args+=['-map','1:v:0','-c:v','mjpeg','-disposition:v:0','attached_pic','-metadata:s:v:0','title=Album cover','-metadata:s:v:0','comment=Cover (front)']
    args+=['-map_metadata','0','-metadata','artist='+artist,'-metadata','title='+title]
    if extra_tags is not None:
        from chat_tags import OPTIONAL,validate
        if not isinstance(extra_tags,dict) or any(name not in OPTIONAL for name in extra_tags):raise ValueError('Unsupported audio tags')
        for name,value in extra_tags.items():args+=['-metadata',{'year':'date','trackNumber':'track'}.get(name,name)+'='+validate(name,value)]
    # Probe the source codec locally: copy compatible AAC/MP3 without another lossy encode.
    probe=private_run([ffmpeg_path(),'-hide_banner',*local_input(source)],capture_output=True,timeout=20)
    info=probe.stderr.decode('utf-8',errors='replace')
    if not cover:
        videos=[line for line in info.splitlines() if 'Stream #' in line and 'Video:' in line]
        dimensions=[re.search(r',\s*(\d+)x(\d+)(?=[\s,])',line) for line in videos]
        # Stream copying does not decode pixels. Preserve ordinary embedded
        # artwork only when every copied video has a bounded known size.
        if videos and all(size and 0<int(size[1])*int(size[2])<=MAX_IMAGE_PIXELS for size in dimensions):
            args+=['-map','0:v?','-c:v','copy','-disposition:v:0','attached_pic']
    compatible=(output.suffix=='.m4a' and 'Audio: aac' in info) or (output.suffix=='.mp3' and 'Audio: mp3' in info)
    if end_at is not None:
        if not isinstance(end_at,(int,float)) or not 0<end_at<=1085:raise ValueError('Invalid audio end')
        args+=['-t',str(round(end_at,3))]
    args+=['-threads','1']
    args+=['-c:a','copy'] if compatible else (['-c:a','libmp3lame','-q:a','2','-id3v2_version','3'] if output.suffix=='.mp3' else ['-c:a','aac','-b:a','192k'])
    run_ffmpeg(args+[str(output)])
    if not output.exists() or not output.stat().st_size: raise RuntimeError('Пустой результат')
    return output

def search_genius(query, token):
    if not token: raise RuntimeError('Для поиска Genius нужен ключ API — настрой его на ПК')
    request=urllib.request.Request('https://api.genius.com/search?'+urllib.parse.urlencode({'q':clean(query)}),headers={'Authorization':'Bearer '+token,'User-Agent':'PMXP-MusicBot/0.1'})
    with urllib.request.urlopen(request,timeout=15) as response: data=json.load(response)
    songs=[]
    for hit in data.get('response',{}).get('hits',[]):
        if hit.get('type')!='song':continue
        item=hit['result']; artist=item.get('primary_artist',{}).get('name','')
        songs.append(dict(id=item['id'],title=item.get('title',''),artist=artist,url=item.get('url',''),cover=item.get('song_art_image_url') or item.get('header_image_url','')))
    return songs[:5]

from work_cache import keyed_lock

def download_cover(url, target):
    parsed=urllib.parse.urlparse(url)
    if parsed.scheme!='https' or parsed.port not in (None,443) or not (parsed.hostname=='images.genius.com' or re.fullmatch(r'is\d+-ssl\.mzstatic\.com',parsed.hostname or '') or parsed.hostname in {'i1.sndcdn.com','i.ytimg.com','f4.bcbits.com','yt3.googleusercontent.com','lh3.googleusercontent.com'}) or parsed.username or parsed.password: raise ValueError('Unsupported cover source')
    digest=hashlib.sha256(url.encode()).hexdigest()
    cached=ROOT/'work'/('sc-art-'+digest+'.jpg')
    # Same album artwork is reused across tracks and concurrent deliveries.
    # Validate every URL before consulting the cache; never trust partial files.
    with keyed_lock(('artwork',digest)):
        try:
            if not cached.is_symlink() and cached.is_file() and 0<cached.stat().st_size<=8*1024*1024 and time.time()-cached.stat().st_mtime<172800:
                # Old cache entries were admitted on Content-Type alone.
                # A real decode also warms the reusable Telegram thumbnail.
                prepare_cover_thumbnail(cached)
                shutil.copyfile(cached,target);return Path(target)
        except (OSError,ValueError,RuntimeError,subprocess.TimeoutExpired):
            cached.unlink(missing_ok=True)
        result=_download_cover_uncached(url,target)
        # Reject invalid images before caching/embedding; delivery can then
        # try its next artwork candidate instead of failing audio conversion.
        prepare_cover_thumbnail(result)
        temporary=cached.with_name(cached.name+'.'+secrets.token_hex(6)+'.pending')
        try:
            cached.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(result,temporary);temporary.replace(cached)
        except OSError:pass
        finally:
            try:temporary.unlink(missing_ok=True)
            except OSError:pass
        try:
            entries=sorted(cached.parent.glob('sc-art-*.jpg'),key=lambda p:p.stat().st_mtime,reverse=True)
            for old in entries[128:]:
                try:old.unlink()
                except OSError:pass
        except OSError:pass
        return result

def _download_cover_uncached(url,target):
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self,*args,**kwargs): raise ValueError('Unexpected cover redirect')
    opener=urllib.request.build_opener(NoRedirect)
    with opener.open(urllib.request.Request(url,headers={'User-Agent':'PMXP-MusicBot/0.1'}),timeout=15) as response:
        if not response.headers.get('Content-Type','').startswith('image/'): raise ValueError('Not an image')
        data=response.read(8*1024*1024+1)
    if len(data)>8*1024*1024: raise ValueError('Cover too large')
    Path(target).write_bytes(data);return Path(target)

def search_metadata(artist,title,token=''):
    if token:
        try:
            songs=search_genius(artist+' '+title,token)
            if songs:
                for song in songs:song['provider']='Genius'
                return songs
        except Exception:pass
    def key(value):return re.sub(r'[^\w]+','',clean(value).casefold().replace('ё','е'))
    def matches(item):
        return SequenceMatcher(None,key(title),key(item.get('trackName',''))).ratio()>=.85 and key(artist) in key(item.get('artistName',''))
    def read(endpoint,params):
        req=urllib.request.Request('https://itunes.apple.com/'+endpoint+'?'+urllib.parse.urlencode(params),headers={'User-Agent':'PMXP-MusicBot/0.2'})
        with urllib.request.urlopen(req,timeout=15) as response:return json.load(response).get('results',[])
    # Verified public release IDs act as a catalogue index, not special cases in the resolver.
    index=ROOT/'release-index.json'
    known=json.loads(index.read_text(encoding='utf-8')) if index.exists() else []
    releases=[x for x in known if key(x['title'])==key(title) and key(artist) in key(x['artist'])]
    records=[]
    for release in releases[:2]:records+=read('lookup',{'id':release['collectionId'],'entity':'song'})
    if not any(matches(x) for x in records):
        records+=read('search',{'term':artist+' '+title,'entity':'song','limit':20})
    if not any(matches(x) for x in records):
        records+=read('search',{'term':title,'entity':'song','limit':20})
    songs=[];seen=set()
    for item in records:
        if item.get('wrapperType')!='track' or not item.get('trackId') or not matches(item) or item['trackId'] in seen:continue
        seen.add(item['trackId'])
        songs.append(dict(id=item['trackId'],artist=item['artistName'],title=item['trackName'],url=item.get('trackViewUrl',''),provider='Apple Music',
            cover=re.sub(r'/\d+x\d+bb\.jpg$', '/600x600bb.jpg',item.get('artworkUrl100',''))))
    return songs[:5]

def safe_name(artist,title):
    value=re.sub(r'[<>:"/\\|?*\x00-\x1f]','_',artist+' — '+title).strip(' .')[:140]
    return value or 'track'

def prepare_cover_thumbnail(source,target=None):
    # Exact selected image bytes identify a reusable Telegram JPEG, not the song.
    source=Path(source)
    with source.open('rb') as handle:blob=handle.read(8*1024*1024+1)
    if not 0<len(blob)<=8*1024*1024:raise ValueError('Cover too large')
    digest=hashlib.sha256(blob).hexdigest();folder=ROOT/'work';folder.mkdir(exist_ok=True)
    cached=folder/('sc-thumb-'+digest+'.jpg')
    from work_cache import keyed_lock
    with keyed_lock(('telegram-thumbnail',digest)):
        def valid(path):
            try:return not path.is_symlink() and 0<path.stat().st_size<200*1024 and path.read_bytes().startswith(b'\xff\xd8\xff')
            except OSError:return False
        if not valid(cached) or time.time()-cached.stat().st_mtime>=172800:
            temp=folder/('sc-thumb-'+digest+'-'+secrets.token_hex(6)+'.pending.jpg')
            try:
                run_ffmpeg(['-y',*local_input(source,image=True),'-frames:v','1','-vf','scale=320:320:force_original_aspect_ratio=decrease,pad=320:320:(ow-iw)/2:(oh-ih)/2,setsar=1','-q:v','5',str(temp)],timeout=15)
                if not valid(temp):raise RuntimeError('Invalid Telegram thumbnail')
                temp.chmod(0o600);temp.replace(cached)
            finally:temp.unlink(missing_ok=True)
            try:
                for old in sorted(folder.glob('sc-thumb-*.jpg'),key=lambda p:p.stat().st_mtime,reverse=True)[128:]:
                    if old!=cached:old.unlink(missing_ok=True)
            except OSError:pass  # Concurrent pruning cannot fail a valid thumbnail.
        if target is None:return cached
        shutil.copyfile(cached,target);return Path(target)

def telegram_audio_details(source, thumbnail, selected_cover=None):
    result=private_run([ffmpeg_path(),'-hide_banner',*local_input(source)],capture_output=True,timeout=30)
    info=result.stderr.decode('utf-8',errors='replace')
    found=re.search(r'Duration: (\d+):(\d+):(\d+(?:\.\d+)?)',info)
    if not found: raise RuntimeError('Не удалось определить длительность аудио')
    duration=max(1,round(int(found[1])*3600+int(found[2])*60+float(found[3])))
    cover=None
    if 'attached pic' in info and selected_cover:
        try:cover=prepare_cover_thumbnail(selected_cover,thumbnail)
        except Exception:pass
    if 'attached pic' in info and cover is None:
        run_ffmpeg(['-y',*local_input(source),'-map','0:v:0','-frames:v','1','-vf','scale=320:320:force_original_aspect_ratio=decrease,pad=320:320:(ow-iw)/2:(oh-ih)/2,setsar=1','-q:v','5',str(thumbnail)],timeout=15)
        cover=Path(thumbnail)
        if cover.stat().st_size>=200*1024:raise RuntimeError('Миниатюра слишком большая')
    return duration,cover
