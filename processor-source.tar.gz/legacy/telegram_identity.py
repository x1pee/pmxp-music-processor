"""Read document identity only from Telegram's document file_unique_id.

Unknown encodings fail closed and retain the desktop audio fallback.
"""
import base64,re,struct

def document_id(value):
    if not isinstance(value,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,128}',value):return None
    try:
        packed=base64.b64decode(value+'='*((-len(value))%4),altchars=b'-_',validate=True)
        decoded=bytearray();i=0
        while i<len(packed):
            byte=packed[i];i+=1
            if byte:decoded.append(byte)
            else:
                if i==len(packed) or not packed[i]:return None
                decoded.extend(bytes(packed[i]));i+=1
            if len(decoded)>12:return None
        if len(decoded)!=12:return None
        kind,identity=struct.unpack('<iq',decoded)
        return str(identity) if kind==2 and identity else None
    except (ValueError,struct.error):return None
