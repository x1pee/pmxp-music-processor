"""Small shared primitives for concurrent metadata work; no network on import."""
import json,os,threading,uuid
from contextlib import contextmanager

_guard=threading.Lock()
_flights={}

@contextmanager
def keyed_lock(key):
    # Keep one lock while callers are waiting, then remove it after the last user.
    with _guard:
        entry=_flights.setdefault(key,[threading.Lock(),0,None]);entry[1]+=1
    try:
        with entry[0]:
            # Waiters share a failed attempt as well; otherwise six duplicate
            # requests could each spend a full network timeout in sequence.
            if entry[2] is not None:raise entry[2]
            try:yield
            except BaseException as error:
                entry[2]=error
                raise
    finally:
        with _guard:
            entry[1]-=1
            if not entry[1]:del _flights[key]

def atomic_json(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_name(path.name+'.'+uuid.uuid4().hex+'.pending')
    try:
        temporary.write_text(json.dumps(value,ensure_ascii=False),encoding='utf-8')
        os.chmod(temporary,0o600);temporary.replace(path)
    finally:temporary.unlink(missing_ok=True)
