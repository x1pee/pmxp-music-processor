"""Push-only, owner-scoped processor. Sites owns claims and durable delivery fences."""
import hashlib
import hmac
import json
import os
import re
import shutil
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

OWNER = 1807122506
MAX_BODY = 2 * 1024 * 1024
TYPES = {'search', 'discover', 'catalogue', 'audit', 'prepare', 'send', 'playlist'}
ROUTES = {'renew', 'progress', 'partial', 'delivered', 'complete', 'playlist'}
TOP_KEYS = {'id', 'type', 'input', 'claim', 'userId', 'created'}
INPUT_KEYS = {
    'search': {'query', 'provider', 'offset', 'alternative', 'albumAction', 'albumId', 'track'},
    'discover': {'profile', 'tab', 'cursor', 'exclude', 'provider', 'batchSize', 'warm', 'relatedSearch'},
    'catalogue': {'tracks'}, 'audit': {'track', 'quality'}, 'prepare': {'tracks', 'format'},
    'send': {'track', 'format', 'receivedTrack'},
    'playlist': {'playlistId', 'action', 'operation', 'messageId', 'format', 'tracks', 'profile', 'tab', 'provider', 'order'},
}
for _allowed in INPUT_KEYS.values():
    _allowed.add('context')
FORBIDDEN_FIELDS = {'path', 'file', 'files', 'local_cover', 'localAudio', 'localPath', 'file_path', 'command', 'args',
                    'executable', 'cwd', 'env', 'headers', 'callback', 'callbackUrl', 'callbackURL', 'webhook', 'proxy'}
PROVIDER_HOSTS = {'soundcloud.com', 'www.soundcloud.com', 'youtube.com', 'www.youtube.com',
                  'music.youtube.com', 'youtu.be', 'bandcamp.com', 'genius.com', 'www.genius.com',
                  'music.apple.com', 'musicbrainz.org'}
IMAGE_SUFFIXES = ('mzstatic.com', 'sndcdn.com', 'ytimg.com', 'bcbits.com', 'googleusercontent.com', 'genius.com')


class InvalidJob(ValueError):
    pass


class ClaimLost(RuntimeError):
    pass


class DeliveryUncertain(RuntimeError):
    pass


class CallbackUnavailable(RuntimeError):
    pass


def json_bytes(value):
    return json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(',', ':')).encode('utf-8')


def validate_url(value):
    parsed = urllib.parse.urlsplit(value)
    host = (parsed.hostname or '').lower()
    permitted = host in PROVIDER_HOSTS or host.endswith('.bandcamp.com') or any(host == s or host.endswith('.' + s) for s in IMAGE_SUFFIXES)
    if parsed.scheme != 'https' or parsed.username or parsed.password or parsed.port not in (None, 443) or not permitted:
        raise InvalidJob('Unsupported provider URL')


def validate_tree(value, depth=0):
    if depth > 10:
        raise InvalidJob('Input depth exceeded')
    if isinstance(value, dict):
        if len(value) > 2500:
            raise InvalidJob('Too many fields')
        for key, item in value.items():
            if not isinstance(key, str) or key in FORBIDDEN_FIELDS or len(key) > 100:
                raise InvalidJob('Unsupported input field')
            validate_tree(item, depth + 1)
    elif isinstance(value, list):
        if len(value) > 1000:
            raise InvalidJob('Too many input items')
        for item in value:
            validate_tree(item, depth + 1)
    elif isinstance(value, str):
        if len(value) > 16000 or '\x00' in value:
            raise InvalidJob('Invalid input string')
        if re.match(r'^[A-Za-z][A-Za-z0-9+.-]*://', value):
            validate_url(value)
        elif value.startswith(('file:', 'data:', 'javascript:', 'ftp:', '\\\\')):
            raise InvalidJob('Unsupported input scheme')
    elif value is not None and not isinstance(value, (bool, int, float)):
        raise InvalidJob('Unsupported input value')


def validate_job(job):
    if not isinstance(job, dict) or set(job) - TOP_KEYS or not {'id', 'type', 'input', 'claim', 'userId'} <= set(job):
        raise InvalidJob('Expected a claimed job')
    if type(job['userId']) is not int or job['userId'] != OWNER:
        raise InvalidJob('Owner scope required')
    if not isinstance(job['id'], str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,100}', job['id']):
        raise InvalidJob('Invalid job id')
    if not isinstance(job['claim'], str) or not re.fullmatch(r'[A-Za-z0-9_.:-]{16,256}', job['claim']):
        raise InvalidJob('Invalid claim')
    if not isinstance(job['type'], str) or job['type'] not in TYPES or not isinstance(job['input'], dict) or set(job['input']) - INPUT_KEYS[job['type']]:
        raise InvalidJob('Unsupported job type/input')
    if 'created' in job and (type(job['created']) not in (int, float) or job['created'] <= 0):
        raise InvalidJob('Invalid creation time')
    data = job['input']
    context = data.get('context', {})
    if not isinstance(context, dict) or set(context) - {'catalogue', 'profile', 'preferences', 'tagCatalogue'}:
        raise InvalidJob('Unsupported private context')
    if 'catalogue' in context and (not isinstance(context['catalogue'], list) or len(context['catalogue']) > 1000):
        raise InvalidJob('Invalid catalogue context')
    if 'profile' in context and (not isinstance(context['profile'], dict) or context['profile'].get('owner', OWNER) != OWNER):
        raise InvalidJob('Context owner mismatch')
    if data.get('format', 'mp3') not in {'mp3', 'm4a'}:
        raise InvalidJob('Unsupported output format')
    if data.get('provider', 'SoundCloud') not in {'SoundCloud', 'YouTube', 'Bandcamp', 'all'}:
        raise InvalidJob('Unsupported provider')
    if 'offset' in data and (type(data['offset']) is not int or not 0 <= data['offset'] <= 10000):
        raise InvalidJob('Invalid offset')
    if job['type'] in {'send', 'audit'} and not isinstance(data.get('track'), dict):
        raise InvalidJob('Track required')
    if job['type'] in {'prepare', 'catalogue'} and (not isinstance(data.get('tracks'), list) or len(data['tracks']) > (3 if job['type'] == 'prepare' else 60)):
        raise InvalidJob('Bounded tracks required')
    if job['type'] == 'search' and not data.get('albumAction') and not data.get('alternative') and (not isinstance(data.get('query'), str) or not 1 <= len(data['query']) <= 500):
        raise InvalidJob('Search query required')
    validate_tree(data)
    if len(json_bytes(job)) > MAX_BODY:
        raise InvalidJob('Job too large')
    return job


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise CallbackUnavailable('Callback redirect blocked')


class SiteCallbacks:
    def __init__(self, origin, secret, job, opener=None):
        if origin != 'https://pmxp.fun':
            raise ValueError('SITE_ORIGIN must be https://pmxp.fun')
        self.origin, self.secret, self.job = origin, secret, job
        self.opener = opener or urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
        self.lost = threading.Event()

    def call(self, route, fields=None):
        if route not in ROUTES:
            raise ValueError('Callback route blocked')
        if self.lost.is_set():
            raise ClaimLost('Claim no longer active')
        fields = dict(fields or {})
        fields.pop('id', None)
        fields.pop('claim', None)
        # Legacy playlist's token is a button token, never the worker claim.
        if route == 'playlist' and 'token' in fields:
            fields['deliveryToken'] = fields.pop('token')
        else:
            fields.pop('token', None)
        payload = {'id': self.job['id'], 'token': self.job['claim'], **fields}
        body = json_bytes(payload)
        if len(body) > 2 * 1024 * 1024:
            raise CallbackUnavailable('Callback payload too large')
        request = urllib.request.Request(self.origin + '/api/mini/processor/' + route, data=body,
                                         headers={'Authorization': 'Bearer ' + self.secret, 'Content-Type': 'application/json'}, method='POST')
        try:
            with self.opener.open(request, timeout=15) as response:
                raw = response.read(2 * 1024 * 1024 + 1)
                if response.status != 200 or len(raw) > 2 * 1024 * 1024:
                    raise CallbackUnavailable('Callback response rejected')
                result = json.loads(raw)
        except urllib.error.HTTPError as error:
            status = error.code
            error.close()
            if status == 409:
                self.lost.set()
                raise ClaimLost('Claim/fence already consumed') from None
            raise CallbackUnavailable('Callback HTTP failure') from None
        except (ClaimLost, CallbackUnavailable):
            raise
        except Exception:
            raise CallbackUnavailable('Callback response unavailable') from None
        if not isinstance(result, dict) or result.get('ok') is not True:
            raise CallbackUnavailable('Callback did not acknowledge')
        return result


class FencedTelegram:
    """The only Telegram capability exposed to reused preparation/delivery code."""
    def __init__(self, raw, callbacks, job):
        self.raw, self.callbacks, self.job = raw, callbacks, job
        self.bot_id = raw.bot_id
        self.receipts = []
        self.write_count = 0
        self.uncertain = False
        self.lock = threading.Lock()

    def call(self, method, fields, files=None, **kwargs):
        if method in {'getMe', 'getFile'}:
            return self.raw.call(method, fields, files, **kwargs)
        if self.job['type'] not in {'send', 'playlist'} or method not in {'sendAudio', 'editMessageMedia', 'editMessageReplyMarkup'}:
            raise PermissionError('Telegram method not permitted by explicit job')
        if type(fields.get('chat_id')) is not int or fields['chat_id'] != OWNER:
            raise PermissionError('Telegram destination not owned')
        if method == 'editMessageReplyMarkup':
            # Cosmetic cleanup cannot create or replace an audio message.
            self.callbacks.call('renew')
            return self.raw.call(method, fields, files, **kwargs)
        with self.lock:
            if self.uncertain:
                raise DeliveryUncertain('Uncertain delivery cannot be replayed')
            limit = 1 if self.job['type'] == 'send' else 3
            if self.write_count >= limit:
                raise PermissionError('Explicit job delivery limit exceeded')
            key = 'send' if self.job['type'] == 'send' else 'playlist:' + str(self.write_count) + ':send'
            # Count before fence: no fallback can retry a consumed/unknown fence.
            self.write_count += 1
            try:
                self.callbacks.call('renew', {'deliveryFence': True, 'deliveryKey': key})
            except Exception:
                self.uncertain = True
                raise DeliveryUncertain('Delivery fence not confirmed; no send attempted') from None
            try:
                result = self.raw.call(method, fields, files, **kwargs)
            except Exception:
                self.uncertain = True
                # Deliberately conservative even for a definitive rejection.
                # A fresh user action gets a new job; this claim never resends.
                raise DeliveryUncertain('Telegram delivery unconfirmed; automatic resend stopped') from None
            if not isinstance(result, dict) or type(result.get('message_id')) is not int or result['message_id'] <= 0:
                self.uncertain = True
                raise DeliveryUncertain('No Telegram message receipt; automatic resend stopped')
            receipt = {'message_id': result['message_id'], 'audio': result.get('audio', {}),
                       'duration': result.get('audio', {}).get('duration'), 'botId': str(self.bot_id),
                       'deliveryKey': key, 'deliveredAt': round(time.time() * 1000)}
            self.receipts.append(receipt)
            # Never discard an actual receipt because Site acknowledgement failed.
            if self.job['type'] == 'send':
                try:
                    self.callbacks.call('delivered', {'result': receipt, 'deliveredAt': receipt['deliveredAt']})
                except Exception:
                    pass
            return result

    def download(self, file_id, target):
        # Extracted Telegram.download uses read-only getFile and a fixed TLS host.
        return self.raw.download(file_id, target)


class NativeRuntime:
    def __init__(self, bot_token, runtime_root):
        code = Path(__file__).resolve().parent
        root = Path(runtime_root).resolve()
        if root == code or code in root.parents:
            raise ValueError('Runtime state must be outside source bundle')
        root.mkdir(parents=True, exist_ok=True)
        (root / 'work').mkdir(exist_ok=True)
        (root / 'catalog').mkdir(exist_ok=True)
        if not (root / 'catalog/catalog.json').exists():
            (root / 'catalog/catalog.json').write_text('[]', encoding='utf-8')
        os.environ['PMP_RUNTIME_ROOT'] = str(root)
        os.environ['PYTHONPATH'] = os.pathsep.join((str(code), str(code / 'legacy')))
        os.environ['MINI_PROCESSOR_NETWORK_GUARD'] = '1'
        if not (root / 'chart-seeds.json').exists():
            shutil.copyfile(code / 'legacy/chart-seeds.json', root / 'chart-seeds.json')
        sys.path.insert(0, str(code / 'legacy'))
        from bot import Telegram
        self.raw = Telegram(bot_token)

    def execute(self, job, callbacks):
        from job_helpers import search_results, check_audio, received_input
        from delivery import send_track, prepare_tracks, StageTimings
        from taste import snapshot, identity, remember_received
        data, kind, owner = job['input'], job['type'], job['userId']
        api = FencedTelegram(self.raw, callbacks, job)
        sequence = 0
        # Claimed owner context comes from Sites, never a public profile endpoint.
        context = data.get('context') or {}
        catalogue = context.get('catalogue')
        if catalogue is not None:
            from media import ROOT
            from work_cache import atomic_json
            atomic_json(ROOT / 'catalog/catalog.json', catalogue)
        if isinstance(context.get('tagCatalogue'), dict):
            import tag_resolver
            # Signature->cached tags only; no scanner or old jobs are started.
            with tag_resolver._lock:
                tag_resolver._cache = {key: row for key, row in context['tagCatalogue'].items()
                                       if isinstance(row, dict) and type(row.get('time')) in (int, float) and isinstance(row.get('tags'), dict)}

        def partial(result):
            nonlocal sequence
            sequence += 1
            callbacks.call('partial', {'sequence': sequence, 'result': result})

        def progress(fields):
            try:
                callbacks.call('progress', fields)
            except CallbackUnavailable:
                pass

        if kind == 'search' and data.get('alternative'):
            from alternatives import find_alternative
            result = find_alternative(data['alternative'])
        elif kind == 'search' and data.get('albumAction'):
            from albums import open_album, albums_for_track, search_albums
            action = data['albumAction']
            provider = data.get('provider', 'all')
            if action == 'open':
                result = open_album(data['albumId'])
            elif action == 'track':
                result = albums_for_track(data['track'], provider, on_partial=partial)
            elif action == 'search':
                result = search_albums(data['query'], data.get('offset', 0), provider, on_partial=partial)
            else:
                raise InvalidJob('Unknown album action')
        elif kind == 'search':
            query = identity(data['query'])
            profile = context.get('profile') or snapshot(owner)
            local = [] if data.get('offset') else [t for t in profile.get('tracks', []) if t.get('source') == 'Telegram' and query in identity(t.get('artist', '') + ' ' + t.get('title', ''))][:20]
            result = search_results(data['query'], data.get('provider', 'SoundCloud'), data.get('offset', 0), local)
        elif kind == 'discover':
            from discovery import build_feed
            result = build_feed(data['profile'], data['tab'], cursor=data.get('cursor'), exclude=data.get('exclude', []),
                                provider=data.get('provider', 'SoundCloud'), batch_size=data.get('batchSize'),
                                on_partial=partial if data.get('warm') else None, include_related=data.get('relatedSearch', True))
        elif kind == 'catalogue':
            # On-demand metadata only: no permanent resolver/scanner thread.
            from tag_resolver import canonicalize, lookup
            rows = []
            for track in data['tracks']:
                callbacks.call('renew')
                row = canonicalize(track, enqueue=False)
                if row.get('catalogueState') in {'pending', 'unavailable', 'not-found'}:
                    try:
                        row = {**track, **lookup(track)}
                    except Exception:
                        row = {**row, 'catalogueState': 'unavailable'}
                rows.append(row)
                progress({'tracks': [row]})
            result = {'tracks': rows}
        elif kind == 'audit':
            result = check_audio(data['track'], data.get('quality') is True, api)
        elif kind == 'prepare':
            result = prepare_tracks(api, owner, data['tracks'], data['format'])
        elif kind == 'playlist':
            from playlist import Playlist
            result = Playlist(api, owner, callbacks.call).process(job)
            if result.get('messages') and any(type(i) is not int or i <= 0 for i in result['messages']):
                raise DeliveryUncertain('Playlist lacks actual message receipts')
        elif kind == 'send':
            track = data['track']
            timings = StageTimings(lambda value: progress(value))
            stage = lambda value: progress({'stage': value, **timings.snapshot()})
            try:
                if track.get('source') == 'Telegram':
                    from uploaded import send_uploaded
                    result = send_uploaded(api, owner, track, data['format'], stage)
                else:
                    result = send_track(api, owner, track, data['format'], on_stage=stage, publisher=None,
                                        on_progress=lambda value: progress(value), timings=timings)
            except Exception:
                if not api.receipts:
                    raise
                # Post-send bookkeeping must not erase a confirmed delivery or
                # invite an automatic second send after Site sees an error.
                result = {**api.receipts[-1], 'bookkeepingDeferred': True}
            if not api.receipts or result.get('message_id') != api.receipts[-1]['message_id']:
                raise DeliveryUncertain('Send lacks actual Telegram receipt')
            result = {**result, **timings.finish()}
            try:
                remember_received(owner, 'send:' + job['id'], received_input(data), result)
            except Exception:
                pass
        else:
            raise InvalidJob('Unsupported dispatch')
        return result


class Processor:
    def __init__(self, secret, runtime, origin='https://pmxp.fun', callback_factory=SiteCallbacks, workers=1, capacity=3):
        if not isinstance(secret, str) or not re.fullmatch(r'[a-f0-9]{64}', secret):
            raise ValueError('MINI_PROCESSOR_SECRET must be a new 64-character lowercase hex secret')
        if origin != 'https://pmxp.fun' or workers != 1 or capacity < 1 or capacity > 3:
            raise ValueError('Invalid processor settings')
        self.secret, self.runtime, self.origin, self.callback_factory = secret, runtime, origin, callback_factory
        self.pool = ThreadPoolExecutor(max_workers=workers, thread_name_prefix='claimed-job')
        self.slots = threading.BoundedSemaphore(capacity)
        self.lock = threading.Lock()
        self.registry = {}

    def authorized(self, header):
        return isinstance(header, str) and hmac.compare_digest(header.encode('utf-8'), ('Bearer ' + self.secret).encode('ascii'))

    def submit(self, job):
        validate_job(job)
        stable = json.loads(json_bytes(job))
        stable['input'].pop('context', None)
        if stable['type'] == 'discover':
            stable['input'].pop('profile', None)
        fingerprint = hashlib.sha256(json.dumps(stable, sort_keys=True, ensure_ascii=False, allow_nan=False, separators=(',', ':')).encode()).hexdigest()
        with self.lock:
            previous = self.registry.get(job['id'])
            if previous:
                if previous['fingerprint'] != fingerprint:
                    return 409, {'ok': False, 'error': 'job_claim_or_payload_changed'}
                return 202, {'ok': True, 'duplicate': True, 'state': previous['state']}
            now = time.monotonic()
            for key in list(self.registry):
                row = self.registry[key]
                if row['state'] not in {'queued', 'running'} and now - row['at'] > 86400:
                    del self.registry[key]
            if len(self.registry) >= 4096 or not self.slots.acquire(blocking=False):
                return 503, {'ok': False, 'error': 'processor_busy'}
            self.registry[job['id']] = {'fingerprint': fingerprint, 'state': 'queued', 'at': now}
            self.pool.submit(self._run, json.loads(json_bytes(job)))
        return 202, {'ok': True, 'accepted': True}

    def _run(self, job):
        callbacks = self.callback_factory(self.origin, self.secret, job)
        stopped = threading.Event()
        with self.lock:
            self.registry[job['id']]['state'] = 'running'

        def renew():
            while not stopped.wait(20):
                try:
                    callbacks.call('renew')
                except Exception:
                    # Fail closed; do not let preparation outlive a lost lease.
                    callbacks.lost.set()
                    break

        heartbeat = None
        state = 'failed'
        try:
            callbacks.call('renew')
            heartbeat = threading.Thread(target=renew, name='claimed-lease', daemon=True)
            heartbeat.start()
            result = self.runtime.execute(job, callbacks)
            if job['type'] == 'send' and (not isinstance(result, dict) or type(result.get('message_id')) is not int or result['message_id'] <= 0):
                raise DeliveryUncertain('Missing actual message receipt')
            callbacks.call('complete', {'result': result})
            state = 'complete'
        except Exception as error:
            uncertain = isinstance(error, DeliveryUncertain)
            state = 'uncertain' if uncertain else 'failed'
            # Never include exception text: URLs can contain credential material.
            try:
                callbacks.call('complete', {'error': 'Delivery uncertain; check Telegram before a new send.' if uncertain else 'Processor job failed.',
                                             'uncertain': uncertain})
            except Exception:
                pass
        finally:
            stopped.set()
            if heartbeat:
                heartbeat.join(timeout=1)
            with self.lock:
                self.registry[job['id']].update(state=state, at=time.monotonic())
            self.slots.release()

    def health(self):
        with self.lock:
            active = sum(v['state'] in {'queued', 'running'} for v in self.registry.values())
        return {'ok': True, 'service': 'pmxp-claimed-processor', 'protocol': 1, 'workers': 1, 'active': active}


def handler_for(processor):
    class Handler(BaseHTTPRequestHandler):
        server_version = 'PMXPProcessor/1'
        sys_version = ''
        protocol_version = 'HTTP/1.1'

        def setup(self):
            super().setup()
            self.connection.settimeout(15)

        def log_message(self, *args):
            pass  # Never log request bodies, headers, claims or provider data.

        def respond(self, code, value):
            body = json_bytes(value)
            self.send_response(code)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('Connection', 'close')
            self.end_headers()
            self.wfile.write(body)
            self.close_connection = True

        def do_GET(self):
            self.respond(200, processor.health()) if self.path == '/health' else self.respond(404, {'ok': False})

        def do_POST(self):
            if self.path != '/jobs/start':
                return self.respond(404, {'ok': False})
            if not processor.authorized(self.headers.get('Authorization')):
                return self.respond(401, {'ok': False, 'error': 'unauthorized'})
            if self.headers.get('Transfer-Encoding') or self.headers.get('Content-Type', '').split(';', 1)[0].strip() != 'application/json':
                return self.respond(415, {'ok': False, 'error': 'json_required'})
            try:
                length = int(self.headers.get('Content-Length', '0'))
                if not 0 < length <= MAX_BODY:
                    return self.respond(413, {'ok': False, 'error': 'body_limit'})
                raw = self.rfile.read(length)
                if len(raw) != length:
                    raise InvalidJob('Truncated body')
                job = json.loads(raw, parse_constant=lambda _: (_ for _ in ()).throw(InvalidJob('Nonfinite JSON')))
                code, value = processor.submit(job)
                return self.respond(code, value)
            except (ValueError, TypeError, KeyError, InvalidJob):
                return self.respond(400, {'ok': False, 'error': 'invalid_claimed_job'})
    return Handler


def main():
    from network_guard import install
    install()
    token = os.environ.get('TELEGRAM_BOT_TOKEN', '')
    if not re.fullmatch(r'[0-9]{5,20}:[A-Za-z0-9_-]{20,100}', token):
        raise SystemExit('TELEGRAM_BOT_TOKEN is required as a runtime secret')
    secret = os.environ.get('MINI_PROCESSOR_SECRET', '')
    # Validate settings before constructing any provider/client.
    if not re.fullmatch(r'[a-f0-9]{64}', secret):
        raise SystemExit('MINI_PROCESSOR_SECRET runtime secret is required')
    origin = os.environ.get('SITE_ORIGIN', 'https://pmxp.fun')
    if origin != 'https://pmxp.fun':
        raise SystemExit('Unsupported SITE_ORIGIN')
    runtime = NativeRuntime(token, os.environ.get('PMP_RUNTIME_ROOT', '/tmp/pmxp-processor'))
    processor = Processor(secret, runtime, origin)
    server = ThreadingHTTPServer(('0.0.0.0', int(os.environ.get('PORT', '7860'))), handler_for(processor))
    server.daemon_threads = True
    server.serve_forever(poll_interval=0.5)


if __name__ == '__main__':
    main()
