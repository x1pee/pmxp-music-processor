"""Inherited by fixed provider subprocesses; no requests occur on import."""
import os
if os.environ.get('MINI_PROCESSOR_NETWORK_GUARD') == '1':
    from network_guard import install
    install()
