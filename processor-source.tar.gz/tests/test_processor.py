import ast
import hashlib
import io
import json
import os
import socket
import sys
import threading
import types
import unittest
import urllib.error
from pathlib import Path
from unittest.mock import patch

import processor as p

SECRET = 'a' * 64  # Synthetic test value; never used for deployment.


def job(kind='search', ident='test_job', **data):
    defaults = {'search': {'query': 'test'}, 'discover': {'profile': {}, 'tab': 'personal'},
                'catalogue': {'tracks': []}, 'audit': {'track': {}}, 'prepare': {'tracks': [], 'format': 'mp3'},
                'send': {'track': {'id': '123', 'artist': 'a', 'title': 't'}, 'format': 'mp3'},
                'playlist': {'playlistId': 'p', 'operation': 'append'}}
    return {'id': ident, 'type': kind, 'input': {**defaults[kind], **data}, 'claim': 'claim_' + 'x' * 32, 'userId': p.OWNER, 'created': 1000}


class FakeCallbacks:
    instances = []

    def __init__(self, *args):
        self.calls = []
        self.lost = threading.Event()
        self.fail_fence = False
        self.fences = set()
        self.__class__.instances.append(self)

    def call(self, route, fields=None):
        fields = fields or {}
        self.calls.append((route, fields))
        if route == 'renew' and fields.get('deliveryFence'):
            key = fields['deliveryKey']
            if self.fail_fence or key in self.fences:
                raise p.CallbackUnavailable('Synthetic unavailable fence')
            self.fences.add(key)
        return {'ok': True}


class FakeTelegram:
    bot_id = '12345'

    def __init__(self):
        self.calls = []
        self.error = False
        self.missing = False

    def call(self, method, fields, files=None, **kwargs):
        self.calls.append((method, fields))
        if self.error:
            raise RuntimeError('Synthetic unknown wire response')
        if self.missing:
            return {'audio': {}}
        return {'message_id': len(self.calls), 'audio': {'duration': 10, 'file_id': 'synthetic-private-file'}}


class Safety(unittest.TestCase):
    def setUp(self):
        # Every test, including imported legacy modules, is offline.
        self.socket_block = patch.object(socket.socket, 'connect', side_effect=AssertionError('Network forbidden'))
        self.socket_block.start()

    def tearDown(self):
        self.socket_block.stop()

    def test_owner_and_strict_schema(self):
        p.validate_job(job())
        for mutate in [lambda j: j.update(userId=True), lambda j: j.pop('claim'), lambda j: j.update(userId=999),
                       lambda j: j.update(type='poll'), lambda j: j.update(callbackUrl='https://evil.example'),
                       lambda j: j['input'].update(command='ffmpeg'), lambda j: j['input'].update(context={'profile': {'owner': 999}})]:
            value = job(); mutate(value)
            with self.assertRaises(p.InvalidJob):
                p.validate_job(value)

    def test_url_and_filesystem_rejected(self):
        for value in ['http://127.0.0.1/x', 'https://localhost/x', 'https://169.254.169.254/x',
                      'file:///tmp/a', 'https://youtube.com@127.0.0.1/x', 'https://youtube.com:8443/x', 'data:a']:
            with self.assertRaises(p.InvalidJob):
                p.validate_tree({'url': value})
        with self.assertRaises(p.InvalidJob):
            p.validate_tree({'track': {'localAudio': 'a' * 64 + '.audio'}})
        p.validate_tree({'url': 'https://soundcloud.com/artist/track'})

    def test_auth_and_health_no_private_data(self):
        runtime = types.SimpleNamespace(execute=lambda *a: {})
        processor = p.Processor(SECRET, runtime, callback_factory=FakeCallbacks)
        self.addCleanup(processor.pool.shutdown)
        self.assertTrue(processor.authorized('Bearer ' + SECRET))
        self.assertFalse(processor.authorized('Bearer wrong'))
        self.assertFalse(processor.authorized('Bearer кириллица'))
        self.assertEqual(processor.health()['workers'], 1)
        self.assertEqual(set(processor.health()), {'ok', 'service', 'protocol', 'workers', 'active'})

    def test_dedup_changed_claim_and_volatile_context(self):
        gate = threading.Event()
        runtime = types.SimpleNamespace(execute=lambda *a: gate.wait(2) or {})
        processor = p.Processor(SECRET, runtime, callback_factory=FakeCallbacks)
        self.addCleanup(processor.pool.shutdown)
        try:
            first = job()
            self.assertEqual(processor.submit(first)[0], 202)
            updated = json.loads(json.dumps(first)); updated['input']['context'] = {'profile': {'owner': p.OWNER, 'tracks': []}}
            self.assertTrue(processor.submit(updated)[1]['duplicate'])
            changed = json.loads(json.dumps(first)); changed['claim'] += 'different'
            self.assertEqual(processor.submit(changed)[0], 409)
            changed = json.loads(json.dumps(first)); changed['input']['query'] = 'changed'
            self.assertEqual(processor.submit(changed)[0], 409)
        finally:
            gate.set()

    def test_capacity_one_running_two_queued(self):
        gate = threading.Event()
        counts = {'active': 0, 'max': 0}
        lock = threading.Lock()
        def execute(*args):
            with lock:
                counts['active'] += 1; counts['max'] = max(counts['max'], counts['active'])
            gate.wait(2)
            with lock:
                counts['active'] -= 1
            return {}
        processor = p.Processor(SECRET, types.SimpleNamespace(execute=execute), callback_factory=FakeCallbacks)
        try:
            self.assertEqual([processor.submit(job(ident='j' + str(i)))[0] for i in range(4)], [202, 202, 202, 503])
        finally:
            gate.set(); processor.pool.shutdown()
        self.assertEqual(counts['max'], 1)

    def test_fence_precedes_audio_actual_receipt(self):
        callbacks, raw = FakeCallbacks(), FakeTelegram()
        api = p.FencedTelegram(raw, callbacks, job('send'))
        result = api.call('sendAudio', {'chat_id': p.OWNER, 'audio': 'synthetic'})
        self.assertEqual(result['message_id'], 1)
        self.assertEqual(callbacks.calls[0], ('renew', {'deliveryFence': True, 'deliveryKey': 'send'}))
        self.assertEqual(callbacks.calls[1][0], 'delivered')
        self.assertEqual(callbacks.calls[1][1]['result']['audio']['file_id'], 'synthetic-private-file')
        with self.assertRaises(PermissionError):
            api.call('sendAudio', {'chat_id': p.OWNER})
        self.assertEqual(len(raw.calls), 1)

    def test_lost_fence_never_sends_or_retries(self):
        callbacks, raw = FakeCallbacks(), FakeTelegram(); callbacks.fail_fence = True
        api = p.FencedTelegram(raw, callbacks, job('send'))
        for _ in range(2):
            with self.assertRaises(p.DeliveryUncertain):
                api.call('sendAudio', {'chat_id': p.OWNER})
        self.assertEqual(raw.calls, [])
        self.assertEqual(len(callbacks.calls), 1)

    def test_uncertain_or_missing_receipt_never_resends(self):
        for missing in (False, True):
            callbacks, raw = FakeCallbacks(), FakeTelegram()
            raw.error, raw.missing = not missing, missing
            api = p.FencedTelegram(raw, callbacks, job('send'))
            for _ in range(2):
                with self.assertRaises(p.DeliveryUncertain):
                    api.call('sendAudio', {'chat_id': p.OWNER})
            self.assertEqual(len(raw.calls), 1)
            self.assertFalse(any(route == 'delivered' for route, _ in callbacks.calls))

    def test_playlist_unique_fences_and_destination_scope(self):
        callbacks, raw = FakeCallbacks(), FakeTelegram()
        api = p.FencedTelegram(raw, callbacks, job('playlist'))
        for _ in range(3):
            api.call('sendAudio', {'chat_id': p.OWNER})
        keys = [fields['deliveryKey'] for route, fields in callbacks.calls if route == 'renew']
        self.assertEqual(keys, ['playlist:0:send', 'playlist:1:send', 'playlist:2:send'])
        for method, fields in [('getUpdates', {}), ('sendMessage', {'chat_id': p.OWNER}), ('sendAudio', {'chat_id': 999})]:
            with self.assertRaises(PermissionError):
                api.call(method, fields)

    def test_prepare_cannot_send(self):
        raw = FakeTelegram(); api = p.FencedTelegram(raw, FakeCallbacks(), job('prepare'))
        with self.assertRaises(PermissionError):
            api.call('sendAudio', {'chat_id': p.OWNER})
        self.assertFalse(raw.calls)

    def test_no_receipt_cannot_complete_send(self):
        callbacks = FakeCallbacks()
        processor = p.Processor(SECRET, types.SimpleNamespace(execute=lambda *a: {'cached': True}), callback_factory=lambda *a: callbacks)
        processor.submit(job('send')); processor.pool.shutdown()
        complete = [fields for route, fields in callbacks.calls if route == 'complete']
        self.assertTrue(complete[-1]['uncertain'])
        self.assertNotIn('result', complete[-1])

    def test_callback_fixed_origin_auth_and_playlist_token(self):
        class Response:
            status = 200
            def __enter__(self): return self
            def __exit__(self, *args): return None
            def read(self, _): return b'{"ok":true}'
        class Opener:
            def open(self, request, timeout):
                self.request, self.timeout = request, timeout
                return Response()
        opener = Opener(); cb = p.SiteCallbacks('https://pmxp.fun', SECRET, job('playlist'), opener)
        cb.call('playlist', {'id': 'wrong', 'claim': 'wrong', 'token': 'button-token', 'action': 'activate'})
        sent = json.loads(opener.request.data)
        self.assertEqual(sent['id'], 'test_job')
        self.assertEqual(sent['token'], job()['claim'])
        self.assertEqual(sent['deliveryToken'], 'button-token')
        self.assertEqual(opener.request.full_url, 'https://pmxp.fun/api/mini/processor/playlist')
        self.assertEqual(opener.timeout, 15)
        with self.assertRaises(ValueError):
            p.SiteCallbacks('https://evil.example', SECRET, job())
        with self.assertRaises(ValueError):
            cb.call('recording_prepare')

    def test_callback_409_loses_claim(self):
        class Opener:
            def open(self, request, timeout):
                raise urllib.error.HTTPError(request.full_url, 409, 'stale', {}, io.BytesIO())
        cb = p.SiteCallbacks('https://pmxp.fun', SECRET, job(), Opener())
        with self.assertRaises(p.ClaimLost): cb.call('renew')
        self.assertTrue(cb.lost.is_set())

    def test_dispatch_all_branches_with_fake_modules(self):
        def module(**values): return types.SimpleNamespace(**values)
        modules = {
            'job_helpers': module(search_results=lambda *a: {'tracks': []}, check_audio=lambda *a: {'trackAudit': {}}, received_input=lambda d: d.get('track', {})),
            'delivery': module(send_track=lambda api, owner, track, fmt, **kw: {'message_id': api.call('sendAudio', {'chat_id': owner})['message_id']},
                               prepare_tracks=lambda *a: {'prepared': []}, StageTimings=lambda *a, **kw: module(snapshot=lambda: {}, finish=lambda: {})),
            'taste': module(snapshot=lambda *a: {'tracks': []}, identity=lambda s: s.lower(), remember_received=lambda *a: None),
            'alternatives': module(find_alternative=lambda *a: {'tracks': []}),
            'albums': module(open_album=lambda *a: {'tracks': []}, albums_for_track=lambda *a, **kw: {'albums': []}, search_albums=lambda *a, **kw: {'albums': []}),
            'discovery': module(build_feed=lambda *a, **kw: {'tracks': []}),
            'tag_resolver': module(canonicalize=lambda t, **kw: t, lookup=lambda t: {'catalogueState': 'verified'}),
            'playlist': module(Playlist=lambda api, owner, call: module(process=lambda j: {'messages': [api.call('sendAudio', {'chat_id': owner})['message_id']]})),
            'uploaded': module(send_uploaded=lambda api, owner, *a: {'message_id': api.call('sendAudio', {'chat_id': owner})['message_id']}),
        }
        runtime = p.NativeRuntime.__new__(p.NativeRuntime); runtime.raw = FakeTelegram()
        variants = [job(k) for k in p.TYPES] + [job('search', alternative={}), job('search', albumAction='open', albumId='a'),
                   job('search', albumAction='track', track={}), job('search', albumAction='search'), job('send', track={'source': 'Telegram'})]
        variants[-5]['input']['alternative'] = {'id': 'x'}
        with patch.dict(sys.modules, modules):
            for value in variants:
                with self.subTest(kind=value['type'], data=list(value['input'])):
                    result = runtime.execute(value, FakeCallbacks())
                    self.assertIsInstance(result, dict)

    def test_static_source_scope_and_ffmpeg_preserved(self):
        root = Path(p.__file__).parent
        for source in root.rglob('*.py'):
            ast.parse(source.read_text(encoding='utf-8'))
        source = (root / 'legacy/bot.py').read_text(encoding='utf-8')
        self.assertNotIn('MusicBot', source)
        self.assertNotIn('getUpdates', source)
        self.assertFalse((root / 'legacy/server.py').exists())
        self.assertFalse((root / 'legacy/service.py').exists())
        playlist = (root / 'legacy/playlist.py').read_text(encoding='utf-8')
        self.assertNotIn('def monitor', playlist)
        self.assertNotIn('def configure', playlist)
        security = (root / 'legacy/media_security.py').read_text(encoding='utf-8')
        self.assertIn("'-protocol_whitelist','file,pipe'", security)
        provenance = json.loads((root / 'SOURCE-PROVENANCE.json').read_text(encoding='utf-8'))
        for row in provenance['files']:
            self.assertEqual(hashlib.sha256((root / row['file']).read_bytes()).hexdigest(), row['sha256'])

    def test_subprocess_fixed_commands_and_no_secret_environment(self):
        sys.path.insert(0, str(Path(p.__file__).parent / 'legacy'))
        import runtime_security
        with patch.dict(os.environ, {'TELEGRAM_BOT_TOKEN': 'synthetic-token', 'MINI_PROCESSOR_SECRET': SECRET, 'HTTPS_PROXY': 'synthetic-proxy'}):
            environment = runtime_security.child_environment()
            self.assertNotIn('TELEGRAM_BOT_TOKEN', environment)
            self.assertNotIn('MINI_PROCESSOR_SECRET', environment)
            self.assertNotIn('HTTPS_PROXY', environment)
        for command in [['cmd.exe', '/c', 'bad'], [sys.executable, '-c', 'bad'], [sys.executable, '/tmp/evil.py']]:
            with self.assertRaises(PermissionError): runtime_security.check(command, {})
        runtime_security.check([sys.executable, '-u', str(Path(p.__file__).parent / 'legacy/provider_worker.py')], {})
        runtime_security.check(['ffmpeg', '-version'], {})

    def test_network_private_address_policy(self):
        from network_guard import public_address
        for value in ['127.0.0.1', '10.0.0.1', '169.254.169.254', '::1', 'fc00::1', '192.168.0.1', '0.0.0.0', '224.0.0.1', 'ff02::1']:
            with self.assertRaises(PermissionError): public_address(value)
        self.assertTrue(public_address('8.8.8.8').is_global)

    def test_http_handler_boundaries_without_socket(self):
        runtime = types.SimpleNamespace(execute=lambda *a: {})
        processor = p.Processor(SECRET, runtime, callback_factory=FakeCallbacks)
        self.addCleanup(processor.pool.shutdown)
        Handler = p.handler_for(processor)
        def invoke(method, path, headers, raw=b''):
            handler = Handler.__new__(Handler)
            handler.path, handler.headers = path, headers
            handler.rfile, handler.wfile = io.BytesIO(raw), io.BytesIO()
            response = {}
            handler.send_response = lambda code: response.update(code=code)
            handler.send_header = lambda *args: None
            handler.end_headers = lambda: None
            getattr(handler, 'do_' + method)()
            response['body'] = json.loads(handler.wfile.getvalue())
            return response
        self.assertEqual(invoke('GET', '/health', {})['code'], 200)
        self.assertEqual(invoke('GET', '/jobs/start', {})['code'], 404)
        self.assertEqual(invoke('POST', '/jobs/start', {})['code'], 401)
        base = {'Authorization': 'Bearer ' + SECRET, 'Content-Type': 'application/json'}
        self.assertEqual(invoke('POST', '/jobs/start', {**base, 'Content-Length': str(p.MAX_BODY + 1)})['code'], 413)
        self.assertEqual(invoke('POST', '/jobs/start', {**base, 'Content-Length': '4'}, b'null')['code'], 400)
        body = p.json_bytes(job())
        self.assertEqual(invoke('POST', '/jobs/start', {**base, 'Content-Length': str(len(body))}, body)['code'], 202)


if __name__ == '__main__':
    unittest.main()
