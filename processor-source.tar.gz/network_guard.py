"""Public-Internet-only sockets, including fixed Python provider children.

Not a replacement for provider URL validation. Blocks private destinations at
both DNS resolution and actual connect, including redirects/rebinding.
"""
import ipaddress
import socket

_installed = False


def public_address(value):
    address = ipaddress.ip_address(str(value).split('%', 1)[0])
    if not address.is_global or address.is_multicast or address.is_reserved:
        raise PermissionError('Non-public network destination blocked')
    return address


def install():
    global _installed
    if _installed:
        return
    _installed = True
    resolve, connect, connect_ex = socket.getaddrinfo, socket.socket.connect, socket.socket.connect_ex

    def safe_resolve(host, port, *args, **kwargs):
        if port not in (80, 443, '80', '443', 'http', 'https'):
            raise PermissionError('Outbound port blocked')
        rows = resolve(host, port, *args, **kwargs)
        for row in rows:
            public_address(row[4][0])
        return rows

    def check(address):
        if not isinstance(address, tuple) or len(address) < 2 or address[1] not in (80, 443):
            raise PermissionError('Outbound socket blocked')
        public_address(address[0])

    def safe_connect(sock, address):
        check(address)
        return connect(sock, address)

    def safe_connect_ex(sock, address):
        check(address)
        return connect_ex(sock, address)

    socket.getaddrinfo = safe_resolve
    socket.socket.connect = safe_connect
    socket.socket.connect_ex = safe_connect_ex
